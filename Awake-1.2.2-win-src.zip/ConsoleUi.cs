/*
  Awake Console, the phone client.

  One page, no CDN, no build step. Served inline so the app stays a single
  binary with nothing to install alongside it.

  Written entirely with single quotes so it can live in a C# verbatim string
  without escaping every attribute. Do not introduce a double quote in here.

  Three local lessons are baked in deliberately:

  - Back navigation restores a page from the bfcache with the DOM intact and no
    script re-run, so the stream is reopened on pageshow+persisted rather than
    left frozen.
  - Wide content (code, command lines) scrolls inside its own box. Setting one
    overflow axis forces the other to auto, which is how a page ends up
    scrolling sideways by accident, so the body pins overflow-x.
  - Streaming redraw is debounced with setTimeout, not requestAnimationFrame,
    because rAF stalls in a backgrounded tab and the transcript would freeze
    mid-answer.
*/

namespace AwakeApp
{
    public static class ConsoleUi
    {
        public const string Page = @"<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1, viewport-fit=cover'>
<meta name='color-scheme' content='dark'>
<meta name='theme-color' content='#17150f'>
<title>Awake Console</title>
<style>
  :root{
    --bg:#17150f; --panel:#1f1c15; --panel2:#272319; --line:#3a3428;
    --ink:#efe9dd; --dim:#a49b88; --faint:#756d5d;
    --acc:#d97757; --ok:#7fb069; --bad:#d9605a;
    --radius:14px;
  }
  *{box-sizing:border-box; -webkit-tap-highlight-color:transparent}
  html,body{margin:0; padding:0; height:100%}
  body{
    background:var(--bg); color:var(--ink);
    font:15px/1.55 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
    overflow-x:hidden;
    overscroll-behavior-y:none;
  }
  .app{display:flex; flex-direction:column; height:100vh; height:100dvh}

  header{
    display:flex; align-items:center; gap:10px;
    padding:calc(env(safe-area-inset-top) + 10px) 12px 10px;
    background:var(--panel); border-bottom:1px solid var(--line);
    position:sticky; top:0; z-index:5;
  }
  .burger{
    width:38px; height:38px; flex:0 0 38px; border-radius:10px;
    border:1px solid var(--line); background:var(--panel2); color:var(--ink);
    font-size:17px; line-height:1; cursor:pointer;
  }
  .htitle{flex:1; min-width:0}
  .htitle b{display:block; font-size:14px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis}
  .htitle span{display:block; font-size:11px; color:var(--faint); white-space:nowrap; overflow:hidden; text-overflow:ellipsis}
  .dot{width:9px; height:9px; flex:0 0 9px; border-radius:50%; background:var(--faint)}
  .dot.live{background:var(--ok)}
  .dot.busy{background:var(--acc); animation:pulse 1.1s ease-in-out infinite}
  .dot.gone{background:var(--bad)}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.25}}

  main{flex:1; overflow-y:auto; overflow-x:hidden; padding:14px 12px 6px; -webkit-overflow-scrolling:touch}

  .row{margin:0 0 14px}
  .you{display:flex; justify-content:flex-end}
  .you .b{
    background:#33251d; border:1px solid #4a3527; color:var(--ink);
    padding:9px 12px; border-radius:var(--radius) var(--radius) 4px var(--radius);
    max-width:86%; white-space:pre-wrap; word-wrap:break-word;
  }
  .md{word-wrap:break-word}
  .md p{margin:0 0 .7em}
  .md h1,.md h2,.md h3{margin:1em 0 .4em; line-height:1.3; font-size:1.05em}
  .md ul,.md ol{margin:0 0 .7em; padding-left:1.3em}
  .md li{margin:.15em 0}
  .md code{
    background:var(--panel2); border:1px solid var(--line); border-radius:5px;
    padding:1px 5px; font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; font-size:.87em;
  }
  .md pre{
    background:#12100b; border:1px solid var(--line); border-radius:10px;
    padding:10px 12px; margin:0 0 .8em; overflow-x:auto; max-width:100%;
  }
  .md pre code{background:none; border:0; padding:0; font-size:.84em; white-space:pre}
  .md a{color:var(--acc)}
  .md blockquote{margin:0 0 .7em; padding-left:10px; border-left:2px solid var(--line); color:var(--dim)}
  .md strong{font-weight:650}

  .tools{border:1px solid var(--line); background:var(--panel); border-radius:12px; overflow:hidden; margin:0 0 12px}
  .tools>summary{
    list-style:none; cursor:pointer; padding:8px 11px; font-size:12px; color:var(--dim);
    display:flex; align-items:center; gap:7px;
  }
  .tools>summary::-webkit-details-marker{display:none}
  .tools[open]>summary{border-bottom:1px solid var(--line)}
  .tool{display:flex; gap:8px; padding:6px 11px; font-size:12px; align-items:baseline; border-top:1px solid rgba(58,52,40,.5)}
  .tool:first-of-type{border-top:0}
  .tool .n{color:var(--acc); flex:0 0 auto; font-weight:600}
  .tool .s{color:var(--dim); min-width:0; overflow-x:auto; white-space:nowrap; font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; font-size:11px}
  .tool .r{margin-left:auto; flex:0 0 auto; color:var(--faint); font-size:11px}
  .tool.bad .r{color:var(--bad)}

  .think{display:inline-flex; gap:7px; align-items:center; font-size:12px; color:var(--faint); font-style:italic}
  .todos{border:1px solid var(--line); border-radius:12px; padding:9px 11px; margin:0 0 12px; background:var(--panel)}
  .todos div{font-size:12.5px; padding:2px 0; color:var(--dim)}
  .todos div.doing{color:var(--ink)}
  .todos div.done{color:var(--faint); text-decoration:line-through}
  .meta{font-size:11px; color:var(--faint); margin:0 0 12px}
  .note{font-size:12px; color:var(--faint); border-left:2px solid var(--line); padding-left:9px; margin:0 0 12px}
  .oops{font-size:12.5px; color:var(--bad); border:1px solid #4a2a28; background:#241a19; border-radius:10px; padding:8px 11px; margin:0 0 12px}

  form{
    display:flex; gap:8px; align-items:flex-end;
    padding:9px 12px calc(env(safe-area-inset-bottom) + 9px);
    background:var(--panel); border-top:1px solid var(--line);
  }
  textarea{
    flex:1; min-height:42px; max-height:35vh; resize:none;
    background:var(--panel2); color:var(--ink);
    border:1px solid var(--line); border-radius:12px; padding:10px 12px;
    font:15px/1.45 inherit; font-family:inherit;
  }
  textarea:focus{outline:none; border-color:var(--acc)}
  .go{
    width:44px; height:44px; flex:0 0 44px; border-radius:12px; border:0;
    background:var(--acc); color:#17150f; font-size:19px; font-weight:700; cursor:pointer;
  }
  .go:disabled{opacity:.4}

  .scrim{position:fixed; inset:0; background:rgba(0,0,0,.55); opacity:0; pointer-events:none; transition:opacity .18s; z-index:8}
  .scrim.on{opacity:1; pointer-events:auto}
  aside{
    position:fixed; top:0; left:0; bottom:0; width:min(88vw,380px); z-index:9;
    background:var(--panel); border-right:1px solid var(--line);
    transform:translateX(-101%); transition:transform .2s ease;
    display:flex; flex-direction:column;
  }
  aside.on{transform:translateX(0)}
  aside h3{
    margin:0; padding:calc(env(safe-area-inset-top) + 13px) 14px 11px;
    font-size:13px; letter-spacing:.04em; text-transform:uppercase; color:var(--faint);
    border-bottom:1px solid var(--line);
  }
  .pane{flex:1; overflow-y:auto; padding:10px 12px calc(env(safe-area-inset-bottom) + 14px)}
  .lbl{font-size:11px; text-transform:uppercase; letter-spacing:.05em; color:var(--faint); margin:14px 2px 7px}
  .lbl:first-child{margin-top:2px}
  .item{
    display:block; width:100%; text-align:left; cursor:pointer;
    background:var(--panel2); color:var(--ink); border:1px solid var(--line);
    border-radius:11px; padding:9px 11px; margin:0 0 7px; font:inherit;
  }
  .item:active{border-color:var(--acc)}
  .item b{display:block; font-size:13.5px; font-weight:600; overflow:hidden; text-overflow:ellipsis; white-space:nowrap}
  .item span{display:block; font-size:11px; color:var(--faint); margin-top:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap}
  select,.search{
    width:100%; background:var(--panel2); color:var(--ink);
    border:1px solid var(--line); border-radius:11px; padding:9px 11px;
    font:14px inherit; font-family:inherit; margin:0 0 8px;
  }
  /* Two classes, so this beats the .item span rule above, which is display:block
     and would otherwise stretch the pill across the whole row. */
  .item .pill{display:inline-block; width:auto; font-size:10px; color:var(--faint);
    border:1px solid var(--line); border-radius:20px; padding:1px 7px; margin-left:6px}
  .empty{color:var(--faint); font-size:12.5px; padding:6px 2px}
</style>
</head>
<body>
<div class='app'>
  <header>
    <button class='burger' id='menu' aria-label='Chats'>&#9776;</button>
    <div class='htitle'><b id='ttl'>Awake Console</b><span id='sub'>not connected</span></div>
    <div class='dot' id='dot'></div>
  </header>
  <main id='log'></main>
  <form id='composer'>
    <textarea id='box' rows='1' placeholder='Message Claude Code' enterkeyhint='send'></textarea>
    <button class='go' id='send' type='submit' disabled>&#8593;</button>
  </form>
</div>

<div class='scrim' id='scrim'></div>
<aside id='drawer'>
  <h3>Chats</h3>
  <div class='pane'>
    <div class='lbl'>New chat</div>
    <select id='model'></select>
    <select id='mode'></select>
    <input class='search' id='find' placeholder='Filter projects' autocomplete='off'>
    <div id='projects'></div>
    <div class='lbl'>Recent conversations</div>
    <div id='recent'><div class='empty'>Loading</div></div>
  </div>
</aside>

<script>
(function(){
  'use strict';
  var log=document.getElementById('log'), box=document.getElementById('box'),
      send=document.getElementById('send'), dot=document.getElementById('dot'),
      ttl=document.getElementById('ttl'), sub=document.getElementById('sub'),
      drawer=document.getElementById('drawer'), scrim=document.getElementById('scrim'),
      recent=document.getElementById('recent'), projects=document.getElementById('projects'),
      modeSel=document.getElementById('mode'), modelSel=document.getElementById('model'),
      find=document.getElementById('find');

  var chatId=null, sid=null, seen=0, es=null, items=[], state=null, busy=false;

  // ---------------------------------------------------------------- markdown --
  // Deliberately small: the subset Claude Code actually emits. Escaping happens
  // first, so nothing below can inject markup.
  function esc(s){
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
                    .replace(/>/g,'&gt;');
  }
  function inline(s){
    s=s.replace(/`([^`\n]+)`/g, function(m,c){ return '<code>'+c+'</code>'; });
    s=s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    s=s.replace(/(^|[\s(])\*([^*\n]+)\*/g, '$1<em>$2</em>');
    s=s.replace(/\[([^\]]+)\]\(((?:https?:|\/)[^)\s]+)\)/g,
                '<a href=$2 target=_blank rel=noopener>$1</a>');
    return s;
  }
  function md(src){
    var lines=esc(src||'').split(/\r?\n/), out=[], i=0;
    function flushList(tag,buf){ if(buf.length) out.push('<'+tag+'>'+buf.join('')+'</'+tag+'>'); }
    while(i<lines.length){
      var L=lines[i];
      var fence=L.match(/^\s*```+\s*([A-Za-z0-9_+-]*)\s*$/);
      if(fence){
        var code=[]; i++;
        while(i<lines.length && !/^\s*```+\s*$/.test(lines[i])){ code.push(lines[i]); i++; }
        i++;
        out.push('<pre><code>'+code.join('\n')+'</code></pre>');
        continue;
      }
      var h=L.match(/^(#{1,4})\s+(.*)$/);
      if(h){ var n=Math.min(h[1].length+1,4); out.push('<h'+n+'>'+inline(h[2])+'</h'+n+'>'); i++; continue; }
      if(/^\s*>\s?/.test(L)){
        var q=[];
        while(i<lines.length && /^\s*>\s?/.test(lines[i])){ q.push(inline(lines[i].replace(/^\s*>\s?/,''))); i++; }
        out.push('<blockquote>'+q.join('<br>')+'</blockquote>');
        continue;
      }
      if(/^\s*[-*+]\s+/.test(L)){
        var ul=[];
        while(i<lines.length && /^\s*[-*+]\s+/.test(lines[i])){
          ul.push('<li>'+inline(lines[i].replace(/^\s*[-*+]\s+/,''))+'</li>'); i++;
        }
        flushList('ul',ul); continue;
      }
      if(/^\s*\d+[.)]\s+/.test(L)){
        var ol=[];
        while(i<lines.length && /^\s*\d+[.)]\s+/.test(lines[i])){
          ol.push('<li>'+inline(lines[i].replace(/^\s*\d+[.)]\s+/,''))+'</li>'); i++;
        }
        flushList('ol',ol); continue;
      }
      if(/^\s*$/.test(L)){ i++; continue; }
      var para=[];
      while(i<lines.length && !/^\s*$/.test(lines[i]) &&
            !/^\s*```/.test(lines[i]) && !/^(#{1,4})\s/.test(lines[i]) &&
            !/^\s*[-*+]\s/.test(lines[i]) && !/^\s*\d+[.)]\s/.test(lines[i]) &&
            !/^\s*>\s?/.test(lines[i])){
        para.push(inline(lines[i])); i++;
      }
      out.push('<p>'+para.join('<br>')+'</p>');
    }
    return out.join('');
  }

  // ------------------------------------------------------------------ render --
  // Debounced with setTimeout rather than rAF: rAF stops firing in a
  // backgrounded tab, which would freeze the transcript mid-answer.
  var pending=null;
  function draw(){
    if(pending) return;
    pending=setTimeout(function(){ pending=null; paint(); }, 30);
  }
  function paint(){
    var near = log.scrollHeight - log.scrollTop - log.clientHeight < 130;
    var html='';
    for(var k=0;k<items.length;k++){
      var it=items[k];
      if(it.kind==='user')  html+='<div class=\'row you\'><div class=b>'+esc(it.text)+'</div></div>';
      else if(it.kind==='text') html+='<div class=\'row md\'>'+md(it.text)+'</div>';
      else if(it.kind==='think') html+='<div class=row><span class=think>thinking</span></div>';
      else if(it.kind==='note') html+='<div class=note>'+esc(it.text)+'</div>';
      else if(it.kind==='oops') html+='<div class=oops>'+esc(it.text)+'</div>';
      else if(it.kind==='meta') html+='<div class=meta>'+esc(it.text)+'</div>';
      else if(it.kind==='todos'){
        var t='';
        for(var q=0;q<it.list.length;q++){
          var st=it.list[q].s||'';
          var cl = st==='completed' ? 'done' : (st==='in_progress' ? 'doing' : '');
          var gl = st==='completed' ? '&#10003; ' : (st==='in_progress' ? '&#9656; ' : '&#183; ');
          t+='<div class='+cl+'>'+gl+esc(it.list[q].c)+'</div>';
        }
        html+='<div class=todos>'+t+'</div>';
      }
      else if(it.kind==='tools'){
        var rows='', done=0;
        for(var j=0;j<it.list.length;j++){
          var tl=it.list[j];
          rows+='<div class=\'tool'+(tl.ok===false?' bad':'')+'\'>'+
                '<span class=n>'+esc(tl.n)+'</span>'+
                '<span class=s>'+esc(tl.s||'')+'</span>'+
                '<span class=r>'+(tl.r===undefined?'':esc(tl.r))+'</span></div>';
          if(tl.r!==undefined) done++;
        }
        var open = done<it.list.length ? ' open' : '';
        // Name what it did, so a collapsed group still says something. A bare
        // '1 step' tells you nothing once it has finished.
        var names=[];
        for(var z=0;z<it.list.length;z++){
          if(names.indexOf(it.list[z].n)<0 && names.length<3) names.push(it.list[z].n);
        }
        html+='<details class=tools'+open+'><summary>'+it.list.length+
              (it.list.length===1?' step':' steps')+
              (names.length?' &#183; '+esc(names.join(', ')):'')+
              (done<it.list.length?' &#183; running':'')+'</summary>'+rows+'</details>';
      }
    }
    log.innerHTML=html;
    if(near) log.scrollTop=log.scrollHeight;
  }

  function push(it){ items.push(it); draw(); return it; }
  function openText(){
    var last=items[items.length-1];
    if(last && last.kind==='text' && !last.closed) return last;
    return push({kind:'text', text:'', closed:false});
  }
  function openTools(){
    var last=items[items.length-1];
    if(last && last.kind==='tools') return last;
    return push({kind:'tools', list:[]});
  }
  function dropThink(){
    for(var i=items.length-1;i>=0;i--){
      if(items[i].kind==='think'){ items.splice(i,1); return; }
      if(items[i].kind==='user') return;
    }
  }

  // ------------------------------------------------------------------ events --
  function apply(e){
    if(e.i!==undefined){
      if(e.i<=seen) return;      // replays are idempotent
      seen=e.i;
    }
    switch(e.t){
      case 'init':
        sid=e.sid;
        sub.textContent=(e.model||'')+' · '+e.tools+' tools · '+shortPath(e.cwd);
        setDot('live');
        break;
      case 'you':
        push({kind:'user', text:e.x});
        break;
      case 'think':
        push({kind:'think'});
        break;
      case 'delta':
        dropThink();
        openText().text+=e.x;
        draw();
        break;
      case 'msg':
        dropThink();
        var t=openText(); t.text=e.x; t.closed=true; draw();
        break;
      case 'tool':
        dropThink();
        var last=items[items.length-1];
        if(last && last.kind==='text' && !last.closed) last.closed=true;
        openTools().list.push({id:e.id, n:e.n, s:e.s});
        draw();
        break;
      case 'tool_done':
        for(var k=items.length-1;k>=0;k--){
          if(items[k].kind!=='tools') continue;
          var L=items[k].list, hit=false;
          for(var j=0;j<L.length;j++){
            if(L[j].id===e.id){ L[j].r=e.s||(e.ok?'ok':'failed'); L[j].ok=e.ok; hit=true; break; }
          }
          if(hit) break;
        }
        draw();
        break;
      case 'todos':
        push({kind:'todos', list:e.items||[]});
        break;
      case 'done':
        busy=false; setDot('live'); enable();
        var bits=[];
        if(e.sub && e.sub!=='success') bits.push(e.sub);
        if(e.cost) bits.push('$'+Number(e.cost).toFixed(4));
        if(e.total) bits.push('session $'+Number(e.total).toFixed(3));
        if(bits.length) push({kind:'meta', text:bits.join('  ·  ')});
        break;
      case 'stderr':
        push({kind:'note', text:e.x});
        break;
      case 'err':
        push({kind:'oops', text:e.x});
        break;
      case 'note':
        push({kind:'note', text:e.x});
        break;
      case 'exit':
        busy=false; setDot('gone'); enable();
        push({kind:'note', text:'Session ended. Send a message to start it again.'});
        chatId=null;
        break;
    }
  }

  function setDot(c){ dot.className='dot '+(c||''); }
  function shortPath(p){
    if(!p) return '';
    var parts=String(p).replace(/\\$/,'').split(/[\\\/]/);
    return parts.length>1 ? parts[parts.length-2]+'\\'+parts[parts.length-1] : parts[0];
  }
  function enable(){ send.disabled = busy || !box.value.trim(); }

  // ------------------------------------------------------------------ stream --
  function stream(){
    stop();
    if(!chatId) return;
    es=new EventSource('/api/stream?chatId='+encodeURIComponent(chatId)+'&from='+seen);
    es.onmessage=function(m){
      var e; try{ e=JSON.parse(m.data); }catch(x){ return; }
      apply(e);
    };
    // EventSource cannot change its URL on retry, so it would replay from the
    // original cursor forever. Reconnect by hand with the current one.
    es.onerror=function(){
      stop();
      if(chatId) setTimeout(stream, 1800);
    };
  }
  function stop(){ if(es){ try{ es.close(); }catch(x){} es=null; } }

  // Back restores the DOM with no script re-run, so without this the page comes
  // back looking fine and receiving nothing.
  window.addEventListener('pageshow', function(ev){
    if(ev.persisted && chatId) stream();
  });
  document.addEventListener('visibilitychange', function(){
    if(!document.hidden && chatId && (!es || es.readyState===2)) stream();
  });

  // -------------------------------------------------------------------- calls --
  function post(url, body){
    return fetch(url, {
      method:'POST', credentials:'same-origin',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(body||{})
    }).then(function(r){
      return r.json().catch(function(){ return {ok:false, error:'bad response'}; })
        .then(function(j){ if(!r.ok||j.ok===false) throw new Error(j.error||('HTTP '+r.status)); return j; });
    });
  }
  function get(url){
    return fetch(url, {credentials:'same-origin'}).then(function(r){ return r.json(); });
  }

  // ------------------------------------------------------------------ drawer --
  function setDrawer(on){
    drawer.classList.toggle('on', on);
    scrim.classList.toggle('on', on);
  }
  document.getElementById('menu').onclick=function(){ setDrawer(true); refresh(); };
  scrim.onclick=function(){ setDrawer(false); };

  function rel(iso){
    var d=new Date(iso), s=(Date.now()-d.getTime())/1000;
    if(isNaN(s)) return '';
    if(s<90) return 'just now';
    if(s<5400) return Math.round(s/60)+'m ago';
    if(s<172800) return Math.round(s/3600)+'h ago';
    return Math.round(s/86400)+'d ago';
  }

  function refresh(){
    return get('/api/state').then(function(s){
      state=s;
      if(!modeSel.options.length){
        for(var i=0;i<s.modes.length;i++){
          var o=document.createElement('option');
          o.value=s.modes[i];
          o.textContent = s.modes[i]==='auto' ? 'auto (your rails apply)' : s.modes[i];
          modeSel.appendChild(o);
        }
      }
      if(!modelSel.options.length && s.models){
        for(var m=0;m<s.models.length;m++){
          var mo=document.createElement('option');
          mo.value=s.models[m];
          mo.textContent = s.models[m]==='' ? 'default model' : s.models[m];
          modelSel.appendChild(mo);
        }
      }
      drawProjects();
      var h='';
      for(var k=0;k<s.sessions.length;k++){
        var c=s.sessions[k];
        h+='<button class=item data-sid='+c.id+'><b>'+esc(c.title)+'</b>'+
           '<span>'+esc(c.project)+' · '+rel(c.when)+' · '+c.kb+' KB</span></button>';
      }
      recent.innerHTML = h || '<div class=empty>No conversations yet</div>';
      var btns=recent.querySelectorAll('button');
      for(var b=0;b<btns.length;b++){
        btns[b].onclick=function(){ openChat({sid:this.getAttribute('data-sid')}); };
      }
    }).catch(function(){});
  }

  function drawProjects(){
    if(!state) return;
    var q=find.value.trim().toLowerCase(), h='';
    for(var i=0;i<state.projects.length;i++){
      var p=state.projects[i];
      if(q && p.name.toLowerCase().indexOf(q)<0 && p.path.toLowerCase().indexOf(q)<0) continue;
      h+='<button class=item data-i='+p.i+'><b>'+esc(p.name)+
         (p.linked?'<span class=pill>memory linked</span>':'')+'</b>'+
         '<span>'+esc(p.path)+'</span></button>';
    }
    projects.innerHTML = h || '<div class=empty>No match</div>';
    var btns=projects.querySelectorAll('button');
    for(var b=0;b<btns.length;b++){
      btns[b].onclick=function(){ openChat({project:Number(this.getAttribute('data-i'))}); };
    }
  }
  find.oninput=drawProjects;

  // -------------------------------------------------------------------- chats --
  function openChat(req){
    setDrawer(false);
    stop();
    items=[]; seen=0; chatId=null; sid=null; busy=false;
    setDot(''); sub.textContent='starting';
    ttl.textContent = req.sid ? 'Resuming' : 'New chat';
    paint();

    req.mode=modeSel.value||'auto';
    req.model=modelSel.value||'';
    post('/api/open', req).then(function(r){
      chatId=r.chatId; sid=r.sid||null; seen=r.seq||0;
      ttl.textContent=r.label||'Chat';
      sub.textContent=shortPath(r.cwd);
      setDot('live');
      enable();
      stream();
      // Show what was said before, so a reopened conversation is not a blank pane.
      if(req.sid) return get('/api/history?sid='+encodeURIComponent(req.sid)).then(function(h){
        var pre=[];
        for(var i=0;i<h.messages.length;i++){
          var m=h.messages[i];
          pre.push(m.role==='user' ? {kind:'user',text:m.text} : {kind:'text',text:m.text,closed:true});
        }
        if(pre.length){
          pre.push({kind:'meta', text:'above: earlier in this conversation'});
          items=pre.concat(items);
          paint();
          log.scrollTop=log.scrollHeight;
        }
      }).catch(function(){});
    }).catch(function(e){
      setDot('gone');
      sub.textContent='could not start';
      items=[{kind:'oops', text:String(e.message||e)}];
      paint();
    });
  }

  // ----------------------------------------------------------------- composer --
  box.addEventListener('input', function(){
    box.style.height='auto';
    box.style.height=Math.min(box.scrollHeight, window.innerHeight*0.35)+'px';
    enable();
  });
  box.addEventListener('keydown', function(ev){
    // A phone keyboard sends Enter as send. A desktop keyboard wants shift for
    // a newline, which is the convention everywhere else.
    if(ev.key==='Enter' && !ev.shiftKey && !ev.isComposing){
      ev.preventDefault();
      document.getElementById('composer').requestSubmit
        ? document.getElementById('composer').requestSubmit()
        : submit();
    }
  });
  document.getElementById('composer').addEventListener('submit', function(ev){
    ev.preventDefault(); submit();
  });

  function submit(){
    var text=box.value.trim();
    if(!text || busy) return;
    if(!chatId){
      items.push({kind:'oops', text:'No chat is open. Pick one from the menu.'});
      paint(); return;
    }
    box.value=''; box.style.height='auto';
    busy=true; setDot('busy'); enable();
    post('/api/send', {chatId:chatId, text:text}).catch(function(e){
      busy=false; setDot('gone'); enable();
      items.push({kind:'oops', text:String(e.message||e)}); paint();
    });
  }

  // -------------------------------------------------------------------- start --
  refresh().then(function(){
    if(state && state.chats && state.chats.length){
      // Reattach to whatever is already running, so reloading the page on the
      // phone does not abandon a turn in progress.
      var c=state.chats[0];
      chatId=c.chatId; sid=c.sid; seen=0; busy=c.busy;
      ttl.textContent=c.label||'Chat';
      sub.textContent=shortPath(c.cwd);
      setDot(c.busy?'busy':'live');
      enable(); stream();
    } else {
      setDrawer(true);
    }
  });
})();
</script>
</body>
</html>";
    }
}
