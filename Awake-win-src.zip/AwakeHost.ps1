<#
  Awake, hosted.

  Smart App Control blocks unsigned .exe files outright, and once it is on you
  cannot turn it back on after turning it off, so disabling it is a one way
  door. There is nothing to allowlist either: SAC has no per app exception.

  So this runs the identical app without ever putting an exe on disk. PowerShell
  itself is signed by Microsoft, and Add-Type compiles the same C# in process,
  which SAC permits. Same window, same tray icon, same verification.

  Bonus: updates get simpler. There is no locked exe to swap, only text files.

    powershell -ExecutionPolicy Bypass -File AwakeHost.ps1
    powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File AwakeHost.ps1 -tray
#>
param(
    [switch]$tray,
    # Set by the updater: wait for the outgoing instance to exit before we claim
    # the single instance mutex, otherwise the new copy just reports "already
    # running" and quits, leaving nothing running at all.
    [int]$waitFor = 0
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

# Windows PowerShell is STA, which WinForms requires. pwsh 7 is MTA and would
# give a dead window, so refuse rather than misbehave.
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    throw "Awake must run under Windows PowerShell (STA), not pwsh. Use powershell.exe."
}

$sources = @('Awake.cs', 'Updater.cs', 'Generated.cs') | ForEach-Object { Join-Path $root $_ }
foreach ($s in $sources) { if (-not (Test-Path $s)) { throw "missing source file: $s" } }

Add-Type -Path $sources -ReferencedAssemblies 'System.dll',
                                              'System.Drawing.dll',
                                              'System.Windows.Forms.dll',
                                              'System.IO.Compression.dll',
                                              'System.IO.Compression.FileSystem.dll'

if ($waitFor -gt 0) {
    try { (Get-Process -Id $waitFor -ErrorAction Stop).WaitForExit(30000) | Out-Null } catch { }
}

# Before anything creates a window. Windows PowerShell is DPI unaware, so
# without this the app is laid out at 96 DPI and then stretched by the OS, which
# looks blurry on a scaled display. The exe gets this from app.manifest instead.
[AwakeApp.Native]::MakeDpiAware()

# Tell the app it is hosted, so the updater swaps source files instead of trying
# to replace an exe that does not exist.
[AwakeApp.Host]::Scripted = $true
[AwakeApp.Host]::Root = $root

# One instance only, same as the exe build.
$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\AwakeAppSingleInstance', [ref]$created)
if (-not $created) {
    [System.Windows.Forms.MessageBox]::Show(
        'Awake is already running. Look for the dot in the notification area.',
        'Awake') | Out-Null
    return
}

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

$form = New-Object AwakeApp.MainForm($tray.IsPresent)
[System.Windows.Forms.Application]::Run($form)

$mutex.ReleaseMutex()
