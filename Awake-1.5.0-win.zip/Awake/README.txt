Awake
=====

Keeps your computer counted as active, so the screen does not blank and chat
apps do not flip you to Away while you are still at your desk.

It does this by injecting a real one pixel mouse movement every 50 to 95
seconds and holding a power request, and then it checks that Windows actually
accepted each nudge. If something blocks it, the dot turns red and the window
tells you why, rather than claiming it is working when it is not.


INSTALL
-------

1. Unzip this whole folder somewhere. Downloads is fine.
2. Double click Install.cmd.
3. Look for the small coloured dot in the notification area, next to the
   clock. You may have to click the arrow to show hidden icons. Click the dot
   to open the window.

Green means it is working.


"WINDOWS PROTECTED YOUR PC"
---------------------------

You will probably see this, and it is expected. The app is not signed with a
paid certificate, so Windows warns about it the same way it warns about
anything it has not seen many times before.

Click "More info", then "Run anyway".

If instead Windows says the file is blocked by a security policy and gives you
no "Run anyway" option, that machine has Smart App Control switched on. It
blocks every unsigned program outright and has no per app exception. There is
no workaround from this package; that machine cannot run Awake for now.


USING IT
--------

The window shows what it is doing:

  Idle           how long Windows thinks you have been idle, live
  Longest gap    the longest it ever slipped since starting
  Away events    how many times idle crossed five minutes. Zero is what
                 you want
  Nudges         how many it has sent

Schedule       pick the days and the hours you want it active. It turns
               itself on and off to match.
Verify now     sends a nudge immediately and proves it landed.
Pause          stops it without quitting.

Tick "Start automatically when I sign in to Windows" and you can forget
about it.


WHAT IT DOES NOT DO
-------------------

It cannot beat a locked screen. Nothing can: Windows stops counting you as
present the moment you lock, and the app says so rather than pretending.

It needs to not be running under a window owned by an administrator, because
Windows refuses injected input in that case. If that happens the dot turns
red and explains.


UPDATES
-------

It checks for a new version 30 seconds after starting and then every six
hours, and updates itself quietly. It verifies a checksum before installing
anything and refuses a bad download rather than breaking a working install.

You can also press "Check for updates" in the window.


PRIVACY
-------

It does not collect anything, it has no account, and it makes no network
requests other than checking for its own updates.
