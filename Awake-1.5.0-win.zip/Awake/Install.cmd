@echo off
setlocal
title Awake installer

rem Double click this to install Awake.
rem
rem Copies the app into your own user folder, adds a Start menu entry, and
rem starts it. Nothing here needs administrator rights and nothing is written
rem outside your own profile.

set "SRC=%~dp0Awake.exe"
set "DEST=%LOCALAPPDATA%\Awake"
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Awake.lnk"

echo.
echo   Awake
echo   =====
echo.

if not exist "%SRC%" (
    echo   Awake.exe is not next to this file.
    echo.
    echo   Unzip the whole folder first, then run Install.cmd from the
    echo   unzipped folder. Running it straight out of the zip viewer does
    echo   not work.
    echo.
    pause
    exit /b 1
)

rem A running copy holds the file open, so close it before replacing it.
tasklist /fi "imagename eq Awake.exe" 2>nul | find /i "Awake.exe" >nul
if not errorlevel 1 (
    echo   closing the copy that is already running
    taskkill /im Awake.exe /f >nul 2>&1
    rem give Windows a moment to release the file
    ping -n 3 127.0.0.1 >nul
)

if not exist "%DEST%" mkdir "%DEST%" 2>nul

echo   installing to %DEST%
copy /y "%SRC%" "%DEST%\Awake.exe" >nul
if errorlevel 1 (
    echo.
    echo   Could not copy the file. If Awake is still running, close it from
    echo   the notification area and try again.
    echo.
    pause
    exit /b 1
)

echo   adding a Start menu entry
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%LNK%'); $s.TargetPath='%DEST%\Awake.exe'; $s.WorkingDirectory='%DEST%'; $s.Description='Keeps this session counted as active'; $s.Save()" >nul 2>&1

echo   starting Awake
start "" "%DEST%\Awake.exe"

echo.
echo   Done. Awake is running: look for the small coloured dot in the
echo   notification area, next to the clock. You may need to click the
echo   arrow to show hidden icons.
echo.
echo   Green means it is working. Click the dot to open the window.
echo.
echo   To have it start with Windows, tick the box in the window.
echo.
pause
