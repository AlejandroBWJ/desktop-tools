/*
  What the machine has spent recently, across everything.

  The per-chat counters in Chat only see chats Console opened, and that turned
  out to be a small and misleading slice. Measuring three days of transcripts
  found ten conversations live in a single hour: terminals, background agents,
  the desktop app and the phone, all drawing on one shared limit. Reporting only
  the phone's own chats told a comforting and wrong story.

  Two other things that measurement settled, both worth writing down because
  both contradict the obvious guess:

  - There is no Console penalty. Uncached input across a Console-driven
    conversation was 3k tokens against 618M read from cache, so the prompt cache
    is hitting essentially always and a resumed chat is not re-reading its
    history at full price.
  - Compaction works normally in headless mode. Conversations sawtooth up to the
    ceiling and back down, the same shape a terminal produces.

  What actually costs is the request count. One typed message fans out into
  twenty to seventy API requests here, and every one of them re-reads the whole
  conversation. So the honest unit is requests and tokens over a window, not
  prompts, and the window has to cover the whole machine.

  Reading is deliberately crude: the tail of each recently written transcript,
  scanned backwards, string operations rather than a JSON parser, stopping as
  soon as the timestamps fall out of the window. This runs behind a status
  request on a laptop that is also running the agents it is measuring.

  C# 5 only. No string interpolation, no null-conditional operator.
*/

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace AwakeApp
{
    public static class Usage
    {
        // One conversation's share of the window.
        public class Slice
        {
            public string Id = "";
            public string Project = "";
            public long Requests;
            public long Read;       // input + cache writes + cache reads
            public long Written;    // output
        }

        public class Window
        {
            public int Hours;
            public long Requests;
            public long Read;
            public long Written;
            public long Sessions;
            public List<Slice> Top = new List<Slice>();
            public DateTime Taken;
            public bool Partial;    // the byte budget ran out before every file was read
        }

        // Read backwards a chunk at a time and stop as soon as the timestamps
        // fall out of the window. A fixed tail read was the first attempt and
        // was wrong in both directions at once: 12 MB per file is far more than
        // five hours needs on a quiet conversation, and it still exhausted the
        // total budget and silently skipped conversations.
        const int ChunkBytes = 512 * 1024;

        // Never read more than this from any one transcript. There is a 256 MB
        // file in this store, and a conversation whose last five hours do not
        // fit in 32 MB is one nothing useful can be said about anyway.
        const long TailBytes = 32 * 1024 * 1024;

        // And never read more than this in total, so a status request cannot
        // turn into a disk crawl.
        const long BudgetBytes = 256 * 1024 * 1024;

        static readonly object gate = new object();
        static Window cached;

        // Cached, because the status sheet polls and the answer cannot move
        // meaningfully in a minute.
        public static Window Recent(int hours)
        {
            lock (gate)
            {
                if (cached != null && cached.Hours == hours
                    && (DateTime.UtcNow - cached.Taken).TotalSeconds < 60)
                    return cached;
            }

            Window w = Measure(hours);

            lock (gate) { cached = w; }
            return w;
        }

        static Window Measure(int hours)
        {
            Window w = new Window();
            w.Hours = hours;
            w.Taken = DateTime.UtcNow;

            DateTime since = DateTime.UtcNow.AddHours(-hours);
            string root = SessionIndex.Root();
            if (!Directory.Exists(root)) return w;

            List<FileInfo> files = new List<FileInfo>();
            try
            {
                foreach (string dir in Directory.GetDirectories(root))
                {
                    string[] jsonl;
                    try { jsonl = Directory.GetFiles(dir, "*.jsonl"); }
                    catch { continue; }
                    foreach (string f in jsonl)
                    {
                        FileInfo fi = new FileInfo(f);
                        // mtime is only a filter, never the answer. Something on
                        // this machine touches every transcript at once, which
                        // makes files look newer than they are. Too new is safe
                        // here: it costs a tail read and finds nothing.
                        if (fi.LastWriteTimeUtc < since) continue;
                        if (fi.Length < 512) continue;
                        files.Add(fi);
                    }
                }
            }
            catch { return w; }

            // Most recently written first, so if the budget runs out it runs out
            // on the conversations that matter least.
            files.Sort(delegate(FileInfo a, FileInfo b)
            {
                return b.LastWriteTimeUtc.CompareTo(a.LastWriteTimeUtc);
            });

            Dictionary<string, Slice> byId = new Dictionary<string, Slice>();
            long spent = 0;

            foreach (FileInfo fi in files)
            {
                if (spent >= BudgetBytes) { w.Partial = true; break; }

                long read;
                Slice s = ReadTail(fi, since, out read);
                spent += read;
                if (s == null || s.Requests == 0) continue;

                s.Id = Path.GetFileNameWithoutExtension(fi.Name);
                s.Project = SessionIndex.ShortProject(
                    SessionIndex.DecodeDir(fi.Directory.Name));
                byId[s.Id] = s;

                w.Requests += s.Requests;
                w.Read += s.Read;
                w.Written += s.Written;
            }

            w.Sessions = byId.Count;
            List<Slice> all = new List<Slice>(byId.Values);
            all.Sort(delegate(Slice a, Slice b) { return b.Read.CompareTo(a.Read); });
            for (int i = 0; i < all.Count && i < 6; i++) w.Top.Add(all[i]);
            return w;
        }

        // Scan the tail backwards, line by line, and stop at the first line that
        // is older than the window. Transcripts are append-only and in order, so
        // once the timestamps fall out there is nothing further back to find.
        static Slice ReadTail(FileInfo fi, DateTime since, out long bytesRead)
        {
            bytesRead = 0;
            Slice s = new Slice();
            UTF8Encoding utf8 = new UTF8Encoding(false);

            try
            {
                using (FileStream fs = new FileStream(fi.FullName, FileMode.Open,
                                                      FileAccess.Read, FileShare.ReadWrite))
                {
                    long pos = fs.Length;
                    long floor = Math.Max(0, fs.Length - TailBytes);

                    // Bytes, not a string. A chunk boundary can fall inside a
                    // UTF-8 character, and carrying the partial line as raw
                    // bytes is the only way to join the halves back correctly.
                    byte[] carry = new byte[0];

                    while (pos > floor)
                    {
                        int chunk = (int)Math.Min(ChunkBytes, pos - floor);
                        byte[] buf = new byte[chunk + carry.Length];
                        pos -= chunk;
                        fs.Seek(pos, SeekOrigin.Begin);

                        int got = 0;
                        while (got < chunk)
                        {
                            int n = fs.Read(buf, got, chunk - got);
                            if (n <= 0) break;
                            got += n;
                        }
                        bytesRead += got;
                        Buffer.BlockCopy(carry, 0, buf, chunk, carry.Length);

                        // Unless this chunk starts the file, its first line is
                        // almost certainly cut in half. Hold it back for the
                        // next read, which covers the bytes before it.
                        int from = 0;
                        if (pos > floor)
                        {
                            int nl = Array.IndexOf<byte>(buf, 10, 0, got);
                            if (nl < 0)
                            {
                                carry = buf;    // no line break at all, keep going
                                continue;
                            }
                            carry = new byte[nl + 1];
                            Buffer.BlockCopy(buf, 0, carry, 0, nl + 1);
                            from = nl + 1;
                        }
                        else
                        {
                            carry = new byte[0];
                        }

                        string text = utf8.GetString(buf, from, buf.Length - from);
                        if (ScanBackwards(text, since, s)) return s;
                    }
                }
            }
            catch { return s.Requests > 0 ? s : null; }

            return s;
        }

        // Returns true when a line older than the window was reached, which means
        // there is nothing further back worth reading: transcripts are
        // append-only and in order.
        static bool ScanBackwards(string text, DateTime since, Slice s)
        {
            int end = text.Length;

            while (end > 0)
            {
                int start = text.LastIndexOf('\n', end - 1);
                string line = text.Substring(start + 1, end - start - 1);
                end = start;

                // Only assistant messages carry usage, and there is no point
                // parsing anything else.
                if (line.IndexOf("\"usage\"", StringComparison.Ordinal) < 0) continue;

                DateTime when;
                if (!Stamp(line, out when)) continue;
                if (when < since) return true;

                long tin = Field(line, "\"input_tokens\":");
                long tcw = Field(line, "\"cache_creation_input_tokens\":");
                long tcr = Field(line, "\"cache_read_input_tokens\":");
                long tout = Field(line, "\"output_tokens\":");
                if (tin + tcw + tcr + tout == 0) continue;

                s.Requests++;
                s.Read += tin + tcw + tcr;
                s.Written += tout;
            }

            return false;
        }

        static bool Stamp(string line, out DateTime when)
        {
            when = DateTime.MinValue;
            int i = line.IndexOf("\"timestamp\":\"", StringComparison.Ordinal);
            if (i < 0) return false;
            i += 13;
            int j = line.IndexOf('"', i);
            if (j < 0 || j - i < 10 || j - i > 40) return false;
            return DateTime.TryParse(line.Substring(i, j - i), CultureInfo.InvariantCulture,
                                     DateTimeStyles.AdjustToUniversal
                                     | DateTimeStyles.AssumeUniversal, out when);
        }

        static long Field(string line, string key)
        {
            int i = line.IndexOf(key, StringComparison.Ordinal);
            if (i < 0) return 0;
            i += key.Length;
            long v = 0;
            bool any = false;
            while (i < line.Length && line[i] >= '0' && line[i] <= '9')
            {
                v = v * 10 + (line[i] - '0');
                i++;
                any = true;
            }
            return any ? v : 0;
        }
    }
}
