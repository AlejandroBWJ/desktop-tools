#!/bin/bash
# Double click this file to install Awake.
#
# If macOS refuses to open it, right click it and choose Open, then click Open
# in the dialog. That is Gatekeeper being careful about files from the internet,
# and it applies to this script as well as to the app.

set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/Awake.app"
DEST="/Applications/Awake.app"

echo "Awake installer"
echo

if [ ! -d "$APP" ]; then
    echo "Awake.app is not next to this script."
    echo "Unzip Awake-macOS.zip first, then run install.command from the unzipped folder."
    echo
    read -n 1 -s -r -p "Press any key to close."
    exit 1
fi

# The zip came from the internet, so every file inside carries a quarantine
# flag. Without clearing it macOS shows "Apple could not verify Awake".
echo "==> clearing the download quarantine flag"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true

REPLACING=0
if [ -d "$DEST" ]; then
    echo "==> replacing the existing copy in /Applications"
    REPLACING=1
    osascript -e 'quit app "Awake"' 2>/dev/null || true
    sleep 1
    rm -rf "$DEST"
fi

echo "==> copying to /Applications"
if ! cp -R "$APP" "$DEST"; then
    echo "Could not write to /Applications. Trying your own Applications folder instead."
    mkdir -p "$HOME/Applications"
    DEST="$HOME/Applications/Awake.app"
    rm -rf "$DEST"
    cp -R "$APP" "$DEST" || { echo "copy failed"; read -n 1 -s -r -p "Press any key to close."; exit 1; }
fi

# An ad-hoc signed app gets a new code identity every time it is rebuilt, so an
# existing permission entry points at the OLD binary. It keeps showing as
# granted while doing nothing, which looks exactly like a broken app. Clearing
# it forces a fresh prompt against the new copy.
if [ "$REPLACING" = "1" ]; then
    echo "==> clearing the stale permission entry from the previous version"
    tccutil reset PostEvent com.bwj.awake 2>/dev/null || true
    tccutil reset Accessibility com.bwj.awake 2>/dev/null || true
fi

echo "==> launching"
open "$DEST"

cat <<'EOF'

Installed.

One thing left, and Awake genuinely cannot work without it:

  macOS will ask for permission to post input events. If you miss the prompt,
  open System Settings > Privacy & Security > Accessibility, click +, and add
  Awake from your Applications folder. Make sure its switch is on.

Then click "Verify now" in the app. It should say PASSED.

If it says permission is granted but events are not landing, remove Awake from
that Accessibility list with the minus button and add it back. That happens
because this app is not signed with a paid Apple developer certificate, so
macOS cannot recognise it as the same app across updates.

Awake lives in the menu bar as a coloured dot. Green means it is holding your
session active, amber means paused or outside its hours, red means something is
actually broken and the app will say what. It cannot hold your status green
through a locked screen or a screensaver, and it does not pretend to.

EOF

read -n 1 -s -r -p "Press any key to close."
echo
