<#
  Awake watchdog.

  Awake starts from the Run key, which fires once, at logon. That is fine for a
  desktop utility and useless for something meant to answer a phone for days: if
  the process ever dies there is nothing to notice, and the machine it is
  supposed to be reachable on is the one place you cannot get to.

  A scheduled task runs this every few minutes. It checks the single instance
  mutex rather than looking for a process name, because the app runs hosted
  inside powershell.exe and is indistinguishable from any other by name. If the
  mutex is gone, nothing is running, so it starts one.

  Checking the mutex also avoids the failure this would otherwise have: launching
  AwakeHost.ps1 while a copy is already up puts a "Awake is already running"
  dialog on screen, and a watchdog that does that every five minutes is worse
  than no watchdog at all.

  It also watches the path to the phone, which is the part that actually broke.
  On 2026-09-09 the app was perfectly healthy, answering 200 on loopback, and
  completely unreachable, because tailscale-ipn.exe was not running. On Windows
  that process is the user mode frontend that owns the interactive user's
  profile: without it the service sits in NoState forever and the tunnel adapter
  keeps an APIPA address instead of a tailnet one. Restarting the service does
  not fix it, and `tailscale up` returns silently without connecting, so it
  presents as a healthy machine that simply cannot be reached. Nothing was
  watching the one component whose failure is invisible from the phone and
  unfixable without walking to the laptop.

  So there are three checks, each independent and each repairing only itself:
  the app, the tray process, and the serve config. Everything is best effort and
  nothing here throws: a watchdog that dies on its first surprise is not a
  watchdog. It logs only when it acts, because it runs forever.

  Needs no administrator rights and touches nothing outside the user profile.
#>

# Deliberately not 'Stop'. Every check below guards itself, and one unexpected
# failure must not skip the checks that come after it.
$ErrorActionPreference = 'Continue'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$hostScript = Join-Path $root 'AwakeHost.ps1'
$logFile = Join-Path $root 'watchdog.log'
# Settings always live beside the installed copy, never beside the repo copy.
$dataDir = Join-Path $env:LOCALAPPDATA 'Awake'

function Note($msg) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $msg
    try {
        # Keep it small. This runs every few minutes forever.
        if ((Test-Path $logFile) -and (Get-Item $logFile).Length -gt 200KB) {
            $keep = Get-Content $logFile -Tail 200
            Set-Content $logFile $keep -Encoding utf8
        }
        Add-Content $logFile $line -Encoding utf8
    } catch { }
}

# settings.ini is written with a BOM, so match per line rather than parsing.
function Get-Setting($name, $fallback) {
    try {
        $ini = Join-Path $dataDir 'settings.ini'
        if (-not (Test-Path $ini)) { return $fallback }
        foreach ($line in (Get-Content $ini -Encoding UTF8)) {
            if ($line -match ('^\s*' + [regex]::Escape($name) + '\s*=\s*(.+?)\s*$')) {
                return $matches[1]
            }
        }
    } catch { }
    return $fallback
}

# --------------------------------------------------------------- the app --

function Repair-Awake {
    if (-not (Test-Path $hostScript)) { Note 'AwakeHost.ps1 is missing, cannot start'; return }

    $mutex = $null
    $running = $false
    try {
        $running = [System.Threading.Mutex]::TryOpenExisting('Local\AwakeAppSingleInstance', [ref]$mutex)
    } catch {
        $running = $false
    }
    if ($mutex) { try { $mutex.Dispose() } catch { } }
    if ($running) { return }

    Note 'Awake was not running, starting it'
    try {
        Start-Process -FilePath 'powershell.exe' `
            -ArgumentList '-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass',
                          '-File', $hostScript, '-tray' `
            -WindowStyle Hidden
        Note 'started'
    } catch {
        Note ('could not start Awake: ' + $_.Exception.Message)
    }
}

# ---------------------------------------------------------- the tunnel --

function Find-Tailscale($leaf) {
    $roots = @($env:ProgramFiles, ${env:ProgramFiles(x86)})
    foreach ($r in $roots) {
        if ($r) {
            $p = Join-Path $r (Join-Path 'Tailscale' $leaf)
            if (Test-Path $p) { return $p }
        }
    }
    try {
        $cmd = Get-Command $leaf -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }
    } catch { }
    return $null
}

# The ground truth for "are we on the tailnet". The CLI reports NoState in this
# situation, which reads like a transient startup state rather than a fault, and
# an address either is or is not 100.x.
function Get-TailnetAddress {
    try {
        $ip = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
              Where-Object { $_.InterfaceAlias -match 'Tailscale' -and $_.IPAddress -like '100.*' }
        if ($ip) { return @($ip)[0].IPAddress }
    } catch { }
    return $null
}

function Repair-Tunnel {
    # Only meddle with Tailscale if Console is actually switched on here.
    if ((Get-Setting 'console' '0') -ne '1') { return }

    $ts = Find-Tailscale 'tailscale.exe'
    if (-not $ts) { return }   # not installed, not our business

    $addr = Get-TailnetAddress

    # The tray app owns the interactive user's profile. This scheduled task runs
    # as the logged in user precisely so Start-Process lands in that session; as
    # SYSTEM it would start in session 0 and do nothing useful.
    $tray = $null
    try { $tray = Get-Process 'tailscale-ipn' -ErrorAction SilentlyContinue } catch { }

    if (-not $tray) {
        $trayExe = Find-Tailscale 'tailscale-ipn.exe'
        if ($trayExe) {
            Note 'the Tailscale tray app was not running, starting it'
            try {
                Start-Process -FilePath $trayExe
            } catch {
                Note ('could not start the tray app: ' + $_.Exception.Message)
                return
            }
            # It reconnected in about five seconds by hand. Give it longer than
            # that, but never enough to matter inside a five minute task.
            for ($i = 0; $i -lt 12; $i++) {
                Start-Sleep -Seconds 2
                $addr = Get-TailnetAddress
                if ($addr) { break }
            }
            if ($addr) { Note ('back on the tailnet at ' + $addr) }
            else       { Note 'still no tailnet address after starting the tray app' }
        }
    }

    # No point touching serve while the backend has no state: the command would
    # fail and we would log a misleading error every five minutes.
    if (-not $addr) { return }

    $port = Get-Setting 'conport' '8787'
    $target = 'http://127.0.0.1:' + $port

    $serve = ''
    try { $serve = (& $ts serve status 2>&1 | Out-String) } catch { }

    if ($serve -notmatch [regex]::Escape('127.0.0.1:' + $port)) {
        Note ('serve was not proxying ' + $target + ', re-applying')
        try {
            $out = (& $ts serve --bg $target 2>&1 | Out-String).Trim()
            $check = ''
            try { $check = (& $ts serve status 2>&1 | Out-String) } catch { }
            if ($check -match [regex]::Escape('127.0.0.1:' + $port)) {
                Note 'serve restored'
            } else {
                # Writing serve config can need elevation, and this task runs at
                # Limited. Say so plainly rather than retrying forever in silence.
                Note ('serve could not be restored, may need an elevated `tailscale serve --bg ' + $target + '`: ' + $out)
            }
        } catch {
            Note ('serve failed: ' + $_.Exception.Message)
        }
    }
}

# ------------------------------------------------------------------ run --

Repair-Awake
Repair-Tunnel
