/*
  Awake Console setup.

  For somebody who has just been handed Awake and has none of the pieces yet.
  A live checklist rather than a README: every row detects its own state, and
  the button next to it either does the thing or copies the exact command, so
  there is nothing to read and nothing to type.

  What it cannot do, it says plainly. Signing in to Claude, signing in to
  Tailscale and enabling HTTPS certificates all need a browser and an account
  that is not ours to hold, so those rows open the right page and then wait for
  the check to go green.

  C# 5 only.
*/

using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace AwakeApp
{
    public class ConsoleSetup : Form
    {
        static readonly Color Page = Color.FromArgb(246, 247, 249);
        static readonly Color CardBg = Color.White;
        static readonly Color Line = Color.FromArgb(226, 229, 234);
        static readonly Color Ink = Color.FromArgb(24, 28, 34);
        static readonly Color Dim = Color.FromArgb(107, 114, 128);
        static readonly Color Accent = Color.FromArgb(37, 99, 235);
        static readonly Color OkFg = Color.FromArgb(21, 115, 71);
        static readonly Color WarnFg = Color.FromArgb(180, 95, 6);
        static readonly Color BadFg = Color.FromArgb(190, 30, 30);

        readonly Settings cfg;
        float sc = 1f;
        int S(int v) { return (int)Math.Round(v * sc); }

        Font fBold, fSmall, fMono;
        Row rMachine, rClaude, rProjects, rTailscale, rHttps, rPhone;
        Label lblBusy;

        // One checklist row: a title, a status word, a detail line, and buttons.
        class Row
        {
            public Label Title, Status, Detail;
            public Button[] Buttons;
        }

        public ConsoleSetup(Settings settings)
        {
            cfg = settings;
            using (Graphics g = CreateGraphics()) sc = g.DpiX / 96f;

            Text = "Awake Console setup";
            BackColor = Page;
            ForeColor = Ink;
            Font = new Font("Segoe UI", 9f);
            FormBorderStyle = FormBorderStyle.Sizable;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(S(680), S(620));
            MinimumSize = new Size(S(560), S(420));

            fBold = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            fSmall = new Font("Segoe UI", 8.25f);
            fMono = new Font("Consolas", 8.5f);

            BuildUi();
            Recheck();
        }

        // Named BuildUi, not Build: a method called Build shadows the Build
        // class that carries the version and the embedded guide.
        void BuildUi()
        {
            // Two tabs: the live checklist, and the written guide compiled in from
            // CONSOLE-SETUP.md. The buttons sit on the form below them, so Recheck
            // and Close are reachable from either tab.
            TabControl tabs = new TabControl();
            tabs.Bounds = new Rectangle(S(10), S(10),
                                        ClientSize.Width - S(20), ClientSize.Height - S(58));
            tabs.Anchor = AnchorStyles.Top | AnchorStyles.Left
                        | AnchorStyles.Right | AnchorStyles.Bottom;
            Controls.Add(tabs);

            TabPage pgCheck = new TabPage("Checklist");
            pgCheck.BackColor = Page;
            tabs.TabPages.Add(pgCheck);

            TabPage pgGuide = new TabPage("Instructions");
            pgGuide.BackColor = Page;
            tabs.TabPages.Add(pgGuide);

            Panel body = new Panel();
            body.Dock = DockStyle.Fill;
            body.BackColor = Page;
            body.AutoScroll = true;
            pgCheck.Controls.Add(body);

            TextBox guide = new TextBox();
            guide.Multiline = true;
            guide.ReadOnly = true;
            guide.WordWrap = true;
            guide.ScrollBars = ScrollBars.Vertical;
            guide.Dock = DockStyle.Fill;
            guide.BackColor = CardBg;
            guide.ForeColor = Ink;
            guide.Font = new Font("Consolas", 9f);
            guide.BorderStyle = BorderStyle.None;
            // The build compiles the markdown file in, so this cannot drift from
            // the copy on GitHub. Newlines normalised because a TextBox only
            // breaks on CRLF.
            string text = Build.SetupGuide == null ? "" : Build.SetupGuide;
            text = text.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\n", "\r\n");
            guide.Text = text;
            guide.Select(0, 0);
            pgGuide.Controls.Add(guide);

            int m = S(16), w = body.ClientSize.Width - 2 * m - S(18), y = S(12);

            Label head = Mk(body, "Run Claude Code on this machine from your phone",
                            m, y, w, new Font("Segoe UI", 13f, FontStyle.Bold), Ink);
            head.Height = S(24);
            head.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            y += S(28);
            Label sub = Mk(body, "Work through the rows. Each one checks itself, so press Recheck after any step.",
                           m, y, w, fSmall, Dim);
            sub.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            y += S(24);

            rMachine = AddRow(body, m, ref y, w, "1  This machine",
                new string[] { "Copy my machine id", "Check again" });
            rClaude = AddRow(body, m, ref y, w, "2  Claude Code",
                new string[] { "Copy install command", "Open install page" });
            rProjects = AddRow(body, m, ref y, w, "3  Projects",
                new string[] { "Clone a repo", "Import a zip", "Open folder" });
            rTailscale = AddRow(body, m, ref y, w, "4  Tailscale",
                new string[] { "Install", "Sign in", "Fix now" });
            rHttps = AddRow(body, m, ref y, w, "5  HTTPS certificates",
                new string[] { "Open Tailscale DNS settings" });
            rPhone = AddRow(body, m, ref y, w, "6  Your phone link",
                new string[] { "Copy phone link" });

            rMachine.Buttons[0].Click += new EventHandler(CopyMachineId);
            rMachine.Buttons[1].Click += new EventHandler(CheckEnrollment);
            rClaude.Buttons[0].Click += new EventHandler(CopyClaudeInstall);
            rClaude.Buttons[1].Click += new EventHandler(OpenClaudeDocs);
            rProjects.Buttons[0].Click += new EventHandler(CloneRepo);
            rProjects.Buttons[1].Click += new EventHandler(ImportZip);
            rProjects.Buttons[2].Click += new EventHandler(OpenProjects);
            rTailscale.Buttons[0].Click += new EventHandler(InstallTailscale);
            rTailscale.Buttons[1].Click += new EventHandler(TailscaleUp);
            rTailscale.Buttons[2].Click += new EventHandler(TailscaleServe);
            rHttps.Buttons[0].Click += new EventHandler(OpenTailscaleDns);
            rPhone.Buttons[0].Click += new EventHandler(CopyPhoneLink);

            // Bottom bar, on the form rather than in a tab.
            int by = ClientSize.Height - S(40);

            lblBusy = Mk(this, "", S(16), by + S(7), ClientSize.Width - S(230), fSmall, Accent);
            lblBusy.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            Button recheck = new Button();
            recheck.Text = "Recheck";
            recheck.Bounds = new Rectangle(ClientSize.Width - S(206), by, S(90), S(30));
            recheck.FlatStyle = FlatStyle.System;
            recheck.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            recheck.Click += new EventHandler(Btn_Recheck);
            Controls.Add(recheck);

            Button close = new Button();
            close.Text = "Close";
            close.Bounds = new Rectangle(ClientSize.Width - S(110), by, S(94), S(30));
            close.FlatStyle = FlatStyle.System;
            close.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            close.Click += new EventHandler(Btn_Close);
            Controls.Add(close);
        }

        Row AddRow(Control host, int m, ref int y, int w, string title, string[] buttons)
        {
            CardPanel card = new CardPanel();
            card.Bounds = new Rectangle(m, y, w, S(78));
            card.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            card.BackColor = Page;
            card.Fill = CardBg;
            card.Border = Line;
            card.Radius = S(10);
            host.Controls.Add(card);

            Row r = new Row();
            r.Title = Mk(card, title, S(12), S(9), S(200), fBold, Ink);
            r.Status = Mk(card, "checking", S(216), S(9), w - S(230), fBold, Dim);
            r.Status.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            r.Detail = Mk(card, "", S(12), S(28), w - S(24), fSmall, Dim);
            r.Detail.Height = S(16);
            r.Detail.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            r.Buttons = new Button[buttons.Length];
            int bx = S(12);
            for (int i = 0; i < buttons.Length; i++)
            {
                Button b = new Button();
                b.Text = buttons[i];
                int bw = S(10) + TextRenderer.MeasureText(buttons[i], Font).Width + S(18);
                b.Bounds = new Rectangle(bx, S(46), bw, S(26));
                b.FlatStyle = FlatStyle.System;
                card.Controls.Add(b);
                r.Buttons[i] = b;
                bx += bw + S(8);
            }

            y += S(86);
            return r;
        }

        Label Mk(Control parent, string text, int x, int y, int w, Font f, Color c)
        {
            Label l = new Label();
            l.Text = text;
            l.Bounds = new Rectangle(x, y, w, S(18));
            l.Font = f;
            l.ForeColor = c;
            l.BackColor = Color.Transparent;
            l.AutoSize = false;
            parent.Controls.Add(l);
            return l;
        }

        void Set(Row r, string status, Color c, string detail)
        {
            r.Status.Text = status;
            r.Status.ForeColor = c;
            r.Detail.Text = detail;
        }

        void Busy(string s)
        {
            lblBusy.Text = s;
            lblBusy.Refresh();
        }

        // ------------------------------------------------------------- detection --
        void Btn_Recheck(object sender, EventArgs e) { Recheck(); }
        void Btn_Close(object sender, EventArgs e) { Close(); }

        void Recheck()
        {
            Busy("checking...");
            Cursor = Cursors.WaitCursor;
            try
            {
                CheckMachine();
                CheckClaude();
                CheckProjects();
                CheckTailscale();
                CheckPhone();
            }
            finally
            {
                Cursor = Cursors.Default;
                Busy("");
            }
        }

        void CheckMachine()
        {
            string id = Exclusive.MachineId();
            if (id == null)
            {
                Set(rMachine, "cannot read", BadFg, "Windows did not return a machine id.");
                return;
            }
            if (Exclusive.Allowed())
                Set(rMachine, "enabled", OkFg, "Console is enabled on this machine. Id " + id.Substring(0, 16) + "...");
            else
                Set(rMachine, "not enabled yet", WarnFg,
                    "Send this id to Alejandro to be added, then press Check again. Id " + id.Substring(0, 16) + "...");
        }

        void CheckClaude()
        {
            string exe = Chat.FindClaude();
            if (exe == null)
                Set(rClaude, "not found", BadFg,
                    "Install Claude Code, then sign in by running claude once. Needs a Pro, Max, Team, Enterprise or Console plan.");
            else
                Set(rClaude, "found", OkFg,
                    exe + "   (sign in by running claude once, if you have not)");
        }

        void CheckProjects()
        {
            string root = ConsoleServer.ProjectsRoot();
            int n = 0;
            try { if (Directory.Exists(root)) n = Directory.GetDirectories(root).Length; }
            catch { }
            if (n == 0)
                Set(rProjects, "empty", WarnFg,
                    "No projects in " + root + ". Clone a repo or import a zip to get started.");
            else
                Set(rProjects, n + (n == 1 ? " project" : " projects"), OkFg, root);
        }

        void CheckTailscale()
        {
            int st = ConsoleServer.TailnetState();

            if (st == ConsoleServer.TsMissing)
            {
                Set(rTailscale, "not installed", BadFg,
                    "Without it, Console only works on this machine. Press Install.");
                Set(rHttps, "waiting", Dim, "Install and sign in to Tailscale first.");
                return;
            }

            if (st == ConsoleServer.TsOffline)
            {
                // Distinct from "not serving" on purpose. This is the state that
                // reads as healthy everywhere else: the service runs, the adapter
                // is up, and the machine is simply not on the tailnet. Start
                // serving cannot fix it, so do not suggest it.
                Set(rTailscale, "not connected", BadFg,
                    "Tailscale is installed but this machine is not on the tailnet. Press Fix now.");
                Set(rHttps, "waiting", Dim, "Connect to the tailnet first.");
                return;
            }

            if (st == ConsoleServer.TsNotServing)
            {
                Set(rTailscale, "connected, not serving", WarnFg,
                    "On the tailnet as " + ConsoleServer.TailnetSelf() +
                    ", but nothing is proxying the port yet. Press Fix now.");
                Set(rHttps, "check", WarnFg,
                    "Serving needs HTTPS certificates enabled for your tailnet. Enable it on the DNS page.");
                return;
            }

            Set(rTailscale, "serving", OkFg, ConsoleServer.TailnetHost());
            Set(rHttps, "enabled", OkFg, "A certificate was issued, so HTTPS is on.");
        }

        void CheckPhone()
        {
            if (!ConsoleServer.Running)
            {
                Set(rPhone, "console is off", WarnFg,
                    "Turn Console on in the Awake window, then recheck.");
                return;
            }
            string host = ConsoleServer.TailnetHost();
            if (string.IsNullOrEmpty(host))
            {
                Set(rPhone, "this machine only", WarnFg,
                    "Finish Tailscale above to get a link that works on a phone.");
                return;
            }
            Set(rPhone, "ready", OkFg,
                "https://" + host + "   Copy it, open it once on your phone, and you are paired.");
        }

        // --------------------------------------------------------------- actions --
        void CopyMachineId(object sender, EventArgs e)
        {
            string id = Exclusive.MachineId();
            if (id == null) return;
            Copy(id, "machine id copied");
        }

        void CheckEnrollment(object sender, EventArgs e)
        {
            Busy("checking the enrollment list...");
            Cursor = Cursors.WaitCursor;
            bool allowed;
            try { allowed = Exclusive.Refresh(); }
            finally { Cursor = Cursors.Default; Busy(""); }

            if (allowed)
                MessageBox.Show(this,
                    "This machine is enabled. Restart Awake to pick up the Console card.",
                    "Awake Console", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(this,
                    "Not on the list yet. Send your machine id over and try again in a minute.",
                    "Awake Console", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Recheck();
        }

        void CopyClaudeInstall(object sender, EventArgs e)
        {
            // The documented native installer for Windows PowerShell.
            Copy("irm https://claude.ai/install.ps1 | iex",
                 "install command copied, paste it into PowerShell");
        }

        void OpenClaudeDocs(object sender, EventArgs e)
        {
            Open("https://code.claude.com/docs/en/setup");
        }

        void OpenProjects(object sender, EventArgs e)
        {
            string root = ConsoleServer.ProjectsRoot();
            try
            {
                Directory.CreateDirectory(root);
                Process.Start("explorer.exe", "\"" + root + "\"");
            }
            catch (Exception ex) { Oops(ex.Message); }
        }

        void CloneRepo(object sender, EventArgs e)
        {
            string url = Prompt("Clone a repository",
                "Paste a git URL. It will be cloned into " + ConsoleServer.ProjectsRoot() + ".",
                "https://github.com/user/repo.git");
            if (string.IsNullOrEmpty(url)) return;

            string git = Which("git.exe");
            if (git == null)
            {
                Oops("Git is not installed. Install Git for Windows, then try again.");
                Open("https://git-scm.com/downloads/win");
                return;
            }

            string root = ConsoleServer.ProjectsRoot();
            Busy("cloning...");
            Cursor = Cursors.WaitCursor;
            try
            {
                Directory.CreateDirectory(root);
                ProcessStartInfo psi = new ProcessStartInfo(git, "clone --depth 1 " + Quote(url));
                psi.WorkingDirectory = root;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardError = true;
                psi.RedirectStandardOutput = true;
                Process p = Process.Start(psi);
                string err = p.StandardError.ReadToEnd();
                p.StandardOutput.ReadToEnd();
                p.WaitForExit(180000);
                if (p.ExitCode != 0) Oops("git clone failed:\n\n" + Tail(err));
                else Info("Cloned into " + root + ".");
            }
            catch (Exception ex) { Oops(ex.Message); }
            finally { Cursor = Cursors.Default; Busy(""); ConsoleServer.Rescan(); Recheck(); }
        }

        void ImportZip(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Title = "Pick a zip to import as a project";
            d.Filter = "Zip archives|*.zip";
            if (d.ShowDialog(this) != DialogResult.OK) return;

            string root = ConsoleServer.ProjectsRoot();
            string name = Path.GetFileNameWithoutExtension(d.FileName);
            string dest = Path.Combine(root, name);

            Busy("extracting...");
            Cursor = Cursors.WaitCursor;
            try
            {
                Directory.CreateDirectory(root);
                if (Directory.Exists(dest))
                {
                    // Never write into an existing project folder.
                    dest = dest + "-" + DateTime.Now.ToString("yyyyMMdd-HHmmss",
                                                               CultureInfo.InvariantCulture);
                }
                System.IO.Compression.ZipFile.ExtractToDirectory(d.FileName, dest);
                Info("Extracted into " + dest + ".");
            }
            catch (Exception ex) { Oops(ex.Message); }
            finally { Cursor = Cursors.Default; Busy(""); ConsoleServer.Rescan(); Recheck(); }
        }

        void InstallTailscale(object sender, EventArgs e)
        {
            if (Which("winget.exe") == null)
            {
                Oops("winget is not available. Download Tailscale from the website instead.");
                Open("https://tailscale.com/download/windows");
                return;
            }
            if (MessageBox.Show(this,
                    "Install Tailscale with winget?\n\nWindows will ask for permission.",
                    "Awake Console", MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Question) != DialogResult.OK) return;

            Busy("installing Tailscale, this takes a minute...");
            Cursor = Cursors.WaitCursor;
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("winget.exe",
                    "install --id Tailscale.Tailscale --exact " +
                    "--accept-package-agreements --accept-source-agreements");
                psi.UseShellExecute = true;      // let it elevate on its own
                Process p = Process.Start(psi);
                if (p != null) p.WaitForExit(600000);
                Info("Installer finished. Press Sign in next.");
            }
            catch (Exception ex) { Oops(ex.Message); }
            finally { Cursor = Cursors.Default; Busy(""); Recheck(); }
        }

        void TailscaleUp(object sender, EventArgs e)
        {
            string ts = Tailscale();
            if (ts == null) { Oops("Tailscale is not installed yet."); return; }
            try
            {
                // Opens a browser for the account login. Nothing for us to hold.
                ProcessStartInfo psi = new ProcessStartInfo(ts, "up");
                psi.UseShellExecute = true;
                Process.Start(psi);
                Info("A browser will open. Sign in, then press Recheck.");
            }
            catch (Exception ex) { Oops(ex.Message); }
        }

        void TailscaleServe(object sender, EventArgs e)
        {
            string ts = Tailscale();
            if (ts == null) { Oops("Tailscale is not installed yet."); return; }
            if (!ConsoleServer.Running)
            {
                Oops("Turn Console on in the Awake window first, so there is something to serve.");
                return;
            }

            // The tunnel goes down for two very different reasons and serve only
            // fixes one of them. Deal with the other first: a backend with no
            // profile, which is what a missing tray app looks like from here, and
            // which no amount of serving will repair.
            ConsoleServer.TailnetForget();
            if (ConsoleServer.TailnetState() == ConsoleServer.TsOffline)
            {
                Busy("reconnecting Tailscale...");
                Cursor = Cursors.WaitCursor;
                string rerr = null;
                try { rerr = ConsoleServer.RepairTunnel(); }
                finally { Cursor = Cursors.Default; }

                Recheck();
                if (rerr == null) { Info("Reconnected. Your phone link is ready."); return; }
                if (ConsoleServer.TailnetState() == ConsoleServer.TsOffline) { Oops(rerr); return; }
                // Back on the tailnet but still not serving, so carry on below.
            }

            Busy("starting the tailnet proxy...");
            Cursor = Cursors.WaitCursor;
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(ts,
                    "serve --bg http://127.0.0.1:" +
                    ConsoleServer.Port.ToString(CultureInfo.InvariantCulture));
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                Process p = Process.Start(psi);
                string so = p.StandardOutput.ReadToEnd();
                string se = p.StandardError.ReadToEnd();
                if (!p.WaitForExit(60000)) { try { p.Kill(); } catch { } }

                string all = (so + " " + se);
                if (all.IndexOf("does not support getting TLS certs",
                                StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    Oops("Your tailnet does not have HTTPS certificates enabled yet.\n\n" +
                         "Enable it on the DNS page (row 5), then press Fix now again.");
                    Open("https://login.tailscale.com/admin/dns");
                }
                else if (p.ExitCode != 0 && all.Trim().Length > 0)
                {
                    Oops("Tailscale said:\n\n" + Tail(all));
                }
                else
                {
                    Info("Serving. Row 6 now has the link for your phone.");
                }
            }
            catch (Exception ex) { Oops(ex.Message); }
            finally { Cursor = Cursors.Default; Busy(""); Recheck(); }
        }

        void OpenTailscaleDns(object sender, EventArgs e)
        {
            Open("https://login.tailscale.com/admin/dns");
        }

        void CopyPhoneLink(object sender, EventArgs e)
        {
            if (!ConsoleServer.Running) { Oops("Turn Console on first."); return; }
            Copy(ConsoleServer.PhoneUrl(), "link copied, open it once on your phone");
        }

        // -------------------------------------------------------------- plumbing --
        static string Tailscale()
        {
            string[] guesses = new string[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                             "Tailscale\\tailscale.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                             "Tailscale\\tailscale.exe")
            };
            foreach (string g in guesses) { try { if (File.Exists(g)) return g; } catch { } }
            return Which("tailscale.exe");
        }

        static string Which(string exe)
        {
            string pathVar = Environment.GetEnvironmentVariable("PATH");
            if (string.IsNullOrEmpty(pathVar)) return null;
            foreach (string part in pathVar.Split(';'))
            {
                if (part.Trim().Length == 0) continue;
                try
                {
                    string cand = Path.Combine(part.Trim(), exe);
                    if (File.Exists(cand)) return cand;
                }
                catch { }
            }
            return null;
        }

        static string Quote(string s) { return "\"" + s.Replace("\"", "") + "\""; }

        static string Tail(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            s = s.Trim();
            return s.Length > 600 ? s.Substring(s.Length - 600) : s;
        }

        void Copy(string text, string note)
        {
            try { Clipboard.SetText(text); Busy(note); }
            catch (Exception ex) { Oops(ex.Message); }
        }

        void Open(string url)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(url);
                psi.UseShellExecute = true;
                Process.Start(psi);
            }
            catch (Exception ex) { Oops(ex.Message); }
        }

        void Info(string s)
        {
            MessageBox.Show(this, s, "Awake Console",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        void Oops(string s)
        {
            MessageBox.Show(this, s, "Awake Console",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        // A one line input box, because WinForms has no InputBox and pulling in
        // VisualBasic just for one would be silly.
        string Prompt(string title, string message, string placeholder)
        {
            Form f = new Form();
            f.Text = title;
            f.BackColor = Page;
            f.Font = Font;
            f.FormBorderStyle = FormBorderStyle.FixedDialog;
            f.MinimizeBox = false;
            f.MaximizeBox = false;
            f.StartPosition = FormStartPosition.CenterParent;
            f.ClientSize = new Size(S(520), S(132));

            Label l = new Label();
            l.Text = message;
            l.Bounds = new Rectangle(S(14), S(12), S(492), S(34));
            l.ForeColor = Dim;
            f.Controls.Add(l);

            TextBox t = new TextBox();
            t.Bounds = new Rectangle(S(14), S(52), S(492), S(24));
            t.BorderStyle = BorderStyle.FixedSingle;
            t.Text = placeholder;
            f.Controls.Add(t);

            Button ok = new Button();
            ok.Text = "OK";
            ok.Bounds = new Rectangle(S(320), S(90), S(88), S(28));
            ok.FlatStyle = FlatStyle.System;
            ok.DialogResult = DialogResult.OK;
            f.Controls.Add(ok);

            Button cancel = new Button();
            cancel.Text = "Cancel";
            cancel.Bounds = new Rectangle(S(418), S(90), S(88), S(28));
            cancel.FlatStyle = FlatStyle.System;
            cancel.DialogResult = DialogResult.Cancel;
            f.Controls.Add(cancel);

            f.AcceptButton = ok;
            f.CancelButton = cancel;
            t.SelectAll();

            string result = null;
            if (f.ShowDialog(this) == DialogResult.OK)
            {
                string v = t.Text.Trim();
                if (v.Length > 0 && v != placeholder) result = v;
            }
            f.Dispose();
            return result;
        }
    }
}
