<#
  Awake, hosted.

  Smart App Control blocks unsigned .exe files outright, and once it is on you
  cannot turn it back on after turning it off, so disabling it is a one way
  door. There is nothing to allowlist either: SAC has no per app exception.

  So this runs the identical app without ever putting an exe on disk. PowerShell
  itself is signed by Microsoft, and Add-Type compiles the same C# in process,
  which SAC permits. Same window, same tray icon, same verification.

  Bonus: updates get simpler. There is no locked exe to swap, only text files.

    powershell -ExecutionPolicy Bypass -File AwakeHost.ps1
    powershell -WindowStyle Hidden -ExecutionPolicy Bypass -File AwakeHost.ps1 -tray
#>
param(
    [switch]$tray,
    # Set by the updater: wait for the outgoing instance to exit before we claim
    # the single instance mutex, otherwise the new copy just reports "already
    # running" and quits, leaving nothing running at all.
    [int]$waitFor = 0
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

# Windows PowerShell is STA, which WinForms requires. pwsh 7 is MTA and would
# give a dead window, so refuse rather than misbehave.
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    throw "Awake must run under Windows PowerShell (STA), not pwsh. Use powershell.exe."
}

$names   = @('Awake.cs', 'Updater.cs', 'Console.cs', 'ConsoleServer.cs', 'ConsoleUi.cs',
             'ConsoleSetup.cs', 'ConsoleUsage.cs', 'Generated.cs')
$sources = $names | ForEach-Object { Join-Path $root $_ }

# Self-heal a partial install rather than die on it.
#
# Updaters before 1.2.4 copied only four source files, so a hosted copy that
# updated from an older build ends up with a new Awake.cs and no Console*.cs.
# Compiling then fails and the app never starts again, silently, which is the
# worst possible outcome for something meant to run unattended. So if anything
# is missing, fetch the matching source zip from the public channel and fill in
# the gaps.
$missing = $names | Where-Object { -not (Test-Path (Join-Path $root $_)) }
if ($missing) {
    Write-Host "repairing a partial install, missing: $($missing -join ', ')"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $channel = 'https://raw.githubusercontent.com/AlejandroBWJ/desktop-tools/main/'
        $manifest = (New-Object Net.WebClient).DownloadString($channel + 'version.json') | ConvertFrom-Json
        $zipName = $manifest.winsrc_file
        if (-not $zipName) { throw 'the manifest names no source zip' }

        $tmp = Join-Path $env:TEMP ('awake-repair-' + [Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Force $tmp | Out-Null
        $zip = Join-Path $tmp 'src.zip'
        (New-Object Net.WebClient).DownloadFile($channel + $zipName, $zip)
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::ExtractToDirectory($zip, (Join-Path $tmp 'src'))

        foreach ($m in $missing) {
            $from = Join-Path (Join-Path $tmp 'src') $m
            if (-not (Test-Path $from)) { throw "$zipName does not contain $m" }
            Copy-Item $from (Join-Path $root $m) -Force
        }
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "repaired from $zipName"
    } catch {
        Add-Type -AssemblyName System.Windows.Forms
        [Windows.Forms.MessageBox]::Show(
            "Awake is missing part of its install and could not repair itself:`n`n" +
            "$($missing -join ', ')`n`n$($_.Exception.Message)`n`n" +
            "Download Awake again from the link in the README to fix it.",
            'Awake') | Out-Null
        return
    }
}

Add-Type -Path $sources -ReferencedAssemblies 'System.dll',
                                              'System.Drawing.dll',
                                              'System.Windows.Forms.dll',
                                              'System.IO.Compression.dll',
                                              'System.IO.Compression.FileSystem.dll',
                                              'System.Web.Extensions.dll'

if ($waitFor -gt 0) {
    try { (Get-Process -Id $waitFor -ErrorAction Stop).WaitForExit(30000) | Out-Null } catch { }
}

# Before anything creates a window. Windows PowerShell is DPI unaware, so
# without this the app is laid out at 96 DPI and then stretched by the OS, which
# looks blurry on a scaled display. The exe gets this from app.manifest instead.
[AwakeApp.Native]::MakeDpiAware()

# Tell the app it is hosted, so the updater swaps source files instead of trying
# to replace an exe that does not exist.
[AwakeApp.Host]::Scripted = $true
[AwakeApp.Host]::Root = $root

# One instance only, same as the exe build.
$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\AwakeAppSingleInstance', [ref]$created)
if (-not $created) {
    [System.Windows.Forms.MessageBox]::Show(
        'Awake is already running. Look for the dot in the notification area.',
        'Awake') | Out-Null
    return
}

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

$form = New-Object AwakeApp.MainForm($tray.IsPresent)
[System.Windows.Forms.Application]::Run($form)

$mutex.ReleaseMutex()
