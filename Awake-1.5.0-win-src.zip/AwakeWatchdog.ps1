<#
  Awake watchdog.

  Awake starts from the Run key, which fires once, at logon. That is fine for a
  desktop utility and useless for something meant to answer a phone for days: if
  the process ever dies there is nothing to notice, and the machine it is
  supposed to be reachable on is the one place you cannot get to.

  A scheduled task runs this every few minutes. It checks the single instance
  mutex rather than looking for a process name, because the app runs hosted
  inside powershell.exe and is indistinguishable from any other by name. If the
  mutex is gone, nothing is running, so it starts one.

  Checking the mutex also avoids the failure this would otherwise have: launching
  AwakeHost.ps1 while a copy is already up puts a "Awake is already running"
  dialog on screen, and a watchdog that does that every five minutes is worse
  than no watchdog at all.

  Needs no administrator rights and touches nothing outside the user profile.
#>

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$host_ = Join-Path $root 'AwakeHost.ps1'
$logFile = Join-Path $root 'watchdog.log'

function Note($msg) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  ' + $msg
    try {
        # Keep it small. This runs every few minutes forever.
        if ((Test-Path $logFile) -and (Get-Item $logFile).Length -gt 200KB) {
            $keep = Get-Content $logFile -Tail 200
            Set-Content $logFile $keep -Encoding utf8
        }
        Add-Content $logFile $line -Encoding utf8
    } catch { }
}

if (-not (Test-Path $host_)) { Note "AwakeHost.ps1 is missing, cannot start"; exit 1 }

# Is a copy already up?
$mutex = $null
$running = $false
try {
    $running = [System.Threading.Mutex]::TryOpenExisting('Local\AwakeAppSingleInstance', [ref]$mutex)
} catch {
    $running = $false
}
if ($mutex) { try { $mutex.Dispose() } catch { } }

if ($running) { exit 0 }

# Nothing running. Start it the same way the Run key does.
Note 'Awake was not running, starting it'
try {
    Start-Process -FilePath 'powershell.exe' `
        -ArgumentList '-NoProfile', '-WindowStyle', 'Hidden', '-ExecutionPolicy', 'Bypass',
                      '-File', $host_, '-tray' `
        -WindowStyle Hidden
    Note 'started'
} catch {
    Note ("could not start it: " + $_.Exception.Message)
    exit 1
}
