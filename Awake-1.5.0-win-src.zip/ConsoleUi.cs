/*
  Awake Console, the phone client.

  The page itself now lives in console.html at the repo root, and build.ps1
  compiles it into Generated.cs. The macOS port embeds the very same file from
  mac/build.sh, so there is one client for both platforms and no way for them to
  drift apart. Before this it was a 28 KB C# string literal, and porting to Swift
  would have meant a second copy of it.

  Notes that belong with the page rather than the build, kept here because this
  is where anybody looking for the client will start:

  - The page is written entirely with single quotes. That was originally so it
    could sit in a C# verbatim string without escaping every attribute, and it
    stays that way because build.ps1 still wraps it in one.
  - Back navigation restores a page from the bfcache with the DOM intact and no
    script re-run, so the stream is reopened on pageshow+persisted rather than
    left frozen.
  - Wide content scrolls inside its own box. Setting one overflow axis forces
    the other to auto, which is how a page ends up scrolling sideways by
    accident, so the body pins overflow-x.
  - Streaming redraw is debounced with setTimeout, not requestAnimationFrame,
    because rAF stalls in a backgrounded tab and the transcript would freeze
    mid-answer.
*/

namespace AwakeApp
{
    public static class ConsoleUi
    {
        public static string Page
        {
            get
            {
                string p = Build.ConsolePage;
                // A build that somehow lost the asset should say so plainly
                // rather than serve a blank page to a phone.
                if (string.IsNullOrEmpty(p))
                    return "<!doctype html><title>Awake Console</title>"
                         + "<p>This build is missing console.html.";
                return p;
            }
        }
    }
}
