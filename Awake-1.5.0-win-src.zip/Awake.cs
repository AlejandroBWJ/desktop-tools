﻿// Awake - keeps this Windows session counted as active, and proves it.
//
// Injects real OS level input (1 px mouse move + F15) through SendInput on a
// randomised interval, holds a display/system power request so the screen can
// never blank, and shows the system idle clock live so you can see it working.
//
// Build: see build.ps1 (uses the C# compiler that ships with Windows).

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace AwakeApp
{
    // ------------------------------------------------------------- interop --
    public static class Native
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
        [StructLayout(LayoutKind.Sequential)]
        public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
        [StructLayout(LayoutKind.Sequential)]
        public struct HARDWAREINPUT { public uint uMsg; public ushort wParamL; public ushort wParamH; }
        [StructLayout(LayoutKind.Explicit)]
        public struct INPUTUNION
        {
            [FieldOffset(0)] public MOUSEINPUT mi;
            [FieldOffset(0)] public KEYBDINPUT ki;
            [FieldOffset(0)] public HARDWAREINPUT hi;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct INPUT { public uint type; public INPUTUNION u; }

        const uint INPUT_MOUSE = 0;
        const uint INPUT_KEYBOARD = 1;
        const uint MOUSEEVENTF_MOVE = 0x0001;
        const uint MOUSEEVENTF_MOVE_NOCOALESCE = 0x2000;
        const uint KEYEVENTF_KEYUP = 0x0002;

        public const ushort VK_F15 = 0x7E;

        [DllImport("user32.dll", SetLastError = true)]
        static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [StructLayout(LayoutKind.Sequential)]
        struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
        [DllImport("kernel32.dll")]
        static extern uint GetTickCount();
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern uint SetThreadExecutionState(uint esFlags);

        public static int LastError;

        // Seconds since the last input event, real or injected, straight from Windows.
        // This is the exact clock Teams and the power subsystem look at.
        public static double IdleSeconds()
        {
            LASTINPUTINFO lii = new LASTINPUTINFO();
            lii.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
            if (!GetLastInputInfo(ref lii)) return -1;
            return (double)(GetTickCount() - lii.dwTime) / 1000.0;
        }

        // One pixel right, one pixel back. NOCOALESCE stops Windows and Chromium
        // from merging the pair into nothing. Returns events accepted (want 2).
        public static uint Jiggle()
        {
            INPUT[] inp = new INPUT[2];
            inp[0].type = INPUT_MOUSE;
            inp[0].u.mi.dx = 1;
            inp[0].u.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_MOVE_NOCOALESCE;
            inp[1].type = INPUT_MOUSE;
            inp[1].u.mi.dx = -1;
            inp[1].u.mi.dwFlags = MOUSEEVENTF_MOVE | MOUSEEVENTF_MOVE_NOCOALESCE;
            uint sent = SendInput(2, inp, Marshal.SizeOf(typeof(INPUT)));
            LastError = Marshal.GetLastWin32Error();
            return sent;
        }

        public static uint Key(ushort vk)
        {
            INPUT[] inp = new INPUT[2];
            inp[0].type = INPUT_KEYBOARD;
            inp[0].u.ki.wVk = vk;
            inp[1].type = INPUT_KEYBOARD;
            inp[1].u.ki.wVk = vk;
            inp[1].u.ki.dwFlags = KEYEVENTF_KEYUP;
            uint sent = SendInput(2, inp, Marshal.SizeOf(typeof(INPUT)));
            LastError = Marshal.GetLastWin32Error();
            return sent;
        }

        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        // The exe gets DPI awareness from app.manifest. When the app runs hosted
        // inside powershell.exe there is no such manifest, and Windows PowerShell
        // is DPI unaware, so it reports 96 DPI, the layout is built at 100% and
        // Windows then stretches the window, which looks blurry at 150% scaling.
        // Declaring it here fixes that, but ONLY if called before any window
        // exists, which is why the host script calls it first thing.
        public static void MakeDpiAware()
        {
            try { SetProcessDPIAware(); }
            catch { }
        }

        // ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
        public static void StayAwake() { SetThreadExecutionState(0x80000000u | 0x1u | 0x2u); }
        public static void ReleaseAwake() { SetThreadExecutionState(0x80000000u); }

        // LogonUI.exe only exists while the lock screen is up.
        public static bool ScreenLocked()
        {
            try { return Process.GetProcessesByName("LogonUI").Length > 0; }
            catch { return false; }
        }

        public static Process Teams()
        {
            try
            {
                Process[] a = Process.GetProcessesByName("ms-teams");
                if (a.Length == 0) a = Process.GetProcessesByName("Teams");
                if (a.Length == 0) return null;
                return a[0];
            }
            catch { return null; }
        }

        public static bool IsElevated()
        {
            try
            {
                System.Security.Principal.WindowsIdentity id = System.Security.Principal.WindowsIdentity.GetCurrent();
                System.Security.Principal.WindowsPrincipal p = new System.Security.Principal.WindowsPrincipal(id);
                return p.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }
    }

    // ------------------------------------------------------------ settings --
    public class Settings
    {
        public bool AllDay = false;
        public string Start = "10:00";
        public string Stop = "16:30";
        public int MinSec = 50;
        public int MaxSec = 95;
        public bool StartMinimized = false;
        // Monday first. Default to the working week.
        public bool[] Days = new bool[] { true, true, true, true, true, false, false };
        // Console: serve local Claude Code to a phone. Off until asked for.
        public bool ConsoleOn = false;
        public int ConsolePort = 8787;
        // Where project folders live. Empty means work it out at runtime.
        public string ProjectsRoot = "";

        public static string Dir()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Awake");
        }
        static string FilePath() { return Path.Combine(Dir(), "settings.ini"); }

        public static Settings Load()
        {
            Settings s = new Settings();
            try
            {
                string f = FilePath();
                if (!File.Exists(f)) return s;
                string[] lines = File.ReadAllLines(f);
                for (int i = 0; i < lines.Length; i++)
                {
                    int e = lines[i].IndexOf('=');
                    if (e <= 0) continue;
                    string k = lines[i].Substring(0, e).Trim();
                    string v = lines[i].Substring(e + 1).Trim();
                    if (k == "allday") s.AllDay = (v == "1");
                    else if (k == "start") s.Start = v;
                    else if (k == "stop") s.Stop = v;
                    else if (k == "min") int.TryParse(v, out s.MinSec);
                    else if (k == "max") int.TryParse(v, out s.MaxSec);
                    else if (k == "minimized") s.StartMinimized = (v == "1");
                    else if (k == "console") s.ConsoleOn = (v == "1");
                    else if (k == "conport") int.TryParse(v, out s.ConsolePort);
                    else if (k == "projects") s.ProjectsRoot = v;
                    else if (k == "days" && v.Length == 7)
                    {
                        for (int d = 0; d < 7; d++) s.Days[d] = (v[d] == '1');
                    }
                }
            }
            catch { }
            if (s.MinSec < 5) s.MinSec = 5;
            if (s.MaxSec < s.MinSec) s.MaxSec = s.MinSec + 10;
            if (s.ConsolePort < 1024 || s.ConsolePort > 65535) s.ConsolePort = 8787;
            return s;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Dir());
                System.Text.StringBuilder d = new System.Text.StringBuilder();
                for (int i = 0; i < 7; i++) d.Append(Days[i] ? '1' : '0');
                string[] o = new string[10];
                o[0] = "allday=" + (AllDay ? "1" : "0");
                o[1] = "start=" + Start;
                o[2] = "stop=" + Stop;
                o[3] = "min=" + MinSec;
                o[4] = "max=" + MaxSec;
                o[5] = "minimized=" + (StartMinimized ? "1" : "0");
                o[6] = "days=" + d.ToString();
                o[7] = "console=" + (ConsoleOn ? "1" : "0");
                o[8] = "conport=" + ConsolePort;
                o[9] = "projects=" + ProjectsRoot;
                File.WriteAllLines(FilePath(), o);
            }
            catch { }
        }
    }

    // --------------------------------------------------------------- chrome --
    public static class Ui
    {
        public static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            GraphicsPath p = new GraphicsPath();
            int d = radius * 2;
            if (d <= 0 || r.Width <= d || r.Height <= d) { p.AddRectangle(r); return p; }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    // A rounded panel. BackColor is the colour showing THROUGH the rounded
    // corners, so it is set to the page colour; Fill is the card itself.
    public class CardPanel : Panel
    {
        public Color Fill = Color.White;
        public Color Border = Color.FromArgb(226, 229, 234);
        public int Radius = 10;

        public CardPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint
                     | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(BackColor);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle r = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath gp = Ui.RoundRect(r, Radius))
            {
                using (SolidBrush b = new SolidBrush(Fill)) e.Graphics.FillPath(b, gp);
                using (Pen pen = new Pen(Border)) e.Graphics.DrawPath(pen, gp);
            }
        }
    }

    // ----------------------------------------------------------- main form --
    public class MainForm : Form
    {
        const string RunKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";
        const string RunName = "Awake";
        const int MaxSamples = 150;          // 150 x 2 s = 5 minutes of history
        const double AwayThreshold = 300.0;  // Teams flips to Away at 5 minutes idle

        static readonly Color Page = Color.FromArgb(246, 247, 249);
        static readonly Color CardBg = Color.White;
        static readonly Color Line = Color.FromArgb(226, 229, 234);
        static readonly Color Ink = Color.FromArgb(24, 28, 34);
        static readonly Color Dim = Color.FromArgb(107, 114, 128);
        static readonly Color Accent = Color.FromArgb(37, 99, 235);
        static readonly Color Good = Color.FromArgb(22, 163, 74);
        static readonly Color WarnFg = Color.FromArgb(180, 95, 6);
        static readonly Color BadFg = Color.FromArgb(190, 30, 30);
        static readonly Color OkBg = Color.FromArgb(236, 250, 240), OkFg = Color.FromArgb(21, 115, 71);
        static readonly Color BadBg = Color.FromArgb(254, 242, 242);
        static readonly Color WarnBg = Color.FromArgb(255, 251, 235);
        static readonly Color InfoBg = Color.FromArgb(239, 246, 255), InfoFg = Color.FromArgb(29, 78, 216);

        static readonly string[] DayNames = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };

        Settings cfg;
        float sc = 1f;
        Random rnd = new Random();
        System.Windows.Forms.Timer tick = new System.Windows.Forms.Timer();
        System.Windows.Forms.Timer sampler = new System.Windows.Forms.Timer();
        NotifyIcon tray;
        Icon icGreen, icAmber, icRed;

        bool userPaused = false;
        bool inWindow = true;
        bool locked = false;
        int nudges = 0;
        int flipEvents = 0;
        double longestIdle = 0;
        double prevIdle = 0;
        DateTime lastNudge = DateTime.MinValue;
        DateTime nextNudge = DateTime.MinValue;
        DateTime lastSeen = DateTime.Now;
        string health = "";
        bool healthNotified = false;
        List<double> samples = new List<double>();

        int verifyPhase = 0;
        DateTime verifyDeadline, verifyInjectAt;
        double verifyBefore = 0;
        int verifyErr = 0;
        bool verifyRefused = false;

        bool startHidden, shownOnce = false, allowExit = false, loading = true, interactive = false;

        // updates
        string updateStatus = "not checked yet";
        DateTime nextUpdateCheck = DateTime.MinValue;
        bool updateBusy = false;

        Panel pnlDot, pnlGraph;
        CardPanel pnlVerify;
        Label lblState, lblSub, lblVerifyTitle, lblVerifyBody;
        Label vIdle, vLongest, vNudges, vNext, vTeams, vElev, vScreen, vFlips;
        CheckBox chkWindowOnly;
        Panel[] dayToggles = new Panel[7];
        bool[] days = new bool[7];
        DateTimePicker dtStart, dtStop;
        NumericUpDown numMin, numMax;
        CheckBox chkStartup, chkStartMin;
        Button btnToggle, btnVerify, btnHide, btnUpdate;
        TextBox txtLog;
        Label lblUpdate;
        bool hasConsole;
        CheckBox chkConsole;
        NumericUpDown numPort;
        Button btnSetup;
        Label lblConsole, lblConsoleHint;
        TextBox txtLink;
        Button btnCopy;
        Font fBold, fTitle, fSmall, fMono, fDay, fNum;

        int S(int v) { return (int)Math.Round(v * sc); }

        public MainForm(bool hidden)
        {
            startHidden = hidden;
            cfg = Settings.Load();
            using (Graphics g = CreateGraphics()) sc = g.DpiX / 96f;
            BuildUi();
            WireEvents();
            loading = false;

            locked = Native.ScreenLocked();
            nextNudge = DateTime.Now;   // nudge straight away, do not wait a full interval
            Log("Awake " + Build.Version + " started");

            Updater.CleanStaging();                              // leftovers from a previous update
            nextUpdateCheck = DateTime.Now.AddSeconds(30);       // let the app settle first
            if (!Native.IsElevated())
                Log("not elevated: injection is refused while an elevated window has focus");

            tick.Interval = 500;
            tick.Tick += new EventHandler(OnTick);
            tick.Start();
            sampler.Interval = 2000;
            sampler.Tick += new EventHandler(OnSample);
            sampler.Start();

            SystemEvents.SessionSwitch += new SessionSwitchEventHandler(OnSessionSwitch);
            SystemEvents.PowerModeChanged += new PowerModeChangedEventHandler(OnPowerMode);
            ApplyConsole();
            UpdateUi();
        }

        // ------------------------------------------------------------- ui --
        void BuildUi()
        {
            fTitle = new Font("Segoe UI", 16f, FontStyle.Bold);
            fBold  = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            fNum   = new Font("Segoe UI", 11f, FontStyle.Bold);
            fSmall = new Font("Segoe UI", 8.25f);
            fDay   = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            fMono  = new Font("Consolas", 8.5f);

            Text = "Awake";
            Font = new Font("Segoe UI", 9f);
            BackColor = Page;
            ForeColor = Ink;
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            AutoScaleMode = AutoScaleMode.None;
            StartPosition = FormStartPosition.CenterScreen;
            // Console is built for the machines it belongs to, and for anyone who
            // has deliberately switched it on in settings.ini, which is how a new
            // machine gets far enough to read its own id and ask to be enrolled.
            // A random downloader who never touches that file still gets plain
            // Awake, at exactly the height it always had.
#if NO_CONSOLE
            hasConsole = false;
#else
            hasConsole = Exclusive.Allowed() || cfg.ConsoleOn;
#endif
            // Console card height plus the gap the other cards use.
            int co = hasConsole ? 122 : 0;

            // Width now, height at the end of this method once the controls
            // exist. The height used to be a hand maintained constant, and
            // adding the Console card pushed it past a 1080p working area, so
            // the window opened with its bottom off the screen. Measuring the
            // content instead means it cannot drift again.
            ClientSize = new Size(S(600), S(800 + co));
            // The window is resizable, and the layout is absolute, so two things
            // carry the slack: the full width controls are anchored left+right so
            // they follow the width, and AutoScroll picks up whatever is left, so
            // shrinking the window scrolls instead of clipping. That also covers
            // the Console card making the design taller than a scaled 1080p
            // desktop can show.
            AutoScroll = true;
            MinimumSize = new Size(S(560), S(420));

            icGreen = MakeDot(Good);
            icAmber = MakeDot(Color.FromArgb(217, 119, 6));
            icRed = MakeDot(Color.FromArgb(220, 38, 38));
            Icon = icGreen;

            for (int i = 0; i < 7; i++) days[i] = cfg.Days[i];

            int m = S(20);
            int w = ClientSize.Width - 2 * m;

            // ---- header ----
            pnlDot = new Panel();
            pnlDot.Bounds = new Rectangle(m, S(24), S(12), S(12));
            pnlDot.BackColor = Page;
            pnlDot.Paint += new PaintEventHandler(Dot_Paint);
            Controls.Add(pnlDot);

            lblState = Mk(this, "Active", m + S(22), S(14), S(360), fTitle, Ink);
            lblState.Height = S(28);   // 16pt bold needs more than the default row
            lblSub = Mk(this, "", m + S(22), S(46), w - S(22), fSmall, Dim);

            // ---- verification ----
            pnlVerify = (CardPanel)Card(m, S(76), w, S(64));
            lblVerifyTitle = Mk(pnlVerify, "", S(14), S(10), w - S(28), fBold, Ink);
            lblVerifyBody = Mk(pnlVerify, "", S(14), S(30), w - S(28), fSmall, Dim);
            lblVerifyBody.Height = S(32);
            SetVerify("Not verified yet",
                      "Click Verify to prove Windows accepts the injected input and resets the idle clock.",
                      CardBg, Dim);

            // ---- live numbers ----
            Panel mc = Card(m, S(152), w, S(114));
            int rh = S(26), ry = S(16);
            int l1 = S(14), v1 = S(124), l2 = S(300), v2 = S(400);
            Mk(mc, "Idle now",    l1, ry + 0 * rh, S(110), fSmall, Dim);
            Mk(mc, "Longest gap", l1, ry + 1 * rh, S(110), fSmall, Dim);
            Mk(mc, "Nudges sent", l1, ry + 2 * rh, S(110), fSmall, Dim);
            Mk(mc, "Next nudge",  l1, ry + 3 * rh, S(110), fSmall, Dim);
            vIdle    = Mk(mc, "", v1, ry + 0 * rh, S(170), fNum, Ink);
            vLongest = Mk(mc, "", v1, ry + 1 * rh, S(170), fNum, Ink);
            vNudges  = Mk(mc, "", v1, ry + 2 * rh, S(170), fNum, Ink);
            vNext    = Mk(mc, "", v1, ry + 3 * rh, S(170), fNum, Ink);
            Mk(mc, "Teams",       l2, ry + 0 * rh, S(100), fSmall, Dim);
            Mk(mc, "Screen",      l2, ry + 1 * rh, S(100), fSmall, Dim);
            Mk(mc, "Elevated",    l2, ry + 2 * rh, S(100), fSmall, Dim);
            Mk(mc, "Away events", l2, ry + 3 * rh, S(100), fSmall, Dim);
            vTeams  = Mk(mc, "", v2, ry + 0 * rh, S(140), fNum, Ink);
            vScreen = Mk(mc, "", v2, ry + 1 * rh, S(140), fNum, Ink);
            vElev   = Mk(mc, "", v2, ry + 2 * rh, S(140), fNum, Ink);
            vFlips  = Mk(mc, "", v2, ry + 3 * rh, S(140), fNum, Ink);

            // ---- graph ----
            Panel gc = Card(m, S(278), w, S(120));
            Mk(gc, "System idle time, last 5 minutes", S(14), S(10), w - S(28), fSmall, Dim);
            pnlGraph = new Panel();
            pnlGraph.Bounds = new Rectangle(S(14), S(32), w - S(28), S(86));
            pnlGraph.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            pnlGraph.BackColor = CardBg;
            pnlGraph.Paint += new PaintEventHandler(Graph_Paint);
            gc.Controls.Add(pnlGraph);

            // ---- schedule ----
            Panel sched = Card(m, S(410), w, S(134));
            Mk(sched, "Schedule", S(14), S(10), S(70), fBold, Ink);
            Mk(sched, "turns itself on for the days and hours you pick",
               S(84), S(11), S(400), fSmall, Dim);

            for (int i = 0; i < 7; i++)
            {
                Panel d = new Panel();
                d.Bounds = new Rectangle(S(14) + i * S(40), S(36), S(36), S(28));
                d.Tag = i;
                d.BackColor = CardBg;
                d.Cursor = Cursors.Hand;
                d.Paint += new PaintEventHandler(Day_Paint);
                d.Click += new EventHandler(Day_Click);
                sched.Controls.Add(d);
                dayToggles[i] = d;
            }

            chkWindowOnly = new CheckBox();
            chkWindowOnly.Text = "Only between";
            chkWindowOnly.Bounds = new Rectangle(S(14), S(76), S(120), S(22));
            chkWindowOnly.BackColor = CardBg;
            chkWindowOnly.Checked = !cfg.AllDay;
            sched.Controls.Add(chkWindowOnly);

            dtStart = MkTime(sched, cfg.Start, S(138), S(74));
            Mk(sched, "and", S(218), S(78), S(28), fSmall, Dim);
            dtStop = MkTime(sched, cfg.Stop, S(248), S(74));

            Mk(sched, "Nudge every", S(14), S(112), S(80), fSmall, Dim);
            numMin = MkNum(sched, cfg.MinSec, S(98), S(110));
            Mk(sched, "to", S(152), S(112), S(20), fSmall, Dim);
            numMax = MkNum(sched, cfg.MaxSec, S(172), S(110));
            Mk(sched, "seconds, and Teams needs under 300", S(228), S(112), S(300), fSmall, Dim);

            // ---- console ----
            if (hasConsole)
            {
                // Four rows, and the link gets one to itself. It used to share a
                // row with the buttons at a fixed width that stopped accounting
                // for them once Setup was added, so the tail of the URL sat
                // underneath the button. Status moved up to the title row, where
                // there is room for it to grow, rather than being squeezed
                // between the port box and the buttons.
                Panel con = Card(m, S(556), w, S(110));

                Mk(con, "Console", S(14), S(9), S(62), fBold, Ink);
                Mk(con, "run local Claude Code from your phone",
                   S(78), S(10), w - S(232), fSmall, Dim)
                    .Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

                lblConsole = Mk(con, "off", w - S(146), S(10), S(132), fSmall, Dim);
                lblConsole.TextAlign = ContentAlignment.TopRight;
                lblConsole.Anchor = AnchorStyles.Top | AnchorStyles.Right;

                chkConsole = new CheckBox();
                chkConsole.Text = "Serve on port";
                chkConsole.Bounds = new Rectangle(S(14), S(31), S(104), S(22));
                chkConsole.BackColor = CardBg;
                chkConsole.Checked = cfg.ConsoleOn;
                con.Controls.Add(chkConsole);

                numPort = new NumericUpDown();
                numPort.Minimum = 1024;
                numPort.Maximum = 65535;
                numPort.Value = cfg.ConsolePort;
                numPort.Bounds = new Rectangle(S(120), S(31), S(70), S(22));
                numPort.BorderStyle = BorderStyle.FixedSingle;
                con.Controls.Add(numPort);

                btnSetup = new Button();
                btnSetup.Text = "Setup...";
                btnSetup.Bounds = new Rectangle(w - S(232), S(30), S(96), S(24));
                btnSetup.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                btnSetup.FlatStyle = FlatStyle.System;
                con.Controls.Add(btnSetup);

                btnCopy = new Button();
                btnCopy.Text = "Copy link";
                btnCopy.Bounds = new Rectangle(w - S(130), S(30), S(116), S(24));
                btnCopy.Anchor = AnchorStyles.Top | AnchorStyles.Right;
                btnCopy.FlatStyle = FlatStyle.System;
                con.Controls.Add(btnCopy);

                txtLink = new TextBox();
                txtLink.ReadOnly = true;
                txtLink.BorderStyle = BorderStyle.FixedSingle;
                txtLink.Font = fMono;
                txtLink.BackColor = Page;
                txtLink.ForeColor = Dim;
                txtLink.Bounds = new Rectangle(S(14), S(60), w - S(28), S(22));
                txtLink.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                con.Controls.Add(txtLink);

                lblConsoleHint = Mk(con, "", S(14), S(87), w - S(28), fSmall, Dim);
                lblConsoleHint.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            }

            // ---- options ----
            chkStartup = new CheckBox();
            chkStartup.Text = "Start automatically when I sign in to Windows";
            chkStartup.Bounds = new Rectangle(m, S(556 + co), S(400), S(22));
            chkStartup.BackColor = Page;
            chkStartup.Checked = StartupEnabled();
            Controls.Add(chkStartup);

            chkStartMin = new CheckBox();
            chkStartMin.Text = "Start hidden in the notification area";
            chkStartMin.Bounds = new Rectangle(m, S(580 + co), S(400), S(22));
            chkStartMin.BackColor = Page;
            chkStartMin.Checked = cfg.StartMinimized;
            Controls.Add(chkStartMin);

            // ---- actions ----
            btnVerify = MkBtn("Verify now",        m,          S(612 + co), S(120), true);
            btnToggle = MkBtn("Pause",             m + S(130), S(612 + co), S(110), false);
            btnHide   = MkBtn("Hide to tray",      m + S(250), S(612 + co), S(120), false);
            btnUpdate = MkBtn("Check for updates", m + S(380), S(612 + co), S(150), false);

            // ---- activity ----
            Mk(this, "Activity", m, S(656 + co), S(56), fSmall, Dim);
            lblUpdate = Mk(this, "", m + S(60), S(656 + co), w - S(60), fSmall, Dim);
            lblUpdate.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtLog = new TextBox();
            txtLog.Multiline = true;
            txtLog.ReadOnly = true;
            txtLog.BorderStyle = BorderStyle.FixedSingle;
            txtLog.ScrollBars = ScrollBars.Vertical;
            txtLog.Font = fMono;
            txtLog.BackColor = CardBg;
            txtLog.ForeColor = Dim;
            txtLog.Bounds = new Rectangle(m, S(674 + co), w, S(68));
            txtLog.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            Controls.Add(txtLog);

            // Size the window to what is actually in it, then clamp to the
            // screen. AutoScroll covers the clamp on a short display; on a
            // normal one nothing is clamped and nothing scrolls.
            int deepest = 0;
            foreach (Control c in Controls) if (c.Bottom > deepest) deepest = c.Bottom;

            // Fit the content first. This matters because the log is anchored to
            // the bottom: whatever margin exists at this moment is the margin
            // anchoring will preserve, so setting the real content height here
            // is what stops a clamp from leaving a band of dead space under it.
            ClientSize = new Size(ClientSize.Width, deepest + S(14));

            // Then clamp to the screen, measuring the chrome from the window
            // itself. SystemInformation under-reports it by the padded border,
            // which was enough to open two pixels taller than the desktop.
            int chrome = Height - ClientSize.Height;
            int room = Screen.PrimaryScreen.WorkingArea.Height - chrome - S(8);
            if (ClientSize.Height > room)
                ClientSize = new Size(ClientSize.Width, Math.Max(S(420), room));

            tray = new NotifyIcon();
            tray.Icon = icGreen;
            tray.Text = "Awake";
            tray.Visible = true;
            ContextMenuStrip cm = new ContextMenuStrip();
            cm.Items.Add("Show Awake", null, new EventHandler(Tray_Show));
            cm.Items.Add("Verify now", null, new EventHandler(Btn_Verify));
            cm.Items.Add("Pause / resume", null, new EventHandler(Btn_Toggle));
            cm.Items.Add("Check for updates", null, new EventHandler(Btn_Update));
            cm.Items.Add(new ToolStripSeparator());
            cm.Items.Add("Quit", null, new EventHandler(Tray_Quit));
            tray.ContextMenuStrip = cm;
            tray.DoubleClick += new EventHandler(Tray_Show);
        }

        Panel Card(int x, int y, int w, int h)
        {
            CardPanel c = new CardPanel();
            c.Bounds = new Rectangle(x, y, w, h);
            // Every card spans the window, so they all follow its width.
            c.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            c.BackColor = Page;
            c.Fill = CardBg;
            c.Border = Line;
            c.Radius = S(10);
            Controls.Add(c);
            return c;
        }

        void Day_Paint(object sender, PaintEventArgs e)
        {
            Panel d = (Panel)sender;
            int i = (int)d.Tag;
            bool on = days[i];
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle r = new Rectangle(0, 0, d.Width - S(4) - 1, d.Height - 1);
            using (GraphicsPath gp = Ui.RoundRect(r, S(7)))
            {
                using (SolidBrush b = new SolidBrush(on ? Accent : CardBg)) g.FillPath(b, gp);
                using (Pen pen = new Pen(on ? Accent : Line)) g.DrawPath(pen, gp);
            }
            TextRenderer.DrawText(g, DayNames[i].Substring(0, 2), fDay, r,
                                  on ? Color.White : Dim,
                                  TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        void Day_Click(object sender, EventArgs e)
        {
            Panel d = (Panel)sender;
            int i = (int)d.Tag;
            days[i] = !days[i];
            d.Invalidate();
            Cfg_Changed(sender, e);
            Log("schedule: " + DaysText());
            if (days[i]) nextNudge = DateTime.Now;
        }

        // A Label with a transparent background shows its PARENT's colour, not the
        // colour of the panel it happens to sit on, so a label inside a white card
        // has to be told it is on white.
        Label Mk(Control parent, string text, int x, int y, int w, Font f, Color c)
        {
            Label l = new Label();
            l.Text = text;
            l.Bounds = new Rectangle(x, y, w, S(20));
            l.Font = f;
            l.ForeColor = c;
            l.BackColor = (parent is CardPanel) ? CardBg : Page;
            parent.Controls.Add(l);
            return l;
        }

        Button MkBtn(string text, int x, int y, int w, bool primary)
        {
            Button b = new Button();
            b.Text = text;
            b.Bounds = new Rectangle(x, y, w, S(32));
            b.FlatStyle = FlatStyle.Flat;
            b.Font = Font;
            b.UseVisualStyleBackColor = false;
            b.BackColor = primary ? Accent : CardBg;
            b.ForeColor = primary ? Color.White : Ink;
            b.FlatAppearance.BorderColor = primary ? Accent : Line;
            b.FlatAppearance.BorderSize = 1;
            b.FlatAppearance.MouseOverBackColor = primary
                ? Color.FromArgb(29, 78, 216) : Color.FromArgb(243, 244, 246);
            b.FlatAppearance.MouseDownBackColor = primary
                ? Color.FromArgb(30, 64, 175) : Color.FromArgb(229, 231, 235);
            using (GraphicsPath gp = Ui.RoundRect(new Rectangle(0, 0, w, S(32)), S(8)))
                b.Region = new Region(gp);
            Controls.Add(b);
            return b;
        }

        DateTimePicker MkTime(Control parent, string hhmm, int x, int y)
        {
            DateTimePicker d = new DateTimePicker();
            d.Format = DateTimePickerFormat.Custom;
            d.CustomFormat = "HH:mm";
            d.ShowUpDown = true;
            d.Bounds = new Rectangle(x, y, S(74), S(24));
            TimeSpan t;
            if (!TimeSpan.TryParse(hhmm, out t)) t = new TimeSpan(10, 0, 0);
            d.Value = DateTime.Today.Add(t);
            parent.Controls.Add(d);
            return d;
        }

        NumericUpDown MkNum(Control parent, int val, int x, int y)
        {
            NumericUpDown n = new NumericUpDown();
            n.Minimum = 5;
            n.Maximum = 280;
            n.Value = Math.Max(5, Math.Min(280, val));
            n.Bounds = new Rectangle(x, y, S(50), S(24));
            n.BorderStyle = BorderStyle.FixedSingle;
            parent.Controls.Add(n);
            return n;
        }

        void WireEvents()
        {
            btnVerify.Click += new EventHandler(Btn_Verify);
            btnToggle.Click += new EventHandler(Btn_Toggle);
            btnHide.Click += new EventHandler(Btn_Hide);
            btnUpdate.Click += new EventHandler(Btn_Update);
            chkWindowOnly.CheckedChanged += new EventHandler(Cfg_Changed);
            dtStart.ValueChanged += new EventHandler(Cfg_Changed);
            dtStop.ValueChanged += new EventHandler(Cfg_Changed);
            numMin.ValueChanged += new EventHandler(Cfg_Changed);
            numMax.ValueChanged += new EventHandler(Cfg_Changed);
            chkStartMin.CheckedChanged += new EventHandler(Cfg_Changed);
            chkStartup.CheckedChanged += new EventHandler(Startup_Changed);
            if (hasConsole)
            {
                chkConsole.CheckedChanged += new EventHandler(Console_Changed);
                numPort.ValueChanged += new EventHandler(Console_Changed);
                btnCopy.Click += new EventHandler(Btn_Copy);
                btnSetup.Click += new EventHandler(Btn_Setup);
            }
        }

        // ------------------------------------------------------------ console --
        //
        // Everything from here to the end of Btn_Copy is compiled out of the
        // public build. build.ps1 -Public defines NO_CONSOLE and leaves the
        // Console sources out of the compile, so that binary contains no web
        // server, no embedded client and no machine allowlist at all: it is the
        // keep-awake app and nothing else. The stubs under #else keep the call
        // sites and the event wiring compiling without a guard around each one.
#if !NO_CONSOLE
        void Console_Changed(object sender, EventArgs e)
        {
            if (loading || !hasConsole) return;
            cfg.ConsoleOn = chkConsole.Checked;
            cfg.ConsolePort = (int)numPort.Value;
            cfg.Save();
            ApplyConsole();
        }

        // Console has to survive being carried between networks, a lid closed at
        // one desk and opened at another, and anything that quietly closes the
        // listener underneath us. Nothing restarted it before: ApplyConsole only
        // ran at startup or when the checkbox moved, which are the two moments
        // you are definitely at the machine and least need it.
        DateTime nextConsoleCheck = DateTime.MinValue;
        int consoleDown;

        void ConsoleWatchdog()
        {
            if (!hasConsole || !cfg.ConsoleOn || !Exclusive.Allowed()) return;
            if (DateTime.Now < nextConsoleCheck) return;
            nextConsoleCheck = DateTime.Now.AddSeconds(20);

            if (ConsoleServer.Healthy())
            {
                if (consoleDown > 0)
                {
                    Log("console is answering again");
                    consoleDown = 0;
                }
                return;
            }

            consoleDown++;
            string err = ConsoleServer.Heal(cfg.ConsolePort);
            if (err == null)
            {
                Log("console had stopped answering, listener rebuilt on 127.0.0.1:" + cfg.ConsolePort);
                consoleDown = 0;
            }
            else if (consoleDown == 1 || consoleDown % 15 == 0)
            {
                // Once, then every five minutes, so a long outage does not fill
                // the log with the same line.
                Log("console is down, still retrying: " + err);
            }
            UpdateConsoleUi();
        }

        void Btn_Setup(object sender, EventArgs e)
        {
            using (ConsoleSetup d = new ConsoleSetup(cfg)) d.ShowDialog(this);
            UpdateConsoleUi();
        }

        void ApplyConsole()
        {
            if (!hasConsole) return;

            ConsoleServer.ProjectsRootOverride = cfg.ProjectsRoot;

            if (!Exclusive.Allowed())
            {
                // Switched on, but this machine is not enrolled. Say so with the
                // id, which is exactly what Setup needs to send over.
                string id = Exclusive.MachineId();
                Log("console is not enabled for this machine (id " +
                    (id == null ? "unknown" : id) + ")");
                // Ask the channel once, in the background, in case it was added
                // since the last launch.
                System.Threading.Thread t = new System.Threading.Thread(
                    new System.Threading.ThreadStart(RefreshEnrollment));
                t.IsBackground = true;
                t.Start();
                UpdateConsoleUi();
                return;
            }

            bool want = cfg.ConsoleOn;
            if (want && ConsoleServer.Running && ConsoleServer.Port != cfg.ConsolePort)
            {
                ConsoleServer.Stop();       // port changed under us
                Log("console stopped to change port");
            }

            if (want && !ConsoleServer.Running)
            {
                string err = ConsoleServer.Start(cfg.ConsolePort, null);
                if (err != null) Log("console could not start: " + err);
                else Log("console serving on 127.0.0.1:" + cfg.ConsolePort);
            }
            else if (!want && ConsoleServer.Running)
            {
                ConsoleServer.Stop();
                Log("console stopped");
            }
            UpdateConsoleUi();
        }

        // Runs off the UI thread, so it only touches the log through Invoke.
        void RefreshEnrollment()
        {
            bool allowed = Exclusive.Refresh();
            if (!allowed) return;
            try
            {
                BeginInvoke(new MethodInvoker(delegate()
                {
                    Log("this machine has been enabled for Console, restart Awake to use it");
                    UpdateConsoleUi();
                }));
            }
            catch { }
        }

        void UpdateConsoleUi()
        {
            if (!hasConsole) return;

            // Enrolled but not yet restarted, or never enrolled at all. Either way
            // the only useful control is Setup.
            if (!Exclusive.Allowed())
            {
                chkConsole.Enabled = false;
                numPort.Enabled = false;
                btnCopy.Enabled = false;
                lblConsole.Text = "not enabled for this machine";
                lblConsole.ForeColor = WarnFg;
                string id = Exclusive.MachineId();
                txtLink.Text = id == null ? "" : id;
                lblConsoleHint.Text = "Open Setup, copy your machine id, and send it over to be added.";
                lblConsoleHint.ForeColor = Dim;
                return;
            }

            chkConsole.Enabled = true;
            numPort.Enabled = !ConsoleServer.Running;

            if (!ConsoleServer.Running)
            {
                lblConsole.Text = string.IsNullOrEmpty(ConsoleServer.LastError)
                    ? "off" : "failed: " + ConsoleServer.LastError;
                lblConsole.ForeColor = string.IsNullOrEmpty(ConsoleServer.LastError) ? Dim : BadFg;
                txtLink.Text = "";
                lblConsoleHint.Text = "";
                btnCopy.Enabled = false;
                return;
            }

            int open = ConsoleServer.OpenChats();
            lblConsole.Text = "serving, " + open + (open == 1 ? " chat open" : " chats open");
            lblConsole.ForeColor = OkFg;
            txtLink.Text = ConsoleServer.PhoneUrl();
            btnCopy.Enabled = true;

            string host = ConsoleServer.TailnetHost();
            if (host == null)
            {
                lblConsoleHint.Text = "Tailscale not detected. Only this machine can reach it until you install it.";
                lblConsoleHint.ForeColor = WarnFg;
            }
            else if (host.Length == 0)
            {
                lblConsoleHint.Text = "Tailscale is installed. Run: tailscale serve --bg http://127.0.0.1:"
                                      + cfg.ConsolePort;
                lblConsoleHint.ForeColor = Dim;
            }
            else
            {
                lblConsoleHint.Text = "Reachable on your phone. Copy the link and open it once to pair.";
                lblConsoleHint.ForeColor = OkFg;
            }
        }

        void Btn_Copy(object sender, EventArgs e)
        {
            try
            {
                if (txtLink.Text.Length > 0)
                {
                    Clipboard.SetText(txtLink.Text);
                    Log("pairing link copied to the clipboard");
                }
            }
            catch (Exception ex) { Log("could not copy: " + ex.Message); }
        }
#else
        // Public build: no Console. hasConsole is already false, so none of
        // these ever run; they exist only so the rest of the file compiles.
        void Console_Changed(object sender, EventArgs e) { }
        void Btn_Setup(object sender, EventArgs e) { }
        void Btn_Copy(object sender, EventArgs e) { }
        void ApplyConsole() { }
        void UpdateConsoleUi() { }
        void ConsoleWatchdog() { }
        DateTime nextConsoleCheck = DateTime.MinValue;
#endif

        static Icon MakeDot(Color c)
        {
            Bitmap bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (SolidBrush b = new SolidBrush(c)) g.FillEllipse(b, 1, 1, 14, 14);
                using (Pen p = new Pen(Color.FromArgb(70, 0, 0, 0))) g.DrawEllipse(p, 1, 1, 14, 14);
            }
            return Icon.FromHandle(bmp.GetHicon());
        }

        void Dot_Paint(object sender, PaintEventArgs e)
        {
            Color c = StateColor();
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (SolidBrush b = new SolidBrush(c))
                e.Graphics.FillEllipse(b, 0, 0, pnlDot.Width - 1, pnlDot.Height - 1);
        }

        void Card_Paint(object sender, PaintEventArgs e)
        {
            Panel p = (Panel)sender;
            using (Pen pen = new Pen(Color.FromArgb(225, 225, 225)))
                e.Graphics.DrawRectangle(pen, 0, 0, p.Width - 1, p.Height - 1);
        }

        void Graph_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            int w = pnlGraph.Width, h = pnlGraph.Height;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // no frame here: the card already has a border
            // the line Teams cares about
            int yAway = S(14);
            using (Pen pen = new Pen(Color.FromArgb(240, 170, 170)))
            {
                pen.DashStyle = DashStyle.Dash;
                g.DrawLine(pen, 1, yAway, w - 2, yAway);
            }
            using (SolidBrush b = new SolidBrush(Color.FromArgb(190, 90, 90)))
                g.DrawString("Teams switches to Away here (5:00 idle)", fSmall, b, S(6), yAway + S(2));

            if (samples.Count < 2) return;

            float baseY = h - S(3);
            float span = baseY - yAway;
            float step = (float)(w - 2) / (float)(MaxSamples - 1);
            PointF[] pts = new PointF[samples.Count];
            for (int i = 0; i < samples.Count; i++)
            {
                double v = samples[i];
                if (v < 0) v = 0;
                if (v > AwayThreshold) v = AwayThreshold;
                float x = 1 + step * (i + (MaxSamples - samples.Count));
                float y = baseY - (float)(v / AwayThreshold) * span;
                pts[i] = new PointF(x, y);
            }
            using (Pen pen = new Pen(Good, Math.Max(1.2f, 1.6f * sc)))
            {
                pen.LineJoin = LineJoin.Round;
                g.DrawLines(pen, pts);
            }

            PointF[] fill = new PointF[pts.Length + 2];
            Array.Copy(pts, fill, pts.Length);
            fill[pts.Length] = new PointF(pts[pts.Length - 1].X, baseY);
            fill[pts.Length + 1] = new PointF(pts[0].X, baseY);
            using (LinearGradientBrush b = new LinearGradientBrush(
                       new Rectangle(0, (int)yAway, w, (int)(baseY - yAway) + 1),
                       Color.FromArgb(70, Good), Color.FromArgb(8, Good), 90f))
                g.FillPolygon(b, fill);
        }

        Color StateColor()
        {
            if (health.Length > 0) return Color.FromArgb(200, 50, 50);
            if (locked) return Color.FromArgb(212, 160, 23);
            if (userPaused || !inWindow) return Color.FromArgb(212, 160, 23);
            return Color.FromArgb(46, 160, 67);
        }

        void SetVerify(string title, string body, Color bg, Color fg)
        {
            lblVerifyTitle.Text = title;
            lblVerifyBody.Text = body;
            lblVerifyTitle.ForeColor = (fg == Dim) ? Ink : fg;
            lblVerifyBody.ForeColor = fg;
            // The labels carry their own opaque background, so tinting only the
            // card would leave two white boxes floating on a coloured card.
            lblVerifyTitle.BackColor = bg;
            lblVerifyBody.BackColor = bg;
            pnlVerify.Fill = bg;
            pnlVerify.Invalidate();
        }

        // ---------------------------------------------------------- logic --
        void ScheduleNext(int minDelay)
        {
            int lo = (int)numMin.Value, hi = (int)numMax.Value;
            if (hi < lo) hi = lo;
            nextNudge = DateTime.Now.AddSeconds(Math.Max(minDelay, rnd.Next(lo, hi + 1)));
        }

        bool Running() { return !userPaused && inWindow && !locked; }

        // DayOfWeek counts Sunday as 0; the UI and the settings file are Monday first.
        static int TodayIndex() { return ((int)DateTime.Now.DayOfWeek + 6) % 7; }

        void UpdateWindow()
        {
            if (!days[TodayIndex()]) { inWindow = false; return; }
            if (chkWindowOnly.Checked != true) { inWindow = true; return; }
            TimeSpan a = dtStart.Value.TimeOfDay, b = dtStop.Value.TimeOfDay, t = DateTime.Now.TimeOfDay;
            if (a <= b) inWindow = (t >= a && t < b);
            else inWindow = (t >= a || t < b);   // window crosses midnight
        }

        string DaysText()
        {
            int on = 0;
            for (int i = 0; i < 7; i++) if (days[i]) on++;
            if (on == 0) return "no days selected";
            if (on == 7) return "every day";
            bool weekdays = days[0] && days[1] && days[2] && days[3] && days[4] && !days[5] && !days[6];
            if (weekdays) return "Mon to Fri";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int i = 0; i < 7; i++)
                if (days[i]) { if (sb.Length > 0) sb.Append(' '); sb.Append(DayNames[i]); }
            return sb.ToString();
        }

        void OnTick(object sender, EventArgs e)
        {
            // a sleep or hibernate shows up as a jump in wall clock time
            if ((DateTime.Now - lastSeen).TotalSeconds > 20)
                Log(string.Format("gap of {0:0} s in the timer, the machine was asleep or suspended",
                                  (DateTime.Now - lastSeen).TotalSeconds));
            lastSeen = DateTime.Now;

            bool wasIn = inWindow;
            UpdateWindow();
            if (wasIn != inWindow)
            {
                Log(inWindow ? "inside the schedule window" : "outside the schedule window, idling");
                if (inWindow) nextNudge = DateTime.Now;
            }

            // Console holds the power request on its own, outside the schedule and
            // through a locked screen, because a laptop that went to sleep is a
            // laptop you cannot reach from your phone. It deliberately does not
            // extend Running(): that also drives input injection, and nudging all
            // night would light you up as active in Teams at 3am.
#if NO_CONSOLE
            if (Running()) Native.StayAwake(); else Native.ReleaseAwake();
#else
            if (Running() || ConsoleServer.Running) Native.StayAwake();
            else Native.ReleaseAwake();
            ConsoleWatchdog();
#endif

            if (verifyPhase != 0) RunVerify();
            else if (Running() && DateTime.Now >= nextNudge) DoNudge();

            if (!updateBusy && DateTime.Now >= nextUpdateCheck) CheckForUpdate(false);

            UpdateUi();
        }

        void DoNudge()
        {
            uint m = Native.Jiggle(); int em = Native.LastError;
            uint k = Native.Key(Native.VK_F15); int ek = Native.LastError;
            nudges++;
            lastNudge = DateTime.Now;
            ScheduleNext(0);

            // SendInput updates the last input time synchronously, so the idle
            // clock has to read about zero right now. If it does not, this
            // nudge did not land. Every single nudge is checked this way.
            double after = Native.IdleSeconds();

            if (m < 2 || k < 2)
            {
                int err = (m < 2) ? em : ek;
                string h = "Windows refused the injected input (error " + err + ")";
                if (err == 5) h += ". An elevated window has focus, restart Awake as administrator.";
                SetHealth(h);
            }
            else if (after > 2.0)
            {
                SetHealth(string.Format("Input was accepted but the idle clock stayed at {0:0} s, something is filtering injected input.", after));
            }
            else SetHealth("");
        }

        void SetHealth(string h)
        {
            if (h == health) return;
            health = h;
            if (h.Length > 0)
            {
                Log("PROBLEM: " + h);
                if (!healthNotified)
                {
                    healthNotified = true;
                    try { tray.ShowBalloonTip(8000, "Awake is not working", h, ToolTipIcon.Warning); }
                    catch { }
                }
            }
            else { Log("recovered, input is being accepted again"); healthNotified = false; }
        }

        void OnSample(object sender, EventArgs e)
        {
            double idle = Native.IdleSeconds();
            samples.Add(idle);
            while (samples.Count > MaxSamples) samples.RemoveAt(0);

            // only judge idle gaps once we have actually started nudging, otherwise
            // time the user spent away before launch counts against us
            if (Running() && verifyPhase == 0 && nudges > 0)
            {
                if (idle > longestIdle) longestIdle = idle;
                if (prevIdle <= AwayThreshold && idle > AwayThreshold)
                {
                    flipEvents++;
                    Log("idle passed 5 minutes, Teams will have shown Away");
                }
            }
            prevIdle = idle;
            pnlGraph.Invalidate();
        }

        void RunVerify()
        {
            double idle = Native.IdleSeconds();

            if (verifyPhase == 1)
            {
                if (idle >= 5.0)
                {
                    verifyBefore = idle;
                    uint m = Native.Jiggle(); int em = Native.LastError;
                    uint k = Native.Key(Native.VK_F15); int ek = Native.LastError;
                    verifyRefused = (m < 2 || k < 2);
                    verifyErr = (m < 2) ? em : ek;
                    verifyInjectAt = DateTime.Now;
                    verifyPhase = 2;
                    return;
                }
                if (DateTime.Now >= verifyDeadline)
                {
                    verifyPhase = 0;
                    ScheduleNext(0);
                    SetVerify("Verification cancelled",
                              "Could not get 5 quiet seconds. Start it again and keep your hands off the mouse and keyboard.",
                              WarnBg, WarnFg);
                    return;
                }
                SetVerify("Verifying, hands off",
                          string.Format("Waiting for 5 quiet seconds so the idle clock can climb. Idle now {0:0.0} s.", idle),
                          InfoBg, InfoFg);
                return;
            }

            if (verifyPhase == 2 && (DateTime.Now - verifyInjectAt).TotalMilliseconds > 400)
            {
                verifyPhase = 0;
                ScheduleNext(0);
                if (verifyRefused)
                {
                    string extra = (verifyErr == 5)
                        ? "An elevated window had focus. Close it or restart Awake as administrator."
                        : "Check for input blocking software.";
                    SetVerify("FAILED, Windows refused the input",
                              "SendInput was rejected with error " + verifyErr + ". " + extra, BadBg, BadFg);
                }
                else if (idle > 1.5)
                {
                    SetVerify("FAILED, the idle clock did not move",
                              string.Format("The input was accepted but idle stayed at {0:0.0} s. Something is filtering injected input.", idle),
                              BadBg, BadFg);
                }
                else
                {
                    SetVerify("PASSED",
                              string.Format("Idle went from {0:0.0} s straight back to {1:0.0} s. Windows counts this session as active, so Teams stays green.", verifyBefore, idle),
                              OkBg, OkFg);
                }
                Log("verify: " + lblVerifyTitle.Text);
            }
        }

        void UpdateUi()
        {
            double idle = Native.IdleSeconds();

            string state;
            if (health.Length > 0) state = "Not working";
            else if (locked) state = "Screen locked";
            else if (userPaused) state = "Paused";
            else if (!inWindow) state = "Waiting for the window";
            else state = "Active";
            lblState.Text = state;
            lblState.ForeColor = StateColor();

            string sched = (chkWindowOnly.Checked != true)
                ? DaysText() + ", all day"
                : string.Format("{0}, {1:HH:mm} to {2:HH:mm}", DaysText(), dtStart.Value, dtStop.Value);
            lblSub.Text = string.Format("mouse nudge plus F15 every {0} to {1} s, {2}  |  v{3}",
                                        (int)numMin.Value, (int)numMax.Value, sched, Build.Version);

            vIdle.Text = string.Format("{0:0.0} s", idle);
            vIdle.ForeColor = idle > AwayThreshold ? BadFg : Ink;
            vLongest.Text = string.Format("{0:0.0} s", longestIdle);
            vLongest.ForeColor = longestIdle > AwayThreshold ? BadFg : Ink;
            vNudges.Text = nudges == 0
                ? "0"
                : string.Format("{0}, last {1:HH:mm:ss}", nudges, lastNudge);
            if (Running() && verifyPhase == 0)
            {
                double left = (nextNudge - DateTime.Now).TotalSeconds;
                if (left < 0) left = 0;
                vNext.Text = string.Format("in {0:0} s", left);
            }
            else vNext.Text = "held";

            Process t = Native.Teams();
            vTeams.Text = (t == null) ? "not running" : "running";
            vTeams.ForeColor = (t == null) ? WarnFg : Ink;
            vScreen.Text = locked ? "locked" : "unlocked";
            vScreen.ForeColor = locked ? WarnFg : Ink;
            vElev.Text = Native.IsElevated() ? "yes" : "no";
            vFlips.Text = flipEvents.ToString();
            vFlips.ForeColor = flipEvents > 0 ? BadFg : Ink;

            btnToggle.Text = userPaused ? "Resume" : "Pause";
            btnVerify.Enabled = (verifyPhase == 0);
            dtStart.Enabled = chkWindowOnly.Checked;
            dtStop.Enabled = chkWindowOnly.Checked;

            Icon want = health.Length > 0 ? icRed : (Running() ? icGreen : icAmber);
            if (tray.Icon != want) tray.Icon = want;
            string tip = "Awake - " + state;
            if (tip.Length > 62) tip = tip.Substring(0, 62);
            if (tray.Text != tip) tray.Text = tip;

            UpdateConsoleUi();
            pnlDot.Invalidate();
        }

        // ---------------------------------------------------------- updates --
        // Runs the network part on a worker thread, then marshals back to the UI.
        void CheckForUpdate(bool userAsked)
        {
            if (updateBusy) return;
            updateBusy = true;
            nextUpdateCheck = DateTime.Now.AddHours(6);
            SetUpdateStatus("checking...");
            if (userAsked) Log("checking for updates");

            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                string status;
                bool install = false;
                Manifest m = null;
                try
                {
                    m = Updater.Fetch();
                    if (!Updater.IsNewer(m.Version, Build.Version))
                    {
                        status = "up to date (v" + Build.Version + "), checked " + DateTime.Now.ToString("HH:mm");
                    }
                    else if (!Updater.CanSelfInstall())
                    {
                        status = "v" + m.Version + " available, but this copy runs outside the install folder";
                    }
                    else if (Host.Scripted && m.SrcFile.Length == 0)
                    {
                        status = "v" + m.Version + " available, but it has no hosted build";
                    }
                    else
                    {
                        status = "installing v" + m.Version + "...";
                        install = true;
                    }
                }
                catch (Exception ex)
                {
                    status = "check failed: " + Trim(ex.Message, 70);
                }

                Manifest mm = m;
                bool doInstall = install;
                string st = status;
                try
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        SetUpdateStatus(st);
                        if (userAsked || doInstall || st.StartsWith("check failed")) Log("update: " + st);
                        if (doInstall) InstallUpdate(mm);
                        else updateBusy = false;
                    });
                }
                catch { updateBusy = false; }
            });
        }

        void InstallUpdate(Manifest m)
        {
            System.Threading.ThreadPool.QueueUserWorkItem(delegate
            {
                string status;
                string staged = null;
                try
                {
                    staged = Host.Scripted ? Updater.StageScripted(m) : Updater.Stage(m);
                    status = "restarting into v" + m.Version;
                }
                catch (Exception ex)
                {
                    status = "update failed: " + Trim(ex.Message, 70);
                }

                string st = status;
                string path = staged;
                try
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        SetUpdateStatus(st);
                        Log("update: " + st);
                        updateBusy = false;
                        if (path != null)
                        {
                            // Hand over and get out of the way: hosted mode swaps the
                            // source files and relaunches, the exe build lets the
                            // staged copy overwrite this one.
                            if (Host.Scripted) Updater.HandOverScripted(path);
                            else Updater.HandOver(path);
                            allowExit = true;
                            Close();
                        }
                    });
                }
                catch { updateBusy = false; }
            });
        }

        static string Trim(string s, int n)
        {
            if (s == null) return "";
            s = s.Replace("\r", " ").Replace("\n", " ");
            return s.Length <= n ? s : s.Substring(0, n) + "...";
        }

        void SetUpdateStatus(string s)
        {
            updateStatus = s;
            if (lblUpdate != null) lblUpdate.Text = s;
        }

        void Log(string msg)
        {
            string line = DateTime.Now.ToString("HH:mm:ss") + "  " + msg;
            try
            {
                if (txtLog.Lines.Length > 300) txtLog.Clear();
                txtLog.AppendText(line + Environment.NewLine);
            }
            catch { }
            try
            {
                Directory.CreateDirectory(Settings.Dir());
                string logPath = Path.Combine(Settings.Dir(), "awake.log");

                // Unbounded until now. It only grew slowly, but something meant
                // to run for weeks should not have a file in it that never stops
                // growing. Keep the tail and drop the rest.
                try
                {
                    FileInfo fi = new FileInfo(logPath);
                    if (fi.Exists && fi.Length > 1024 * 1024)
                    {
                        string[] all = File.ReadAllLines(logPath);
                        int keep = Math.Min(all.Length, 2000);
                        string[] tail = new string[keep];
                        Array.Copy(all, all.Length - keep, tail, 0, keep);
                        File.WriteAllLines(logPath, tail);
                    }
                }
                catch { }

                File.AppendAllText(logPath,
                                   DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine);
            }
            catch { }
        }

        // --------------------------------------------------------- events --
        void Btn_Verify(object sender, EventArgs e)
        {
            if (verifyPhase != 0) return;
            verifyPhase = 1;
            verifyDeadline = DateTime.Now.AddSeconds(30);
            SetVerify("Verifying, hands off",
                      "Waiting for 5 quiet seconds so the idle clock can climb. Do not touch the mouse or keyboard.",
                      InfoBg, InfoFg);
            Log("verification started");
        }

        void Btn_Toggle(object sender, EventArgs e)
        {
            userPaused = !userPaused;
            Log(userPaused ? "paused by you" : "resumed");
            if (!userPaused) nextNudge = DateTime.Now;
            UpdateUi();
        }

        void Btn_Hide(object sender, EventArgs e) { HideToTray(); }

        void Btn_Update(object sender, EventArgs e)
        {
            nextUpdateCheck = DateTime.Now;
            CheckForUpdate(true);
        }

        void HideToTray()
        {
            Hide();
            try { tray.ShowBalloonTip(3000, "Awake", "Still running. Double click the tray icon to open it.", ToolTipIcon.Info); }
            catch { }
        }

        void Tray_Show(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        void Tray_Quit(object sender, EventArgs e) { allowExit = true; Close(); }

        void Cfg_Changed(object sender, EventArgs e)
        {
            if (loading || !interactive) return;
            if (numMax.Value < numMin.Value) numMax.Value = numMin.Value;
            cfg.AllDay = (chkWindowOnly.Checked != true);
            for (int i = 0; i < 7; i++) cfg.Days[i] = days[i];
            cfg.Start = dtStart.Value.ToString("HH:mm");
            cfg.Stop = dtStop.Value.ToString("HH:mm");
            cfg.MinSec = (int)numMin.Value;
            cfg.MaxSec = (int)numMax.Value;
            cfg.StartMinimized = chkStartMin.Checked;
            cfg.Save();
            UpdateUi();
        }

        void Startup_Changed(object sender, EventArgs e)
        {
            if (loading || !interactive) return;
            SetStartup(chkStartup.Checked);
            Log(chkStartup.Checked ? "will start with Windows" : "will not start with Windows");
        }

        void OnSessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            if (e.Reason == SessionSwitchReason.SessionLock || e.Reason == SessionSwitchReason.ConsoleDisconnect)
            {
                locked = true;
                Log("screen locked, Teams will show Away until you sign back in");
            }
            else if (e.Reason == SessionSwitchReason.SessionUnlock || e.Reason == SessionSwitchReason.ConsoleConnect)
            {
                locked = false;
                nextNudge = DateTime.Now;
                Log("screen unlocked");
            }
            UpdateUi();
        }

        void OnPowerMode(object sender, PowerModeChangedEventArgs e)
        {
            if (e.Mode == PowerModes.Resume)
            {
                Log("resumed from sleep");
                ScheduleNext(2);
                // Give the network a few seconds to come back, then let the
                // watchdog look rather than waiting out its normal interval.
                nextConsoleCheck = DateTime.Now.AddSeconds(6);
            }
            else if (e.Mode == PowerModes.Suspend) Log("machine is suspending");
        }

        protected override void SetVisibleCore(bool value)
        {
            if (startHidden && !shownOnce)
            {
                shownOnce = true;
                startHidden = false;
                if (!IsHandleCreated) CreateHandle();
                base.SetVisibleCore(false);
                return;
            }
            shownOnce = true;
            base.SetVisibleCore(value);
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            // park focus on a button so nothing auto-checks itself
            try { ActiveControl = btnVerify; }
            catch { }
            // settings only follow the controls once a human can actually see them
            interactive = true;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (WindowState == FormWindowState.Minimized) HideToTray();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!allowExit && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                HideToTray();
                return;
            }
            Native.ReleaseAwake();
#if !NO_CONSOLE
            // Every chat is a child process of this one. Leaving them running with
            // nothing serving them would strand claude.exe instances nobody can
            // reach or stop.
            ConsoleServer.Stop();
#endif
            try { SystemEvents.SessionSwitch -= new SessionSwitchEventHandler(OnSessionSwitch); }
            catch { }
            Log("Awake stopped");
            tray.Visible = false;
            base.OnFormClosing(e);
        }

        // ------------------------------------------------------- autostart --
        static bool StartupEnabled()
        {
            try
            {
                RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, false);
                if (k == null) return false;
                object v = k.GetValue(RunName);
                k.Close();
                return v != null;
            }
            catch { return false; }
        }

        static void SetStartup(bool on)
        {
            try
            {
                RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, true);
                if (k == null) k = Registry.CurrentUser.CreateSubKey(RunKey);
                if (on)
                {
                    // Hosted mode has no exe to point at, so register the host script.
                    string cmd = Host.Scripted
                        ? "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \""
                          + Path.Combine(Host.Root, "AwakeHost.ps1") + "\" -tray"
                        : "\"" + Application.ExecutablePath + "\" -tray";
                    k.SetValue(RunName, cmd);
                }
                else if (k.GetValue(RunName) != null) k.DeleteValue(RunName, false);
                k.Close();
            }
            catch { }
        }
    }

    // Set by AwakeHost.ps1 when the app runs compiled in process instead of as
    // an exe, which is how it runs on machines where Smart App Control blocks
    // unsigned executables.
    public static class Host
    {
        public static bool Scripted = false;
        public static string Root = "";
    }

    // ------------------------------------------------------------ program --
    public static class Program
    {
        static System.Threading.Mutex mtx;

        [STAThread]
        static void Main(string[] args)
        {
            // Update handover. This copy was just downloaded by the running app and
            // its only job is to replace it. Must happen before the single-instance
            // mutex, because the app being replaced still holds it.
            if (args.Length >= 3 && args[0] == "--apply-update")
            {
                Updater.ApplyUpdate(args[1], args[2]);
                return;
            }

            bool created;
            mtx = new System.Threading.Mutex(true, "Local\\AwakeAppSingleInstance", out created);
            if (!created)
            {
                MessageBox.Show("Awake is already running. Look for the dot in the notification area.",
                                "Awake", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            bool hidden = false;
            for (int i = 0; i < args.Length; i++)
                if (string.Compare(args[i], "-tray", StringComparison.OrdinalIgnoreCase) == 0) hidden = true;

            Settings s = Settings.Load();
            if (s.StartMinimized) hidden = true;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm(hidden));
            Native.ReleaseAwake();
        }
    }
}
