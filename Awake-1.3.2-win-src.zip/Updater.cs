﻿// Awake self-update, Windows side.
//
// Pulls from the public releases channel, so no token and nothing that expires.
// The source repo stays private; only the built binaries and a tiny manifest
// are published.
//
// Replacing a running exe is the whole problem. Windows will not let a process
// overwrite its own image, so the handover is:
//
//   1. running app  : download Awake.exe to <install>\update\, verify SHA-256
//   2. running app  : start it with --apply-update "<my path>" <my pid>, then quit
//   3. staged copy  : wait for that pid to die, copy itself over the target,
//                     start the target, exit
//   4. new app      : deletes the staging folder on startup
//
// Every step is checked. A failed download or a bad checksum leaves the working
// installation untouched.

using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace AwakeApp
{
    public class Manifest
    {
        public string Version = "";
        public string File = "";
        public string Sha256 = "";
        public string SrcFile = "";
        public string SrcSha = "";
        public string Notes = "";
    }

    public static class Updater
    {
        // Public channel, so no token and nothing that expires. The manifest names
        // a version stamped file, so a cached copy can never be mistaken for the
        // new one.
        public const string Channel =
            "https://raw.githubusercontent.com/AlejandroBWJ/desktop-tools/main/";

        // Two lanes on one channel. The public build must never update itself
        // into the Console build, and this one must never update itself down
        // into the public build, so each reads its own manifest and each
        // manifest names its own files.
#if NO_CONSOLE
        public const string ManifestName = "version-public.json";
#else
        public const string ManifestName = "version.json";
#endif

        public static string InstallRoot()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Awake");
        }

        public static string StagingDir() { return Path.Combine(InstallRoot(), "update"); }

        public static string ExePath()
        {
            try { return Process.GetCurrentProcess().MainModule.FileName; }
            catch
            {
                try { return System.Reflection.Assembly.GetEntryAssembly().Location; }
                catch { return ""; }
            }
        }

        // Only overwrite ourselves when running from the installed location. A dev
        // build run out of the repo should report an update, never replace itself.
        public static bool CanSelfInstall()
        {
            // Hosted: we replace source files, so the check is on where they live.
            // Requiring the install root means a copy run out of the repo updates
            // nothing, instead of quietly overwriting the working tree.
            if (Host.Scripted)
                return Host.Root.Length > 0
                       && Host.Root.StartsWith(InstallRoot(), StringComparison.OrdinalIgnoreCase);

            string exe = ExePath();
            if (exe.Length == 0) return false;
            return exe.StartsWith(InstallRoot(), StringComparison.OrdinalIgnoreCase);
        }

        // Every source file the hosted build compiles. A file missing from this
        // list is NOT copied on update, so the host script then tries to compile
        // a new Awake.cs against a stale or absent one and the app stops starting
        // altogether. Adding a .cs to the project means adding it here too, on top
        // of build.ps1, AwakeHost.ps1 and the workflow's zip step.
        static readonly string[] SrcFiles =
        {
            "Awake.cs", "Updater.cs", "Console.cs", "ConsoleServer.cs", "ConsoleUi.cs",
            "ConsoleSetup.cs", "Generated.cs", "AwakeHost.ps1"
        };

        static void EnableTls()
        {
            // GitHub needs TLS 1.2 or better. Numeric values so this still compiles
            // and runs if the enum members are missing on an older framework.
            try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)(3072 | 12288); }
            catch
            {
                try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; }
                catch { }
            }
        }

        static WebClient Client()
        {
            EnableTls();
            WebClient c = new WebClient();
            c.Headers.Add("User-Agent", "Awake-Updater");
            // Never serve a stale manifest from the local cache.
            c.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
            return c;
        }

        static string Field(string json, string key)
        {
            Match m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"([^\"]*)\"");
            return m.Success ? m.Groups[1].Value : "";
        }

        public static Manifest Fetch()
        {
            using (WebClient c = Client())
            {
                string json = c.DownloadString(Channel + ManifestName);
                Manifest m = new Manifest();
                m.Version = Field(json, "version");
                m.File = Field(json, "win_file");
                m.Sha256 = Field(json, "win_sha256");
                m.SrcFile = Field(json, "winsrc_file");
                m.SrcSha = Field(json, "winsrc_sha256");
                m.Notes = Field(json, "notes");
                if (m.File.Length == 0) m.File = "Awake.exe";
                return m;
            }
        }

        // 1.2.10 beats 1.2.9, and a malformed part never throws.
        public static bool IsNewer(string remote, string local)
        {
            string[] a = (remote ?? "").Split('.');
            string[] b = (local ?? "").Split('.');
            int n = Math.Max(a.Length, b.Length);
            for (int i = 0; i < n; i++)
            {
                int x = 0, y = 0;
                if (i < a.Length) int.TryParse(a[i].Trim(), out x);
                if (i < b.Length) int.TryParse(b[i].Trim(), out y);
                if (x != y) return x > y;
            }
            return false;
        }

        public static string Sha256File(string path)
        {
            using (SHA256 h = SHA256.Create())
            using (FileStream fs = File.OpenRead(path))
            {
                byte[] d = h.ComputeHash(fs);
                StringBuilder sb = new StringBuilder(64);
                for (int i = 0; i < d.Length; i++) sb.Append(d[i].ToString("x2"));
                return sb.ToString();
            }
        }

        // Downloads and verifies. Throws on any problem, leaving the install alone.
        public static string Stage(Manifest m)
        {
            string dir = StagingDir();
            Directory.CreateDirectory(dir);
            string dest = Path.Combine(dir, "Awake.exe");
            if (File.Exists(dest)) { try { File.Delete(dest); } catch { } }

            using (WebClient c = Client()) c.DownloadFile(Channel + m.File, dest);

            long size = new FileInfo(dest).Length;
            if (size < 8000) throw new Exception("downloaded file is only " + size + " bytes");

            if (m.Sha256.Length == 64)
            {
                string got = Sha256File(dest);
                if (!string.Equals(got, m.Sha256, StringComparison.OrdinalIgnoreCase))
                {
                    try { File.Delete(dest); } catch { }
                    throw new Exception("checksum mismatch, refusing to install (expected "
                                        + m.Sha256.Substring(0, 12) + ", got " + got.Substring(0, 12) + ")");
                }
            }
            return dest;
        }

        // Hosted mode. No exe to swap, just text files, which the running app does
        // not hold a lock on. Everything is downloaded and checked before a single
        // installed file is touched.
        public static string StageScripted(Manifest m)
        {
            if (m.SrcFile.Length == 0) throw new Exception("this release has no hosted build");

            string dir = StagingDir();
            if (Directory.Exists(dir)) { try { Directory.Delete(dir, true); } catch { } }
            Directory.CreateDirectory(dir);

            string zip = Path.Combine(dir, "src.zip");
            using (WebClient c = Client()) c.DownloadFile(Channel + m.SrcFile, zip);

            long size = new FileInfo(zip).Length;
            if (size < 2000) throw new Exception("source download is only " + size + " bytes");

            if (m.SrcSha.Length == 64)
            {
                string got = Sha256File(zip);
                if (!string.Equals(got, m.SrcSha, StringComparison.OrdinalIgnoreCase))
                {
                    throw new Exception("checksum mismatch on the source download (expected "
                                        + m.SrcSha.Substring(0, 12) + ", got " + got.Substring(0, 12) + ")");
                }
            }

            string ex = Path.Combine(dir, "src");
            Directory.CreateDirectory(ex);
            System.IO.Compression.ZipFile.ExtractToDirectory(zip, ex);

            for (int i = 0; i < SrcFiles.Length; i++)
            {
                if (!System.IO.File.Exists(Path.Combine(ex, SrcFiles[i])))
                    throw new Exception("the download is missing " + SrcFiles[i]);
            }
            return ex;
        }

        public static void HandOverScripted(string extracted)
        {
            string root = Host.Root;
            string prev = Path.Combine(root, "prev");
            Directory.CreateDirectory(prev);

            // Keep the previous version next to the new one. If a bad build ever
            // ships, prev\AwakeHost.ps1 still runs.
            for (int i = 0; i < SrcFiles.Length; i++)
            {
                string dst = Path.Combine(root, SrcFiles[i]);
                if (System.IO.File.Exists(dst))
                {
                    try { System.IO.File.Copy(dst, Path.Combine(prev, SrcFiles[i]), true); } catch { }
                }
                System.IO.File.Copy(Path.Combine(extracted, SrcFiles[i]), dst, true);
            }

            // The new host waits for this process to exit before claiming the
            // single instance mutex, otherwise it would just say "already running".
            ProcessStartInfo psi = new ProcessStartInfo("powershell.exe");
            psi.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \""
                            + Path.Combine(root, "AwakeHost.ps1") + "\" -tray -waitFor "
                            + Process.GetCurrentProcess().Id;
            psi.UseShellExecute = false;
            psi.WorkingDirectory = root;
            Process.Start(psi);
        }

        public static void HandOver(string staged)
        {
            ProcessStartInfo psi = new ProcessStartInfo(staged);
            psi.Arguments = "--apply-update \"" + ExePath() + "\" " + Process.GetCurrentProcess().Id;
            psi.UseShellExecute = false;
            psi.WorkingDirectory = StagingDir();
            Process.Start(psi);
        }

        // Runs inside the freshly downloaded copy, before any UI exists.
        public static void ApplyUpdate(string target, string pidText)
        {
            int pid = 0;
            int.TryParse(pidText, out pid);
            if (pid > 0)
            {
                try
                {
                    Process p = Process.GetProcessById(pid);
                    p.WaitForExit(30000);
                }
                catch { }   // already gone, which is the normal case
            }

            string me = ExePath();
            bool copied = false;
            for (int i = 0; i < 40 && !copied; i++)
            {
                try { File.Copy(me, target, true); copied = true; }
                catch { System.Threading.Thread.Sleep(500); }
            }

            if (!copied)
            {
                // Could not replace it. Better to leave the old version running than
                // to leave nothing installed.
                try { Log("update failed: could not overwrite " + target); } catch { }
            }

            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(target);
                psi.UseShellExecute = false;
                Process.Start(psi);
            }
            catch { }
        }

        public static void CleanStaging()
        {
            try
            {
                string dir = StagingDir();
                if (Directory.Exists(dir)) Directory.Delete(dir, true);
            }
            catch { }   // the staged copy may still be exiting; next start gets it
        }

        static void Log(string msg)
        {
            try
            {
                Directory.CreateDirectory(InstallRoot());
                System.IO.File.AppendAllText(Path.Combine(InstallRoot(), "awake.log"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + msg + Environment.NewLine);
            }
            catch { }
        }
    }
}
