﻿/*
  Awake Console.

  Runs local Claude Code from a phone. Remote Control would have been the
  obvious way to do this, but it is gated behind an organization policy this
  account cannot change (allow_remote_control, off by default on Team plans and
  only an Owner can turn it on). Headless mode has no such gate and, as it
  turns out, makes a better phone client anyway.

  The shape: one long-lived claude.exe per open chat, driven over stdin with
  --input-format stream-json, which is realtime streaming input rather than the
  one-shot pipe the name suggests. Output comes back as stream-json, gets
  collapsed into a small event vocabulary, and is pushed to the browser over
  Server-Sent Events. Conversations live in the same
  ~/.claude/projects transcripts that `claude --resume` reads, so a chat started
  on the phone is the same object as a chat started in a terminal.

  Two deliberate constraints:

  - The listener binds 127.0.0.1 and nothing else. Binding any other address
    needs a netsh urlacl reservation or an elevated process; loopback needs
    neither. Reachability is `tailscale serve`, which fronts it with real HTTPS
    inside the tailnet, so the tailnet is the security boundary.
  - Nothing in the API takes a path or a command. The phone sends an index into
    a list this process scanned, never a string we then execute.

  C# 5 only. The in-box csc.exe is the C# 5 compiler, so no string
  interpolation, no null-conditional operator, no expression-bodied members.
*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;

namespace AwakeApp
{
    // ----------------------------------------------------------------- owner --
    // Console is not part of what Awake is for. Awake is a small utility other
    // people have downloaded, and shipping them a thing that runs an AI agent
    // against their filesystem, on a port, because they happened to take an
    // update, would be a genuinely bad surprise. So the feature exists in every
    // build but only turns on for the machines listed here. Everyone else gets
    // Awake, with no Console card and no listener, and never knows the
    // difference.
    //
    // This is a feature flag, not a security boundary, and it does not need to
    // be one. Console binds loopback, needs a token generated on the machine it
    // runs on, and serves that machine's own Claude Code. Someone who patched
    // the check would gain access to their own computer, which they already
    // had. Nothing here reaches this account, this machine, or the repository.
    //
    // Adding a machine: enable console in settings.ini there, read the id out of
    // the Awake log, add it below, bump VERSION, push.
    public static class Exclusive
    {
        // SHA-256, hex, of HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid.
        // Hashed rather than stored plainly so the binary does not carry a list
        // of machine identifiers around in the clear.
        static readonly string[] Machines = new string[]
        {
            "b2d21fba1fde8e5255eef0818b06fbff4b956d8a37b97f1c31d9de41f70ca062", // BWJ_ALEJANDRO
        };

        static bool? cached;

        public static bool Allowed()
        {
            if (cached.HasValue) return cached.Value;
            string id = MachineId();
            bool ok = false;
            if (id != null)
            {
                if (Listed(Machines, id)) ok = true;
                else if (Listed(Granted(), id)) ok = true;
            }
            cached = ok;
            return ok;
        }

        static bool Listed(IEnumerable<string> list, string id)
        {
            if (list == null) return false;
            foreach (string m in list)
            {
                if (string.Equals(m, id, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        // ------------------------------------------------------- granted machines --
        // The compiled list above is the seed. Anything else is granted through a
        // small file on the public release channel, so enrolling somebody else's
        // machine is one line in one file rather than a whole new release.
        //
        // The file holds SHA-256 hashes and nothing else. It is public and that is
        // fine: a hash identifies no person, reveals no address, and grants nothing
        // by itself. Console is still loopback bound and still needs a token
        // generated on the machine it runs on.
        //
        //   console-machines.json
        //   { "machines": [ "b2d21fba...", "7f3c91ea..." ] }
        static string GrantFile()
        {
            return Path.Combine(Settings.Dir(), "machines.json");
        }

        // Read from the local cache, so startup never waits on the network.
        static List<string> Granted()
        {
            List<string> outp = new List<string>();
            try
            {
                string p = GrantFile();
                if (!File.Exists(p)) return outp;
                foreach (Match m in Regex.Matches(File.ReadAllText(p), "[0-9a-fA-F]{64}"))
                    outp.Add(m.Value);
            }
            catch { }
            return outp;
        }

        // Refresh the cache from the channel. Returns true when this machine is
        // allowed afterwards. Called in the background at startup and by the
        // Check again button in setup, which is how a newly enrolled machine
        // finds out without waiting for the next update check.
        public static bool Refresh()
        {
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)(3072 | 12288);
            }
            catch { }

            try
            {
                using (WebClient c = new WebClient())
                {
                    c.Headers.Add("User-Agent", "Awake-Console");
                    c.CachePolicy = new System.Net.Cache.RequestCachePolicy(
                        System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
                    string json = c.DownloadString(Updater.Channel + "console-machines.json");
                    // Only rewrite the cache if the response actually looks like the
                    // file, so a 404 page can never revoke a machine.
                    if (Regex.IsMatch(json, "[0-9a-fA-F]{64}"))
                    {
                        Directory.CreateDirectory(Settings.Dir());
                        File.WriteAllText(GrantFile(), json);
                    }
                }
            }
            catch { }

            cached = null;          // re-evaluate against whatever we now have
            return Allowed();
        }

        // Stable for the life of a Windows install, and survives a rename, which
        // a hostname does not.
        public static string MachineId()
        {
            try
            {
                using (Microsoft.Win32.RegistryKey k = Microsoft.Win32.Registry.LocalMachine
                        .OpenSubKey("SOFTWARE\\Microsoft\\Cryptography"))
                {
                    if (k == null) return null;
                    string guid = k.GetValue("MachineGuid") as string;
                    if (string.IsNullOrEmpty(guid)) return null;
                    using (SHA256 sha = SHA256.Create())
                    {
                        byte[] h = sha.ComputeHash(new UTF8Encoding(false).GetBytes(guid));
                        StringBuilder sb = new StringBuilder(h.Length * 2);
                        foreach (byte b in h) sb.Append(b.ToString("x2", CultureInfo.InvariantCulture));
                        return sb.ToString();
                    }
                }
            }
            catch { return null; }
        }
    }

    // ------------------------------------------------------------------ json --
    // Thin helpers over JavaScriptSerializer. The stream-json lines are plain
    // JSON, and a tool result can be megabytes, so everything here is written to
    // tolerate a line far larger than anything we want to forward.
    public static class J
    {
        static readonly JavaScriptSerializer Ser = MakeSerializer();

        static JavaScriptSerializer MakeSerializer()
        {
            JavaScriptSerializer s = new JavaScriptSerializer();
            s.MaxJsonLength = int.MaxValue;
            s.RecursionLimit = 200;
            return s;
        }

        public static string Write(object o)
        {
            lock (Ser) { return Ser.Serialize(o); }
        }

        public static Dictionary<string, object> Read(string json)
        {
            try
            {
                lock (Ser) { return Ser.DeserializeObject(json) as Dictionary<string, object>; }
            }
            catch { return null; }
        }

        public static object Get(Dictionary<string, object> d, string key)
        {
            object v;
            if (d != null && d.TryGetValue(key, out v)) return v;
            return null;
        }

        public static string Str(Dictionary<string, object> d, string key)
        {
            object v = Get(d, key);
            if (v == null) return null;
            string s = v as string;
            if (s != null) return s;
            return Convert.ToString(v, CultureInfo.InvariantCulture);
        }

        public static Dictionary<string, object> Obj(Dictionary<string, object> d, string key)
        {
            return Get(d, key) as Dictionary<string, object>;
        }

        public static object[] Arr(Dictionary<string, object> d, string key)
        {
            return Get(d, key) as object[];
        }

        public static double Num(Dictionary<string, object> d, string key)
        {
            object v = Get(d, key);
            if (v == null) return 0;
            try { return Convert.ToDouble(v, CultureInfo.InvariantCulture); }
            catch { return 0; }
        }

        public static bool Bool(Dictionary<string, object> d, string key)
        {
            object v = Get(d, key);
            if (v is bool) return (bool)v;
            return false;
        }
    }

    // --------------------------------------------------------------- sessions --
    public class SessionInfo
    {
        public string Id = "";
        public string Cwd = "";
        public string Project = "";     // display label for the directory
        public string Title = "";
        public DateTime Modified;
        public long Bytes;
    }

    // Reads the on-disk conversation store. Never loads a whole transcript: the
    // index only needs the head of each file, and the history replay is capped.
    public static class SessionIndex
    {
        public static string Root()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                ".claude", "projects");
        }

        public static List<SessionInfo> Scan(int max)
        {
            List<SessionInfo> all = new List<SessionInfo>();
            string root = Root();
            if (!Directory.Exists(root)) return all;

            string[] dirs;
            try { dirs = Directory.GetDirectories(root); }
            catch { return all; }

            List<FileInfo> files = new List<FileInfo>();
            foreach (string dir in dirs)
            {
                string[] jsonl;
                try { jsonl = Directory.GetFiles(dir, "*.jsonl"); }
                catch { continue; }
                foreach (string f in jsonl)
                {
                    try
                    {
                        FileInfo fi = new FileInfo(f);
                        // A transcript with nothing in it is a session that never
                        // got a prompt. Listing those is just noise.
                        if (fi.Length > 512) files.Add(fi);
                    }
                    catch { }
                }
            }

            files.Sort(delegate(FileInfo a, FileInfo b)
            {
                return b.LastWriteTimeUtc.CompareTo(a.LastWriteTimeUtc);
            });

            int taken = 0;
            foreach (FileInfo fi in files)
            {
                if (taken >= max) break;
                SessionInfo si = Describe(fi);
                if (si == null) continue;
                all.Add(si);
                taken++;
            }
            return all;
        }

        static SessionInfo Describe(FileInfo fi)
        {
            SessionInfo si = new SessionInfo();
            si.Id = Path.GetFileNameWithoutExtension(fi.Name);
            si.Modified = fi.LastWriteTimeUtc;
            si.Bytes = fi.Length;
            si.Cwd = DecodeDir(fi.Directory.Name);
            si.Project = ShortProject(si.Cwd);

            // Head of the file only. cwd shows up on early lines and the first
            // user message the person actually typed is the natural title.
            string fallback = "";
            try
            {
                using (FileStream fs = new FileStream(fi.FullName, FileMode.Open,
                                                      FileAccess.Read, FileShare.ReadWrite))
                using (StreamReader sr = new StreamReader(fs, new UTF8Encoding(false)))
                {
                    int lines = 0;
                    string line;
                    while ((line = sr.ReadLine()) != null && lines < 400)
                    {
                        lines++;
                        if (line.Length > 400000) continue;
                        Dictionary<string, object> o = J.Read(line);
                        if (o == null) continue;

                        string cwd = J.Str(o, "cwd");
                        if (!string.IsNullOrEmpty(cwd) && string.IsNullOrEmpty(si.Cwd))
                        {
                            si.Cwd = cwd;
                            si.Project = ShortProject(cwd);
                        }

                        if (si.Title.Length == 0 && J.Str(o, "type") == "user")
                        {
                            string t = FirstText(J.Obj(o, "message"));
                            if (!string.IsNullOrEmpty(t))
                            {
                                if (Boilerplate(t))
                                {
                                    // Note what kind of session this is and carry
                                    // on looking for something he actually typed.
                                    if (fallback.Length == 0) fallback = Label(t);
                                }
                                else si.Title = Clean(t, 110);
                            }
                        }
                        if (si.Title.Length > 0 && si.Cwd.Length > 0) break;
                    }
                }
            }
            catch { }

            // A truncated caveat wrapper as a title is worse than admitting there
            // was never a prompt, so say which kind of session it is instead.
            if (si.Title.Length == 0) si.Title = fallback.Length > 0 ? fallback : "(no prompt yet)";
            return si;
        }

        // The first user turn is often not a prompt at all. A resumed session
        // opens with the compaction summary, and a slash command opens with the
        // harness's caveat wrapper. Three list entries reading "Caveat: The
        // messages below were generated..." tell you nothing about which chat is
        // which, so these are skipped in favour of the next real message.
        static bool Boilerplate(string t)
        {
            if (string.IsNullOrEmpty(t)) return true;
            string s = t.TrimStart();
            if (s.StartsWith("Caveat:", StringComparison.OrdinalIgnoreCase)) return true;
            if (s.StartsWith("This session is being continued", StringComparison.OrdinalIgnoreCase)) return true;
            if (s.StartsWith("<", StringComparison.Ordinal)) return true;          // reminder blocks
            if (s.StartsWith("[Request interrupted", StringComparison.OrdinalIgnoreCase)) return true;
            if (s.StartsWith("Your task is to create a detailed summary",
                              StringComparison.OrdinalIgnoreCase)) return true;    // compaction prompt
            return false;
        }

        static string Label(string t)
        {
            string s = t == null ? "" : t.TrimStart();
            if (s.IndexOf("local-command", StringComparison.OrdinalIgnoreCase) >= 0 ||
                s.StartsWith("Caveat:", StringComparison.OrdinalIgnoreCase))
                return "(local commands only)";
            if (s.StartsWith("This session is being continued", StringComparison.OrdinalIgnoreCase))
                return "(continued session)";
            if (s.StartsWith("[Request interrupted", StringComparison.OrdinalIgnoreCase))
                return "(interrupted)";
            return "";
        }

        // A user message's content is either a bare string or an array of blocks.
        public static string FirstText(Dictionary<string, object> message)
        {
            if (message == null) return null;
            object content = J.Get(message, "content");
            string s = content as string;
            if (s != null) return s;
            object[] blocks = content as object[];
            if (blocks == null) return null;
            foreach (object b in blocks)
            {
                Dictionary<string, object> bd = b as Dictionary<string, object>;
                if (bd == null) continue;
                if (J.Str(bd, "type") == "text")
                {
                    string t = J.Str(bd, "text");
                    if (!string.IsNullOrEmpty(t)) return t;
                }
            }
            return null;
        }

        // ~/.claude/projects encodes the working directory into the folder name by
        // replacing the separators. "C--Users-ajmva" is C:\Users\ajmva. The
        // encoding is lossy, since a real dash in a folder name is indistinguishable
        // from a separator, so this is a display aid only and the authoritative cwd
        // comes from the transcript itself.
        public static string DecodeDir(string encoded)
        {
            if (string.IsNullOrEmpty(encoded)) return "";
            string s = encoded;
            if (s.Length > 3 && s[1] == '-' && s[2] == '-')
                s = s.Substring(0, 1) + ":\\" + s.Substring(3);
            return s.Replace('-', '\\').Replace(":\\\\", ":\\");
        }

        public static string ShortProject(string cwd)
        {
            if (string.IsNullOrEmpty(cwd)) return "";
            string t = cwd.TrimEnd('\\', '/');
            int i = t.LastIndexOfAny(new char[] { '\\', '/' });
            string leaf = (i >= 0 && i < t.Length - 1) ? t.Substring(i + 1) : t;
            return leaf;
        }

        public static string Clean(string s, int max)
        {
            if (s == null) return "";
            s = Regex.Replace(s, @"\s+", " ").Trim();
            // Slash commands and the harness's own reminder blocks make useless
            // titles, so strip the noisiest wrappers.
            s = Regex.Replace(s, @"<[^>]{1,40}>", "").Trim();
            if (s.Length > max) s = s.Substring(0, max - 1).TrimEnd() + "\u2026";
            return s;
        }

        // These transcripts get big: there is a 261 MB one in this store, and a
        // 31 MB one. Only the last handful of messages is ever rendered, so read
        // the tail rather than the whole file, or tapping that conversation on a
        // phone stalls for seconds while we parse a quarter of a gigabyte.
        const long TailBytes = 3L * 1024 * 1024;

        static StreamReader OpenTail(FileStream fs)
        {
            bool seeked = false;
            if (fs.Length > TailBytes)
            {
                fs.Seek(fs.Length - TailBytes, SeekOrigin.Begin);
                seeked = true;
            }
            StreamReader sr = new StreamReader(fs, new UTF8Encoding(false));
            // Seeking lands mid-line, and possibly mid-character, so throw the
            // first partial line away.
            if (seeked) sr.ReadLine();
            return sr;
        }

        // Past messages for a conversation the phone reopens, so it shows history
        // instead of an empty pane. Tool traffic is summarised, not replayed.
        public static List<object> History(string sessionId, int maxMessages)
        {
            List<object> outp = new List<object>();
            string root = Root();
            if (!Directory.Exists(root)) return outp;

            string found = null;
            try
            {
                foreach (string dir in Directory.GetDirectories(root))
                {
                    string cand = Path.Combine(dir, sessionId + ".jsonl");
                    if (File.Exists(cand)) { found = cand; break; }
                }
            }
            catch { }
            if (found == null) return outp;

            List<object> msgs = new List<object>();
            try
            {
                using (FileStream fs = new FileStream(found, FileMode.Open,
                                                      FileAccess.Read, FileShare.ReadWrite))
                using (StreamReader sr = OpenTail(fs))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        // A single tool result can be enormous. Nothing that big is
                        // ever a message we want to render.
                        if (line.Length > 300000) continue;
                        Dictionary<string, object> o = J.Read(line);
                        if (o == null) continue;
                        string type = J.Str(o, "type");
                        if (type != "user" && type != "assistant") continue;

                        Dictionary<string, object> m = J.Obj(o, "message");
                        if (m == null) continue;

                        if (type == "user")
                        {
                            // Skip tool_result turns: they are plumbing, not what
                            // the person typed.
                            if (HasBlock(m, "tool_result")) continue;
                            string t = FirstText(m);
                            if (string.IsNullOrEmpty(t)) continue;
                            if (t.StartsWith("<", StringComparison.Ordinal)) continue;
                            msgs.Add(Msg("user", t));
                        }
                        else
                        {
                            string t = AssistantText(m);
                            if (string.IsNullOrEmpty(t)) continue;
                            msgs.Add(Msg("assistant", t));
                        }
                    }
                }
            }
            catch { }

            int skip = msgs.Count > maxMessages ? msgs.Count - maxMessages : 0;
            for (int i = skip; i < msgs.Count; i++) outp.Add(msgs[i]);
            return outp;
        }

        static object Msg(string role, string text)
        {
            Dictionary<string, object> d = new Dictionary<string, object>();
            d["role"] = role;
            d["text"] = text.Length > 20000 ? text.Substring(0, 20000) + "\u2026" : text;
            return d;
        }

        static bool HasBlock(Dictionary<string, object> message, string type)
        {
            object[] blocks = J.Get(message, "content") as object[];
            if (blocks == null) return false;
            foreach (object b in blocks)
            {
                Dictionary<string, object> bd = b as Dictionary<string, object>;
                if (bd != null && J.Str(bd, "type") == type) return true;
            }
            return false;
        }

        static string AssistantText(Dictionary<string, object> message)
        {
            object[] blocks = J.Get(message, "content") as object[];
            if (blocks == null) return null;
            StringBuilder sb = new StringBuilder();
            foreach (object b in blocks)
            {
                Dictionary<string, object> bd = b as Dictionary<string, object>;
                if (bd == null) continue;
                if (J.Str(bd, "type") != "text") continue;   // drop thinking + tool_use
                string t = J.Str(bd, "text");
                if (!string.IsNullOrEmpty(t)) sb.Append(t);
            }
            return sb.ToString();
        }
    }

    // ------------------------------------------------------------------ chat --
    // One open conversation, backed by one claude.exe. Events are kept in a ring
    // buffer as well as pushed, so a phone that locks its screen and comes back
    // replays what it missed instead of showing a blank pane.
    public class Chat
    {
        public string Id = "";
        public string SessionId = "";
        public string Cwd = "";
        public string Label = "";
        public string Mode = "auto";
        public string Model = "";
        public bool Busy;
        public DateTime LastActivity = DateTime.UtcNow;
        public double CostUsd;
        public string LastError = "";

        Process proc;
        Thread reader;
        readonly object gate = new object();
        readonly List<string> ring = new List<string>();
        int seq;                       // event sequence, so clients can resume
        const int RingMax = 600;

        // Written by ConsoleServer when a browser attaches.
        public readonly List<Stream> Listeners = new List<Stream>();

        public bool Alive
        {
            get
            {
                Process p = proc;
                if (p == null) return false;
                try { return !p.HasExited; }
                catch { return false; }
            }
        }

        public int Seq { get { lock (gate) { return seq; } } }

        public static string FindClaude()
        {
            // The native install lands here. Verified on this machine, and it is a
            // real PE rather than a shell shim, so it can be started directly.
            string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string direct = Path.Combine(home, ".local\\bin\\claude.exe");
            if (File.Exists(direct)) return direct;

            string pathVar = Environment.GetEnvironmentVariable("PATH");
            if (!string.IsNullOrEmpty(pathVar))
            {
                foreach (string part in pathVar.Split(';'))
                {
                    if (part.Trim().Length == 0) continue;
                    try
                    {
                        string cand = Path.Combine(part.Trim(), "claude.exe");
                        if (File.Exists(cand)) return cand;
                    }
                    catch { }
                }
            }
            return null;
        }

        public string Start(string resumeSessionId)
        {
            string exe = FindClaude();
            if (exe == null) return "claude.exe not found";
            if (!Directory.Exists(Cwd)) return "working directory does not exist";

            // -p skips the workspace trust dialog, which is what makes an
            // unattended spawn possible at all: the dialog never persists trust
            // for a home directory, so an interactive spawn there would hang
            // forever waiting for a keypress nobody is at the machine to give.
            StringBuilder a = new StringBuilder();
            a.Append("-p");
            a.Append(" --input-format stream-json");
            a.Append(" --output-format stream-json");
            a.Append(" --verbose");                    // required for stream-json
            a.Append(" --include-partial-messages");   // token level deltas
            a.Append(" --permission-mode ").Append(SafeMode(Mode));
            if (!string.IsNullOrEmpty(Model)) a.Append(" --model ").Append(SafeToken(Model));
            if (!string.IsNullOrEmpty(resumeSessionId))
                a.Append(" --resume ").Append(SafeToken(resumeSessionId));

            ProcessStartInfo psi = new ProcessStartInfo(exe, a.ToString());
            psi.WorkingDirectory = Cwd;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardInput = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            // StandardInputEncoding does not exist on this framework, so stdin is
            // written as raw UTF-8 bytes to the base stream instead.
            psi.StandardOutputEncoding = new UTF8Encoding(false);
            psi.StandardErrorEncoding = new UTF8Encoding(false);

            try
            {
                proc = Process.Start(psi);
            }
            catch (Exception ex)
            {
                return "could not start claude: " + ex.Message;
            }

            if (!string.IsNullOrEmpty(resumeSessionId)) SessionId = resumeSessionId;

            reader = new Thread(ReadLoop);
            reader.IsBackground = true;
            reader.Start();

            Thread errReader = new Thread(ErrLoop);
            errReader.IsBackground = true;
            errReader.Start();

            return null;
        }

        static string SafeMode(string m)
        {
            switch (m)
            {
                case "acceptEdits":
                case "auto":
                case "plan":
                case "manual":
                case "dontAsk":
                    return m;
                default:
                    // bypassPermissions is deliberately not reachable from the phone.
                    return "auto";
            }
        }

        // Belt and braces. These values only ever come from a fixed list or a
        // scanned session id, but they end up on a command line, so anything that
        // is not plainly safe is dropped rather than quoted.
        static string SafeToken(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            if (!Regex.IsMatch(s, @"^[A-Za-z0-9._\-\[\]]{1,80}$")) return "";
            return s;
        }

        public string Send(string text)
        {
            if (!Alive) return "session is not running";
            if (string.IsNullOrEmpty(text)) return "empty message";

            Dictionary<string, object> block = new Dictionary<string, object>();
            block["type"] = "text";
            block["text"] = text;
            Dictionary<string, object> msg = new Dictionary<string, object>();
            msg["role"] = "user";
            msg["content"] = new object[] { block };
            Dictionary<string, object> env = new Dictionary<string, object>();
            env["type"] = "user";
            env["message"] = msg;

            string line = J.Write(env) + "\n";
            try
            {
                byte[] bytes = new UTF8Encoding(false).GetBytes(line);
                Stream s = proc.StandardInput.BaseStream;
                lock (gate)
                {
                    s.Write(bytes, 0, bytes.Length);
                    s.Flush();
                }
            }
            catch (Exception ex) { return "could not write to session: " + ex.Message; }

            Busy = true;
            LastActivity = DateTime.UtcNow;
            Emit("you", new KeyValuePair<string, object>("x", text));
            return null;
        }

        public void Close()
        {
            try
            {
                if (proc != null && !proc.HasExited)
                {
                    // Closing stdin is the graceful exit: the process finishes the
                    // turn it is on and stops. Kill the tree only if it ignores that.
                    try { proc.StandardInput.BaseStream.Close(); } catch { }
                    if (!proc.WaitForExit(2500)) KillTree();
                }
            }
            catch { }
            lock (gate)
            {
                foreach (Stream s in Listeners) { try { s.Close(); } catch { } }
                Listeners.Clear();
            }
        }

        public void KillTree()
        {
            try
            {
                if (proc == null || proc.HasExited) return;
                // claude spawns helpers; Process.Kill would orphan them.
                ProcessStartInfo psi = new ProcessStartInfo(
                    "taskkill.exe",
                    "/PID " + proc.Id.ToString(CultureInfo.InvariantCulture) + " /T /F");
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                Process k = Process.Start(psi);
                if (k != null) k.WaitForExit(4000);
            }
            catch
            {
                try { proc.Kill(); } catch { }
            }
        }

        void ErrLoop()
        {
            try
            {
                string line;
                while ((line = proc.StandardError.ReadLine()) != null)
                {
                    if (line.Trim().Length == 0) continue;
                    LastError = line;
                    Emit("stderr", new KeyValuePair<string, object>("x", Trim(line, 400)));
                }
            }
            catch { }
        }

        void ReadLoop()
        {
            try
            {
                string line;
                while ((line = proc.StandardOutput.ReadLine()) != null)
                {
                    try { Translate(line); }
                    catch (Exception ex)
                    {
                        Emit("err", new KeyValuePair<string, object>("x", "parse: " + ex.Message));
                    }
                }
            }
            catch { }

            int code = -1;
            try { code = proc.ExitCode; } catch { }
            Busy = false;
            Emit("exit", new KeyValuePair<string, object>("code", code));
        }

        // --------------------------------------------------- event translation --
        // Raw stream-json is a firehose: partial deltas, whole message objects,
        // tool inputs, tool results, hook chatter. Forwarding it verbatim would be
        // both slow and unreadable on a phone, and would push file contents into
        // the browser for no reason. This collapses it to the few events the UI
        // actually draws.
        void Translate(string line)
        {
            if (line == null || line.Length == 0) return;

            // Guard against a single pathological line. We still want to know it
            // happened, but we are not going to parse ten megabytes to find out.
            if (line.Length > 1200000)
            {
                Emit("note", new KeyValuePair<string, object>("x", "skipped an oversized event"));
                return;
            }

            Dictionary<string, object> o = J.Read(line);
            if (o == null) return;
            string type = J.Str(o, "type");
            LastActivity = DateTime.UtcNow;

            if (type == "system")
            {
                string sub = J.Str(o, "subtype");
                if (sub == "init")
                {
                    string sid = J.Str(o, "session_id");
                    if (!string.IsNullOrEmpty(sid)) SessionId = sid;
                    object[] tools = J.Arr(o, "tools");
                    Emit("init",
                        new KeyValuePair<string, object>("sid", SessionId),
                        new KeyValuePair<string, object>("model", J.Str(o, "model")),
                        new KeyValuePair<string, object>("tools", tools == null ? 0 : tools.Length),
                        new KeyValuePair<string, object>("cwd", Cwd));
                }
                // hook_started / hook_response and friends are internal plumbing.
                return;
            }

            if (type == "stream_event")
            {
                Dictionary<string, object> ev = J.Obj(o, "event");
                if (ev == null) return;
                string et = J.Str(ev, "type");
                if (et == "content_block_start")
                {
                    Dictionary<string, object> cb = J.Obj(ev, "content_block");
                    if (cb != null && J.Str(cb, "type") == "thinking") Emit("think");
                    return;
                }
                if (et == "content_block_delta")
                {
                    Dictionary<string, object> d = J.Obj(ev, "delta");
                    if (d == null) return;
                    object t = J.Get(d, "text");
                    if (t is string && ((string)t).Length > 0)
                        Emit("delta", new KeyValuePair<string, object>("x", (string)t));
                    // thinking_delta is intentionally not streamed. The UI shows
                    // that thinking is happening without pushing all of it down.
                    return;
                }
                return;
            }

            if (type == "assistant")
            {
                Dictionary<string, object> m = J.Obj(o, "message");
                object[] blocks = m == null ? null : J.Get(m, "content") as object[];
                if (blocks == null) return;
                foreach (object b in blocks)
                {
                    Dictionary<string, object> bd = b as Dictionary<string, object>;
                    if (bd == null) continue;
                    string bt = J.Str(bd, "type");
                    if (bt == "tool_use")
                    {
                        string name = J.Str(bd, "name");
                        Emit("tool",
                            new KeyValuePair<string, object>("id", J.Str(bd, "id")),
                            new KeyValuePair<string, object>("n", PrettyTool(name)),
                            new KeyValuePair<string, object>("s", ToolSummary(name, J.Obj(bd, "input"))));
                        if (name == "TodoWrite") EmitTodos(J.Obj(bd, "input"));
                    }
                    else if (bt == "text")
                    {
                        // The whole block arrives after its deltas. Send it as the
                        // authoritative version so the UI can replace what it
                        // assembled, which also covers the no-deltas case.
                        string t = J.Str(bd, "text");
                        if (!string.IsNullOrEmpty(t))
                            Emit("msg", new KeyValuePair<string, object>("x", t));
                    }
                }
                return;
            }

            if (type == "user")
            {
                // Tool results come back as a user turn. Summarise, never forward:
                // this is where file contents would otherwise leak into the browser.
                Dictionary<string, object> m = J.Obj(o, "message");
                object[] blocks = m == null ? null : J.Get(m, "content") as object[];
                if (blocks == null) return;
                foreach (object b in blocks)
                {
                    Dictionary<string, object> bd = b as Dictionary<string, object>;
                    if (bd == null || J.Str(bd, "type") != "tool_result") continue;
                    bool isErr = J.Bool(bd, "is_error");
                    Emit("tool_done",
                        new KeyValuePair<string, object>("id", J.Str(bd, "tool_use_id")),
                        new KeyValuePair<string, object>("ok", !isErr),
                        new KeyValuePair<string, object>("s", ResultSummary(bd, isErr)));
                }
                return;
            }

            if (type == "result")
            {
                Busy = false;
                double cost = J.Num(o, "total_cost_usd");
                CostUsd += cost;
                string sid = J.Str(o, "session_id");
                if (!string.IsNullOrEmpty(sid)) SessionId = sid;
                Emit("done",
                    new KeyValuePair<string, object>("sub", J.Str(o, "subtype")),
                    new KeyValuePair<string, object>("cost", cost),
                    new KeyValuePair<string, object>("total", CostUsd),
                    new KeyValuePair<string, object>("turns", J.Num(o, "num_turns")),
                    new KeyValuePair<string, object>("sid", SessionId));
                return;
            }

            // rate_limit_event arrives on ordinary successful turns, so it is a
            // usage report rather than a warning. Surfacing it would put a scary
            // and untrue banner on every single message.
        }

        void EmitTodos(Dictionary<string, object> input)
        {
            object[] todos = input == null ? null : J.Arr(input, "todos");
            if (todos == null) return;
            List<object> items = new List<object>();
            foreach (object t in todos)
            {
                Dictionary<string, object> td = t as Dictionary<string, object>;
                if (td == null) continue;
                Dictionary<string, object> item = new Dictionary<string, object>();
                item["c"] = Trim(J.Str(td, "content"), 160);
                item["s"] = J.Str(td, "status");
                items.Add(item);
            }
            if (items.Count > 0)
                Emit("todos", new KeyValuePair<string, object>("items", items.ToArray()));
        }

        // "mcp__claude_ai_Shopify__search_products" reads terribly on a phone.
        public static string PrettyTool(string name)
        {
            if (string.IsNullOrEmpty(name)) return "tool";
            if (name.StartsWith("mcp__", StringComparison.Ordinal))
            {
                string rest = name.Substring(5);
                string server = rest, op = "";
                int i = rest.IndexOf("__", StringComparison.Ordinal);
                if (i > 0)
                {
                    server = rest.Substring(0, i);
                    op = rest.Substring(i + 2);
                }
                server = server.Replace("claude_ai_", "").Replace("plugin_", "")
                               .Replace('_', ' ').Trim();
                op = op.Replace('_', ' ').Replace('-', ' ').Trim();
                if (op.Length == 0) return server;
                return server + ": " + op;
            }
            return name;
        }

        // The one field that tells you what the call actually does.
        public static string ToolSummary(string name, Dictionary<string, object> input)
        {
            if (input == null) return "";
            string[] pathish = new string[] { "file_path", "notebook_path", "path" };
            foreach (string k in pathish)
            {
                string v = J.Str(input, k);
                if (!string.IsNullOrEmpty(v)) return Leaf(v);
            }
            string cmd = J.Str(input, "command");
            if (!string.IsNullOrEmpty(cmd)) return Trim(Collapse(cmd), 90);
            string pattern = J.Str(input, "pattern");
            if (!string.IsNullOrEmpty(pattern))
            {
                string where = J.Str(input, "glob");
                if (string.IsNullOrEmpty(where)) where = J.Str(input, "type");
                return Trim(pattern, 60) + (string.IsNullOrEmpty(where) ? "" : "  in " + where);
            }
            string url = J.Str(input, "url");
            if (!string.IsNullOrEmpty(url)) return Trim(url, 90);
            string[] textish = new string[] { "query", "prompt", "description", "text", "message" };
            foreach (string k in textish)
            {
                string v = J.Str(input, k);
                if (!string.IsNullOrEmpty(v)) return Trim(Collapse(v), 90);
            }
            if (name == "TodoWrite") return "";
            return "";
        }

        static string ResultSummary(Dictionary<string, object> block, bool isErr)
        {
            object content = J.Get(block, "content");
            string s = content as string;
            if (s == null)
            {
                object[] blocks = content as object[];
                if (blocks != null)
                {
                    StringBuilder sb = new StringBuilder();
                    foreach (object b in blocks)
                    {
                        Dictionary<string, object> bd = b as Dictionary<string, object>;
                        if (bd == null) continue;
                        string t = J.Str(bd, "text");
                        if (!string.IsNullOrEmpty(t)) { sb.Append(t); if (sb.Length > 4000) break; }
                    }
                    s = sb.ToString();
                }
            }
            if (string.IsNullOrEmpty(s)) return isErr ? "failed" : "";

            if (isErr) return Trim(Collapse(s), 180);

            // For a success we want a size, not the payload. Two lines is already
            // enough to look like noise once collapsed, because a Read result
            // carries its line-number gutter with it.
            int lines = 1;
            for (int i = 0; i < s.Length; i++) if (s[i] == '\n') lines++;
            if (lines > 1) return lines.ToString(CultureInfo.InvariantCulture) + " lines";
            return Trim(Collapse(s), 90);
        }

        static string Leaf(string p)
        {
            if (string.IsNullOrEmpty(p)) return "";
            string t = p.TrimEnd('\\', '/');
            int i = t.LastIndexOfAny(new char[] { '\\', '/' });
            return (i >= 0 && i < t.Length - 1) ? t.Substring(i + 1) : t;
        }

        static string Collapse(string s)
        {
            if (s == null) return "";
            return Regex.Replace(s, @"\s+", " ").Trim();
        }

        static string Trim(string s, int max)
        {
            if (s == null) return "";
            if (s.Length <= max) return s;
            return s.Substring(0, max - 1).TrimEnd() + "\u2026";
        }

        // -------------------------------------------------------------- fanout --
        void Emit(string t, params KeyValuePair<string, object>[] fields)
        {
            Dictionary<string, object> d = new Dictionary<string, object>();
            d["t"] = t;
            if (fields != null)
                foreach (KeyValuePair<string, object> kv in fields) d[kv.Key] = kv.Value;

            string payload;
            List<Stream> targets;
            lock (gate)
            {
                seq++;
                d["i"] = seq;
                payload = J.Write(d);
                ring.Add(payload);
                if (ring.Count > RingMax) ring.RemoveRange(0, ring.Count - RingMax);
                targets = new List<Stream>(Listeners);
            }

            byte[] frame = Encoding.UTF8.GetBytes("data: " + payload + "\n\n");
            List<Stream> dead = null;
            foreach (Stream s in targets)
            {
                try
                {
                    s.Write(frame, 0, frame.Length);
                    s.Flush();
                }
                catch
                {
                    if (dead == null) dead = new List<Stream>();
                    dead.Add(s);
                }
            }
            if (dead != null)
            {
                lock (gate) { foreach (Stream s in dead) Listeners.Remove(s); }
                foreach (Stream s in dead) { try { s.Close(); } catch { } }
            }
        }

        // Everything the client has not seen yet, for a reconnect.
        public List<string> Replay(int fromSeq)
        {
            lock (gate)
            {
                List<string> outp = new List<string>();
                int first = seq - ring.Count + 1;
                for (int i = 0; i < ring.Count; i++)
                {
                    if (first + i > fromSeq) outp.Add(ring[i]);
                }
                return outp;
            }
        }

        public void Attach(Stream s)
        {
            lock (gate) { Listeners.Add(s); }
        }

        public void Detach(Stream s)
        {
            lock (gate) { Listeners.Remove(s); }
        }
    }
}
