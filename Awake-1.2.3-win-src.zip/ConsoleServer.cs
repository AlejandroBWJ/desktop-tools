﻿/*
  Awake Console, HTTP layer.

  Binds 127.0.0.1 and nothing else. That is not timidity: HttpListener needs a
  netsh urlacl reservation or an elevated process to bind any other address,
  while loopback needs neither, so this keeps Awake a normal unprivileged app.
  Reachability comes from `tailscale serve --bg http://127.0.0.1:<port>`, which
  fronts it with a real certificate inside the tailnet. The tailnet is the
  boundary; there is no inbound hole in the firewall and no port forwarding.

  Because this endpoint starts processes, it is treated as a remote code
  execution surface:

    - a 32 byte random token, required on every request, compared in constant time
    - no request ever carries a path or a command; the phone sends an index into
      a list this process scanned itself
    - permission mode comes from a fixed allowlist, and bypassPermissions is not
      reachable from the phone at all

  C# 5 only.
*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace AwakeApp
{
    public static class ConsoleServer
    {
        public static bool Running { get; private set; }
        public static string LastError = "";
        public static int Port = 8787;

        static HttpListener listener;
        static Thread loop;
        static Timer keepalive;
        static string token = "";
        static readonly object gate = new object();
        static readonly Dictionary<string, Chat> chats = new Dictionary<string, Chat>();
        static List<string> projects = new List<string>();

        // A warm process is worth keeping: a cold start pays about three cents
        // just to load the system prompt for 144 tools. It is not worth keeping
        // all night.
        static readonly TimeSpan IdleLimit = TimeSpan.FromMinutes(45);

        // ------------------------------------------------------------- lifecycle --
        public static string Start(int port, IEnumerable<string> extraDirs)
        {
            if (Running) return null;
            // Refuse here as well as hiding the card, so no other path can bring
            // the listener up on a machine this feature was never meant for.
            if (!Exclusive.Allowed()) return "not available on this machine";
            Port = port;
            LastError = "";

            // A busy port surfaces from HttpListener as "the process cannot access
            // the file because it is being used by another process", which sends
            // you looking for a file that was never the problem. There are node
            // and python dev servers on this machine, so say it plainly instead.
            if (PortBusy(port))
            {
                LastError = "port " + port.ToString(CultureInfo.InvariantCulture)
                          + " is already in use, pick another";
                return LastError;
            }

            try
            {
                token = LoadOrCreateToken();
                projects = ScanProjects(extraDirs);

                listener = new HttpListener();
                listener.Prefixes.Add("http://127.0.0.1:" + port.ToString(CultureInfo.InvariantCulture) + "/");
                listener.Start();
            }
            catch (HttpListenerException hex)
            {
                LastError = "port " + port.ToString(CultureInfo.InvariantCulture)
                          + " could not be opened (" + hex.ErrorCode.ToString(CultureInfo.InvariantCulture)
                          + "), pick another";
                Safe(delegate { if (listener != null) listener.Close(); });
                listener = null;
                return LastError;
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
                Safe(delegate { if (listener != null) listener.Close(); });
                listener = null;
                return ex.Message;
            }

            Running = true;
            loop = new Thread(Accept);
            loop.IsBackground = true;
            loop.Start();

            // SSE through any reverse proxy wants traffic. This also reaps chats
            // nobody has touched for a while.
            keepalive = new Timer(Tick, null, 20000, 20000);
            return null;
        }

        public static void Stop()
        {
            Running = false;
            Safe(delegate { if (keepalive != null) keepalive.Dispose(); });
            keepalive = null;
            Safe(delegate { if (listener != null) listener.Stop(); });
            Safe(delegate { if (listener != null) listener.Close(); });
            listener = null;

            List<Chat> all;
            lock (gate) { all = new List<Chat>(chats.Values); chats.Clear(); }
            foreach (Chat c in all) Safe(delegate { c.Close(); });
        }

        public static string Url()
        {
            return "http://127.0.0.1:" + Port.ToString(CultureInfo.InvariantCulture) + "/?t=" + token;
        }

        // The one to put on a phone. A loopback link is useless there, so once
        // Tailscale is actually serving the port this hands back the tailnet URL
        // instead, token and all, so pairing is one paste rather than a URL you
        // have to assemble by hand.
        public static string PhoneUrl()
        {
            string host = TailnetHost();
            if (string.IsNullOrEmpty(host)) return Url();
            return "https://" + host + "/?t=" + token;
        }

        public static string Token() { return token; }

        public static int OpenChats() { lock (gate) { return chats.Count; } }

        static void Safe(Action a) { try { a(); } catch { } }

        static bool PortBusy(int port)
        {
            try
            {
                System.Net.IPEndPoint[] active = System.Net.NetworkInformation.IPGlobalProperties
                    .GetIPGlobalProperties().GetActiveTcpListeners();
                foreach (System.Net.IPEndPoint ep in active)
                {
                    if (ep.Port != port) continue;
                    // A listener on 0.0.0.0 or :: covers loopback too, so any of
                    // those three blocks us.
                    if (IPAddress.IsLoopback(ep.Address)) return true;
                    if (ep.Address.Equals(IPAddress.Any) || ep.Address.Equals(IPAddress.IPv6Any)) return true;
                }
                return false;
            }
            catch { return false; }   // if we cannot tell, let Start try and report
        }

        // ------------------------------------------------------------- tailscale --
        // Three states the window needs to tell apart, so the answer is tri-valued:
        //   null  Tailscale is not installed, so nothing but this machine can reach us
        //   ""    installed, but nothing is serving our port yet
        //   host  installed and serving, so this is the address to open on the phone
        //
        // Probing shells out, and the window refreshes on a timer, so the result is
        // cached rather than asked every second.
        static string tailnetCache = null;
        static bool tailnetCached = false;
        static DateTime tailnetAt = DateTime.MinValue;

        public static string TailnetHost()
        {
            if (tailnetCached && (DateTime.UtcNow - tailnetAt) < TimeSpan.FromSeconds(60))
                return tailnetCache;

            tailnetCache = ProbeTailnet();
            tailnetCached = true;
            tailnetAt = DateTime.UtcNow;
            return tailnetCache;
        }

        static string FindTailscale()
        {
            string[] guesses = new string[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                             "Tailscale\\tailscale.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                             "Tailscale\\tailscale.exe")
            };
            foreach (string g in guesses) { try { if (File.Exists(g)) return g; } catch { } }

            string pathVar = Environment.GetEnvironmentVariable("PATH");
            if (!string.IsNullOrEmpty(pathVar))
            {
                foreach (string part in pathVar.Split(';'))
                {
                    if (part.Trim().Length == 0) continue;
                    try
                    {
                        string cand = Path.Combine(part.Trim(), "tailscale.exe");
                        if (File.Exists(cand)) return cand;
                    }
                    catch { }
                }
            }
            return null;
        }

        static string ProbeTailnet()
        {
            string exe = FindTailscale();
            if (exe == null) return null;

            string host = "";
            string statusJson = Run(exe, "status --json", 6000);
            if (!string.IsNullOrEmpty(statusJson))
            {
                Dictionary<string, object> o = J.Read(statusJson);
                Dictionary<string, object> self = J.Obj(o, "Self");
                string dns = J.Str(self, "DNSName");
                if (!string.IsNullOrEmpty(dns)) host = dns.TrimEnd('.');
            }
            if (host.Length == 0) return "";

            // Serving is a separate decision from being on the tailnet, and saying
            // the phone can reach us when nothing is proxying the port would just
            // send him to a dead URL.
            string serve = Run(exe, "serve status", 6000);
            if (string.IsNullOrEmpty(serve)) return "";
            string needle = "127.0.0.1:" + Port.ToString(CultureInfo.InvariantCulture);
            if (serve.IndexOf(needle, StringComparison.OrdinalIgnoreCase) < 0) return "";
            return host;
        }

        static string Run(string exe, string args, int timeoutMs)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(exe, args);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                Process p = Process.Start(psi);
                string outp = p.StandardOutput.ReadToEnd();
                p.StandardError.ReadToEnd();
                if (!p.WaitForExit(timeoutMs)) { try { p.Kill(); } catch { } return null; }
                return outp;
            }
            catch { return null; }
        }

        // ----------------------------------------------------------------- token --
        static string LoadOrCreateToken()
        {
            string dir = Settings.Dir();
            Directory.CreateDirectory(dir);
            string path = Path.Combine(dir, "console.token");
            if (File.Exists(path))
            {
                string t = File.ReadAllText(path).Trim();
                if (Regex.IsMatch(t, "^[A-Za-z0-9_-]{20,}$")) return t;
            }
            byte[] raw = new byte[32];
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider()) rng.GetBytes(raw);
            string tok = Convert.ToBase64String(raw)
                                .Replace('+', '-').Replace('/', '_').TrimEnd('=');
            File.WriteAllText(path, tok);
            return tok;
        }

        static bool TokenOk(string candidate)
        {
            if (string.IsNullOrEmpty(candidate) || string.IsNullOrEmpty(token)) return false;
            byte[] a = Encoding.UTF8.GetBytes(candidate);
            byte[] b = Encoding.UTF8.GetBytes(token);
            // Constant time in the length-equal case, and length is not a secret.
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        // -------------------------------------------------------------- projects --
        // The allowlist the phone indexes into. Scanned once at startup so a
        // request can never introduce a new path.
        static List<string> ScanProjects(IEnumerable<string> extraDirs)
        {
            List<string> outp = new List<string>();
            Action<string> add = delegate(string p)
            {
                if (string.IsNullOrEmpty(p)) return;
                try
                {
                    if (!Directory.Exists(p)) return;
                    string full = Path.GetFullPath(p).TrimEnd('\\');
                    if (!outp.Contains(full)) outp.Add(full);
                }
                catch { }
            };

            // The home directory holds the memory store these chats rely on, so it
            // is a first class entry rather than an afterthought.
            add(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));

            if (extraDirs != null) foreach (string d in extraDirs) add(d);

            // C:\Claude is a flat folder of project directories, not a repository.
            string hub = "C:\\Claude";
            if (Directory.Exists(hub))
            {
                string[] subs;
                try { subs = Directory.GetDirectories(hub); }
                catch { subs = new string[0]; }
                Array.Sort(subs, StringComparer.OrdinalIgnoreCase);
                foreach (string s in subs)
                {
                    string leaf = Path.GetFileName(s);
                    if (leaf.StartsWith(".", StringComparison.Ordinal)) continue;
                    add(s);
                }
            }
            return outp;
        }

        public static void Rescan()
        {
            List<string> p = ScanProjects(null);
            lock (gate) { projects = p; }
        }

        // ------------------------------------------------------------------ loop --
        static void Accept()
        {
            while (Running)
            {
                HttpListenerContext ctx;
                try { ctx = listener.GetContext(); }
                catch { if (!Running) return; continue; }

                // Each request on its own thread. An SSE handler parks for as long
                // as the phone is attached, so it must not hold up the accept loop.
                Thread t = new Thread(delegate()
                {
                    try { Handle(ctx); }
                    catch (Exception ex)
                    {
                        try { Fail(ctx, 500, ex.Message); } catch { }
                    }
                });
                t.IsBackground = true;
                t.Start();
            }
        }

        static void Tick(object state)
        {
            // Heartbeat, so an idle SSE connection is not dropped by a proxy.
            List<Chat> all;
            lock (gate) { all = new List<Chat>(chats.Values); }
            byte[] ping = Encoding.UTF8.GetBytes(": ping\n\n");

            foreach (Chat c in all)
            {
                List<Stream> targets;
                lock (c) { targets = new List<Stream>(c.Listeners); }
                foreach (Stream s in targets)
                {
                    try { s.Write(ping, 0, ping.Length); s.Flush(); }
                    catch { c.Detach(s); Safe(delegate { s.Close(); }); }
                }
            }

            // Reap. A reaped chat can be reopened by its session id, which resumes
            // the very same conversation, so this costs continuity nothing.
            DateTime now = DateTime.UtcNow;
            List<Chat> dead = new List<Chat>();
            lock (gate)
            {
                foreach (KeyValuePair<string, Chat> kv in chats)
                {
                    Chat c = kv.Value;
                    if (c.Busy) continue;
                    if (!c.Alive || now - c.LastActivity > IdleLimit) dead.Add(c);
                }
                foreach (Chat c in dead) chats.Remove(c.Id);
            }
            foreach (Chat c in dead) Safe(delegate { c.Close(); });
        }

        // -------------------------------------------------------------- routing --
        static void Handle(HttpListenerContext ctx)
        {
            HttpListenerRequest req = ctx.Request;
            string path = req.Url.AbsolutePath;

            // Auth first, for everything.
            string supplied = req.QueryString["t"];
            if (string.IsNullOrEmpty(supplied))
            {
                string auth = req.Headers["Authorization"];
                if (!string.IsNullOrEmpty(auth) && auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                    supplied = auth.Substring(7).Trim();
            }
            if (string.IsNullOrEmpty(supplied))
            {
                Cookie c = req.Cookies["awc"];
                if (c != null) supplied = c.Value;
            }

            if (!TokenOk(supplied))
            {
                ctx.Response.StatusCode = 401;
                Text(ctx, "Not paired. Open the link from the Awake window, or scan the QR code.");
                return;
            }

            if (path == "/" || path == "/index.html")
            {
                // Remember the pairing so links and API calls do not need the token
                // in every URL. Not marked Secure: this is served over plain http on
                // loopback and Tailscale terminates TLS in front, so a Secure cookie
                // would simply be dropped.
                Cookie ck = new Cookie("awc", token);
                ck.Path = "/";
                ck.HttpOnly = true;
                ctx.Response.SetCookie(ck);
                ctx.Response.Headers["Cache-Control"] = "no-store";
                Html(ctx, ConsoleUi.Page);
                return;
            }

            if (path == "/api/state") { ApiState(ctx); return; }
            if (path == "/api/history") { ApiHistory(ctx); return; }
            if (path == "/api/stream") { ApiStream(ctx); return; }
            if (path == "/api/open") { ApiOpen(ctx); return; }
            if (path == "/api/send") { ApiSend(ctx); return; }
            if (path == "/api/close") { ApiClose(ctx); return; }
            if (path == "/api/link") { ApiLink(ctx); return; }

            ctx.Response.StatusCode = 404;
            Text(ctx, "no such endpoint");
        }

        // ------------------------------------------------------------ endpoints --
        static void ApiState(HttpListenerContext ctx)
        {
            List<object> sess = new List<object>();
            foreach (SessionInfo si in SessionIndex.Scan(120))
            {
                Dictionary<string, object> d = new Dictionary<string, object>();
                d["id"] = si.Id;
                d["title"] = si.Title;
                d["project"] = si.Project;
                d["cwd"] = si.Cwd;
                d["when"] = si.Modified.ToString("o", CultureInfo.InvariantCulture);
                d["kb"] = si.Bytes / 1024;
                sess.Add(d);
            }

            List<object> projs = new List<object>();
            List<string> snapshot;
            lock (gate) { snapshot = new List<string>(projects); }
            for (int i = 0; i < snapshot.Count; i++)
            {
                Dictionary<string, object> d = new Dictionary<string, object>();
                d["i"] = i;
                d["name"] = SessionIndex.ShortProject(snapshot[i]);
                d["path"] = snapshot[i];
                d["linked"] = MemoryLinked(snapshot[i]);
                projs.Add(d);
            }

            List<object> live = new List<object>();
            lock (gate)
            {
                foreach (Chat c in chats.Values)
                {
                    Dictionary<string, object> d = new Dictionary<string, object>();
                    d["chatId"] = c.Id;
                    d["sid"] = c.SessionId;
                    d["label"] = c.Label;
                    d["cwd"] = c.Cwd;
                    d["mode"] = c.Mode;
                    d["busy"] = c.Busy;
                    d["alive"] = c.Alive;
                    d["seq"] = c.Seq;
                    d["cost"] = Math.Round(c.CostUsd, 4);
                    live.Add(d);
                }
            }

            Dictionary<string, object> body = new Dictionary<string, object>();
            body["sessions"] = sess.ToArray();
            body["projects"] = projs.ToArray();
            body["chats"] = live.ToArray();
            body["modes"] = new object[] { "auto", "acceptEdits", "plan", "dontAsk", "manual" };
            body["models"] = new object[] { "", "opus", "sonnet", "haiku" };
            body["version"] = Build.Version;
            Json(ctx, body);
        }

        static void ApiHistory(HttpListenerContext ctx)
        {
            string sid = ctx.Request.QueryString["sid"];
            if (!IsUuid(sid)) { Fail(ctx, 400, "bad session id"); return; }
            Dictionary<string, object> body = new Dictionary<string, object>();
            body["messages"] = SessionIndex.History(sid, 60).ToArray();
            Json(ctx, body);
        }

        static void ApiOpen(HttpListenerContext ctx)
        {
            Dictionary<string, object> b = Body(ctx);
            string mode = J.Str(b, "mode");
            string model = SafeModel(J.Str(b, "model"));
            string sid = J.Str(b, "sid");
            string label;
            string cwd;

            if (!string.IsNullOrEmpty(sid))
            {
                // Reopening a conversation. Its own transcript is the authority on
                // where it ran, because the encoded folder name is lossy.
                if (!IsUuid(sid)) { Fail(ctx, 400, "bad session id"); return; }

                // Already open? Hand back the same chat rather than starting a second
                // process against one conversation.
                lock (gate)
                {
                    foreach (Chat existing in chats.Values)
                    {
                        if (existing.SessionId == sid && existing.Alive)
                        {
                            Dictionary<string, object> same = new Dictionary<string, object>();
                            same["chatId"] = existing.Id;
                            same["sid"] = existing.SessionId;
                            same["cwd"] = existing.Cwd;
                            same["label"] = existing.Label;
                            same["seq"] = existing.Seq;
                            same["reused"] = true;
                            Json(ctx, same);
                            return;
                        }
                    }
                }

                SessionInfo found = null;
                foreach (SessionInfo si in SessionIndex.Scan(400))
                {
                    if (si.Id == sid) { found = si; break; }
                }
                if (found == null) { Fail(ctx, 404, "conversation not found"); return; }
                cwd = found.Cwd;
                label = found.Title;
                if (!Directory.Exists(cwd))
                {
                    // The lossy folder decode can miss when a real dash is in a
                    // folder name. Fall back to the home directory rather than fail.
                    cwd = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                }
            }
            else
            {
                // New chat in a scanned project. An index, never a path.
                object raw = J.Get(b, "project");
                int idx;
                try { idx = Convert.ToInt32(raw, CultureInfo.InvariantCulture); }
                catch { Fail(ctx, 400, "bad project"); return; }

                lock (gate)
                {
                    if (idx < 0 || idx >= projects.Count) { Fail(ctx, 400, "bad project"); return; }
                    cwd = projects[idx];
                }
                label = "New chat in " + SessionIndex.ShortProject(cwd);
                sid = null;
            }

            Chat chat = new Chat();
            chat.Id = Guid.NewGuid().ToString("N");
            chat.Cwd = cwd;
            chat.Label = string.IsNullOrEmpty(label) ? SessionIndex.ShortProject(cwd) : label;
            chat.Mode = string.IsNullOrEmpty(mode) ? "auto" : mode;
            chat.Model = model;

            string err = chat.Start(sid);
            if (err != null) { Fail(ctx, 500, err); return; }

            lock (gate) { chats[chat.Id] = chat; }

            Dictionary<string, object> res = new Dictionary<string, object>();
            res["chatId"] = chat.Id;
            res["sid"] = chat.SessionId;
            res["cwd"] = chat.Cwd;
            res["label"] = chat.Label;
            res["mode"] = chat.Mode;
            res["seq"] = 0;
            res["reused"] = false;
            Json(ctx, res);
        }

        static void ApiSend(HttpListenerContext ctx)
        {
            Dictionary<string, object> b = Body(ctx);
            Chat c = Find(J.Str(b, "chatId"));
            if (c == null) { Fail(ctx, 404, "chat is not open"); return; }
            string text = J.Str(b, "text");
            if (string.IsNullOrEmpty(text)) { Fail(ctx, 400, "empty message"); return; }
            if (text.Length > 100000) { Fail(ctx, 413, "message too long"); return; }
            string err = c.Send(text);
            if (err != null) { Fail(ctx, 500, err); return; }
            Ok(ctx);
        }

        static void ApiClose(HttpListenerContext ctx)
        {
            Dictionary<string, object> b = Body(ctx);
            string id = J.Str(b, "chatId");
            Chat c = Find(id);
            if (c == null) { Ok(ctx); return; }
            lock (gate) { chats.Remove(id); }
            Safe(delegate { c.Close(); });
            Ok(ctx);
        }

        // Memory is keyed to the working directory, so a chat in C:\Claude\Foo gets
        // its own empty store rather than the one with everything in it. A junction
        // points them at the same place. mklink /J needs no elevation.
        static void ApiLink(HttpListenerContext ctx)
        {
            Dictionary<string, object> b = Body(ctx);
            int idx;
            try { idx = Convert.ToInt32(J.Get(b, "project"), CultureInfo.InvariantCulture); }
            catch { Fail(ctx, 400, "bad project"); return; }

            string cwd;
            lock (gate)
            {
                if (idx < 0 || idx >= projects.Count) { Fail(ctx, 400, "bad project"); return; }
                cwd = projects[idx];
            }

            string err = LinkMemory(cwd);
            if (err != null) { Fail(ctx, 500, err); return; }
            Ok(ctx);
        }

        public static string CanonicalMemory()
        {
            string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            return Path.Combine(SessionIndex.Root(), EncodeDir(home), "memory");
        }

        public static string EncodeDir(string cwd)
        {
            if (string.IsNullOrEmpty(cwd)) return "";
            return cwd.TrimEnd('\\', '/').Replace(':', '-').Replace('\\', '-').Replace('/', '-');
        }

        public static bool MemoryLinked(string cwd)
        {
            try
            {
                string canonical = CanonicalMemory();
                string mine = Path.Combine(SessionIndex.Root(), EncodeDir(cwd), "memory");
                if (string.Equals(Path.GetFullPath(mine), Path.GetFullPath(canonical),
                                  StringComparison.OrdinalIgnoreCase)) return true;
                if (!Directory.Exists(mine)) return false;
                DirectoryInfo di = new DirectoryInfo(mine);
                return (di.Attributes & FileAttributes.ReparsePoint) == FileAttributes.ReparsePoint;
            }
            catch { return false; }
        }

        static string LinkMemory(string cwd)
        {
            try
            {
                string canonical = CanonicalMemory();
                if (!Directory.Exists(canonical)) return "no memory store to link to";

                string projDir = Path.Combine(SessionIndex.Root(), EncodeDir(cwd));
                string mine = Path.Combine(projDir, "memory");
                if (string.Equals(Path.GetFullPath(mine), Path.GetFullPath(canonical),
                                  StringComparison.OrdinalIgnoreCase)) return null;
                if (MemoryLinked(cwd)) return null;

                Directory.CreateDirectory(projDir);

                if (Directory.Exists(mine))
                {
                    // Never destroy an existing store. Move it aside so the change
                    // is reversible.
                    string[] entries = Directory.GetFileSystemEntries(mine);
                    if (entries.Length > 0)
                    {
                        string aside = mine + ".before-link-" +
                                       DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
                        Directory.Move(mine, aside);
                    }
                    else
                    {
                        Directory.Delete(mine);
                    }
                }

                ProcessStartInfo psi = new ProcessStartInfo("cmd.exe",
                    "/c mklink /J \"" + mine + "\" \"" + canonical + "\"");
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                Process p = Process.Start(psi);
                string so = p.StandardOutput.ReadToEnd();
                string se = p.StandardError.ReadToEnd();
                p.WaitForExit(8000);
                if (p.ExitCode != 0)
                    return "mklink failed: " + (se.Trim().Length > 0 ? se.Trim() : so.Trim());
                return null;
            }
            catch (Exception ex) { return ex.Message; }
        }

        // ------------------------------------------------------------------ sse --
        static void ApiStream(HttpListenerContext ctx)
        {
            Chat c = Find(ctx.Request.QueryString["chatId"]);
            if (c == null) { Fail(ctx, 404, "chat is not open"); return; }

            int from = 0;
            int.TryParse(ctx.Request.QueryString["from"], out from);

            HttpListenerResponse res = ctx.Response;
            res.StatusCode = 200;
            res.ContentType = "text/event-stream; charset=utf-8";
            res.Headers["Cache-Control"] = "no-cache, no-store";
            res.Headers["X-Accel-Buffering"] = "no";   // tell any proxy not to buffer
            res.SendChunked = true;
            res.KeepAlive = true;

            Stream s = res.OutputStream;

            // Anything the client missed, before it starts receiving live events,
            // so a phone coming back from a locked screen catches up rather than
            // showing a gap.
            try
            {
                byte[] hello = Encoding.UTF8.GetBytes("retry: 2000\n\n");
                s.Write(hello, 0, hello.Length);
                foreach (string payload in c.Replay(from))
                {
                    byte[] frame = Encoding.UTF8.GetBytes("data: " + payload + "\n\n");
                    s.Write(frame, 0, frame.Length);
                }
                s.Flush();
            }
            catch
            {
                Safe(delegate { s.Close(); });
                return;
            }

            c.Attach(s);

            // Park. The stream stays open and is written by Chat.Emit and by the
            // heartbeat; both drop it on the first failed write. Closing the
            // response here would end the connection, so this thread just waits
            // until the stream is gone.
            while (Running)
            {
                Thread.Sleep(1000);
                bool attached;
                lock (c) { attached = c.Listeners.Contains(s); }
                if (!attached) break;
            }
            c.Detach(s);
            Safe(delegate { s.Close(); });
        }

        // -------------------------------------------------------------- plumbing --
        static Chat Find(string chatId)
        {
            if (string.IsNullOrEmpty(chatId)) return null;
            lock (gate)
            {
                Chat c;
                if (chats.TryGetValue(chatId, out c)) return c;
                return null;
            }
        }

        // An empty string means whatever the machine's default is, which is the
        // right answer most of the time. The rest is a fixed list, not free text:
        // this value reaches a command line.
        static string SafeModel(string m)
        {
            if (string.IsNullOrEmpty(m)) return "";
            switch (m)
            {
                case "opus":
                case "sonnet":
                case "haiku":
                    return m;
                default:
                    return "";
            }
        }

        static bool IsUuid(string s)
        {
            return !string.IsNullOrEmpty(s) &&
                   Regex.IsMatch(s, "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");
        }

        static Dictionary<string, object> Body(HttpListenerContext ctx)
        {
            try
            {
                using (StreamReader sr = new StreamReader(ctx.Request.InputStream, Encoding.UTF8))
                {
                    char[] buf = new char[200000];
                    int n = sr.Read(buf, 0, buf.Length);
                    return J.Read(new string(buf, 0, n)) ?? new Dictionary<string, object>();
                }
            }
            catch { return new Dictionary<string, object>(); }
        }

        static void Send(HttpListenerContext ctx, string contentType, byte[] bytes)
        {
            try
            {
                ctx.Response.ContentType = contentType;
                ctx.Response.ContentLength64 = bytes.Length;
                ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            }
            catch { }
            finally { Safe(delegate { ctx.Response.OutputStream.Close(); }); }
        }

        static void Html(HttpListenerContext ctx, string html)
        {
            Send(ctx, "text/html; charset=utf-8", Encoding.UTF8.GetBytes(html));
        }

        static void Text(HttpListenerContext ctx, string s)
        {
            Send(ctx, "text/plain; charset=utf-8", Encoding.UTF8.GetBytes(s));
        }

        static void Json(HttpListenerContext ctx, object body)
        {
            ctx.Response.Headers["Cache-Control"] = "no-store";
            Send(ctx, "application/json; charset=utf-8", Encoding.UTF8.GetBytes(J.Write(body)));
        }

        static void Ok(HttpListenerContext ctx)
        {
            Dictionary<string, object> d = new Dictionary<string, object>();
            d["ok"] = true;
            Json(ctx, d);
        }

        static void Fail(HttpListenerContext ctx, int code, string message)
        {
            ctx.Response.StatusCode = code;
            Dictionary<string, object> d = new Dictionary<string, object>();
            d["ok"] = false;
            d["error"] = message;
            Json(ctx, d);
        }
    }
}
